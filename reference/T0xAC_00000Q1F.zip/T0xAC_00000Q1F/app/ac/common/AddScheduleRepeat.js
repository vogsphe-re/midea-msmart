// { "framework": "Vue" }

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 920);
/******/ })
/************************************************************************/
/******/ ({

/***/ 1:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

var _debugUtil = __webpack_require__(5);

var _debugUtil2 = _interopRequireDefault(_debugUtil);

var _util = __webpack_require__(11);

var _util2 = _interopRequireDefault(_util);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var mm = weex.requireModule('modal');
var navigator = weex.requireModule('navigator');
var stream = weex.requireModule('stream');
var storage = weex.requireModule('storage');
var bridgeModule = weex.requireModule('bridgeModule');
// const blueToothModule = weex.requireModule('blueToothModule');
var singleBlueToothModule = weex.requireModule('singleBlueToothModule'); // ^5.9.0
var blueToothMeshModule = weex.requireModule('blueToothMeshModule');
var globalEvent = weex.requireModule("globalEvent");
var aiSpeechModule = weex.requireModule("aiSpeechModule"); // ^5.9.0


var isIos = weex.config.env.platform == "iOS" ? true : false;


var isDummy = false;
// import Mock from './mock'  //正式场上线时注释掉

var debugLogSeperator = "**************************************\n";

var isDummy = _util2.default.getParameters(weex.config.bundleUrl, "isDummy") == "true";

var platform = weex.config.env.platform;
if (platform == 'Web') {
    isDummy = true;
}
console.log("isDummy:" + isDummy);
var isRemote = weex.config.bundleUrl.indexOf("http") > -1 ? true : false;

exports.default = {
    serviceList: {
        test: "commonservice"
    },
    Mock: {},
    isDummy: isDummy,
    //**********Util方法***************START
    convertToJson: function convertToJson(str) {
        var result = str;
        if (typeof str == 'string') {
            try {
                result = JSON.parse(str);
            } catch (error) {
                console.error(error);
            }
        }
        return result;
    },
    getParameters: function getParameters(key) {
        var theRequest = new Object();
        var bundleUrl = weex.config.bundleUrl;
        var queryString = '';
        if (bundleUrl.indexOf("?") != -1) {
            queryString = bundleUrl.substr(bundleUrl.indexOf("?") + 1);
            var strs = queryString.split("&");
            for (var i = 0; i < strs.length; i++) {
                theRequest[strs[i].split("=")[0]] = decodeURIComponent(strs[i].split("=")[1]);
            }
        }
        return key ? theRequest[key] : theRequest;
    },

    //**********Util方法***************END

    //**********页面跳转接口***************START
    /*
    params:
        path - 跳转页面路径（以插件文件夹为根目录的相对路径）
        options: {
            animated: true/false, - 是否需要跳转动画
            replace: true/false, - 跳转后是否在历史栈保留当前页面
            viewTag: string - 给跳转后的页面设置标识，可用于goBack时指定返回页面
            transparent: 'true/false', //新页面背景是否透明
            animatedType: 'slide_bottomToTop' //新页面出现动效类型
        }
     */
    goTo: function goTo(path, options, params, isCanSideBack) {
        var _this = this;

        var url;

        if (params) {
            path += (path.indexOf("?") == -1 ? '?' : "&") + Object.keys(params).map(function (k) {
                return encodeURIComponent(k) + '=' + encodeURIComponent(params[k] || '');
            }).join('&');
        }
        // mm.toast({ message: isRemote, duration: 2 })
        if (this.isDummy != true && !isRemote) {
            //手机本地页面跳转
            this.getPath(function (weexPath) {
                //weexPath为当前页面目录地址
                // url = weexPath + path;
                var weexPathArray = weexPath.split('/');
                var pathArray = path.split('/');
                if (weexPathArray[weexPathArray.length - 2] == pathArray[0]) {
                    pathArray.shift();
                    if (weexPathArray[weexPathArray.length - 3] == pathArray[0]) {
                        pathArray.shift();
                        if (weexPathArray[weexPathArray.length - 4] == pathArray[0]) {
                            pathArray.shift();
                        }
                    }
                    url = weexPathArray.join('/') + pathArray.join('/');
                } else {
                    url = weexPath + path;
                }
                // this.alert(path+'-------'+JSON.stringify(options))
                _this.runGo(url, options, isCanSideBack);
            });
        } else if (platform != 'Web') {
            //手机远程weex页面调试跳转
            this.getPath(function (weexPath) {
                //weexPath为当前页面目录地址
                var weexPathArray = weexPath.split('/');
                var pathArray = path.split('/');
                if (weexPathArray[weexPathArray.length - 2] == pathArray[0]) {
                    pathArray.shift();
                    if (weexPathArray[weexPathArray.length - 3] == pathArray[0]) {
                        pathArray.shift();
                        if (weexPathArray[weexPathArray.length - 4] == pathArray[0]) {
                            pathArray.shift();
                        }
                    }
                    url = weexPathArray.join('/') + pathArray.join('/');
                } else {
                    url = weexPath + path;
                }
                if (url.indexOf("?") != -1) {
                    url += '&isDummy=' + isDummy;
                } else {
                    url += '?isDummy=' + isDummy;
                }
                _this.runGo(url, options, isCanSideBack);
            });
        } else {
            //PC网页调试跳转
            location.href = location.origin + location.pathname + '?path=' + path.replace('?', '&');
        }
    },
    runGo: function runGo(url, options, isCanSideBack) {
        // mm.toast({ message: url, duration: 2 })
        // if (isCanSideBack !== undefined) {
        //     options.isCanSideBack = isCanSideBack
        // }
        if (!options) {
            options = {
                animated: 'true',
                replace: 'false'
            };
        } else {
            if (typeof options.animated == 'boolean') {
                options.animated = options.animated ? 'true' : 'false';
            }
            if (typeof options.replace == 'boolean') {
                options.replace = options.replace ? 'true' : 'false';
            }
        }
        // this.alert(isCanSideBack)
        if (isCanSideBack !== undefined) {
            options.isCanSideBack = isCanSideBack;
        }
        // this.alert('tt'+JSON.stringify(options))
        var params = Object.assign(options, {
            url: url
        });
        // this.alert(params)
        navigator.push(params, function (event) {});
    },

    /*
        取得当前weex页面的根路径
    */
    getPath: function getPath(callBack) {
        if (this.isDummy != true && !isRemote) {
            bridgeModule.getWeexPath(function (resData) {
                var jsonData = JSON.parse(resData);
                var weexPath = jsonData.weexPath;
                callBack(weexPath);
            });
        } else if (platform != 'Web') {
            //手机远程weex页面调试
            var rootPath = weex.config.bundleUrl.match(new RegExp("(.*/).*\.js", "i"));
            callBack(rootPath ? rootPath[1] : weex.config.bundleUrl);
        } else {
            //PC网页调试跳转
            location.href = location.origin + location.pathname + '?path=' + path;
        }
    },
    getWeexPath: function getWeexPath() {
        var _this2 = this;

        return new Promise(function (resolve, reject) {
            bridgeModule.getWeexPath(function (resData) {
                resolve(_this2.convertToJson(resData));
            });
        });
    },

    /*  
    options = {
            animated: 'true',
            animatedType: 'slide_topToBottom' //页面关闭时动效类型
    }*/
    goBack: function goBack() {
        var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        var params = Object.assign({
            animated: 'true'
        }, options);
        // this.toast(params)
        navigator.pop(params, function (event) {});
    },
    backToNative: function backToNative() {
        bridgeModule.backToNative();
    },

    //**********页面跳转接口***************END


    //**********非APP业务接口***************START
    generateUUID: function generateUUID() {
        var d = new Date().getTime();
        var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            var r = (d + Math.random() * 16) % 16 | 0;
            d = Math.floor(d / 16);
            return (c == 'x' ? r : r & 0x3 | 0x8).toString(16);
        });
        return uuid;
    },
    genMessageId: function genMessageId() {
        var messageId = '';
        for (var i = 0; i < 8; i++) {
            messageId += Math.floor(Math.random() * 10).toString();
        }
        return messageId;
    },
    getItem: function getItem(key, callback) {
        storage.getItem(key, callback);
    },
    setItem: function setItem(key, value, callback) {
        var temp = void 0;
        if ((typeof value === 'undefined' ? 'undefined' : _typeof(value)) == 'object') {
            temp = JSON.stringify(value);
        }
        var defaultCallback = function defaultCallback(event) {
            console.log('set success');
        };
        storage.setItem(key, temp || value, callback || defaultCallback);
    },
    removeItem: function removeItem(key, callback) {
        storage.removeItem(key, function () {
            if (callback) callback();
        });
    },
    toast: function toast(message, duration, bgStyle) {
        if ((typeof message === 'undefined' ? 'undefined' : _typeof(message)) == 'object') {
            message = JSON.stringify(message);
        }
        if (platform == 'Web') {
            mm.toast({ message: message, duration: duration || 1.5 });
        } else {
            bridgeModule.toast({ message: message, duration: duration || 1.5, bgStyle: bgStyle });
        }
    },
    alert: function alert(message, callback, okTitle) {
        var callbackFunc = callback || function (value) {};

        if ((typeof message === 'undefined' ? 'undefined' : _typeof(message)) == 'object') {
            try {
                message = JSON.stringify(message);
            } catch (error) {}
        }
        mm.alert({
            message: message,
            okTitle: okTitle || "确定"
        }, function (value) {
            callbackFunc(value);
        });
    },
    confirm: function confirm(message, callback, okTitle, cancelTitle) {
        mm.confirm({
            message: message,
            okTitle: okTitle || '确定',
            cancelTitle: cancelTitle || '取消'
        }, function (result) {
            callback(result);
        });
    },
    showLoading: function showLoading() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        if (this.isDummy != true) {
            if (_util2.default.toNum(weex.config.env.appVersion) >= _util2.default.toNum("5.11.0")) {
                bridgeModule.showLoading(params);
            } else {
                bridgeModule.showLoading();
            }
        }
    },
    hideLoading: function hideLoading() {
        if (this.isDummy != true) {
            bridgeModule.hideLoading();
        }
    },
    showLoadingWithMsg: function showLoadingWithMsg(option) {
        if (this.isDummy != true) {
            var params = option;
            if (typeof option == 'string') {
                params = {
                    msg: option
                };
            }
            bridgeModule.showLoadingWithMsg(params);
        }
    },
    hideLoadingWithMsg: function hideLoadingWithMsg() {
        if (this.isDummy != true) {
            bridgeModule.hideLoadingWithMsg();
        }
    },

    //隐藏系统导航栏
    setNavBarHidden: function setNavBarHidden() {
        navigator.setNavBarHidden({
            hidden: '1',
            animated: "false"
        }, function (event) {});
    },

    //关闭键盘
    killKeyboard: function killKeyboard() {
        if (this.isDummy != true) {
            bridgeModule.killKeyboard();
        }
    },

    //**********非APP业务接口***************END

    //**********网络请求接口***************START
    //发送智慧云网络请求：此接口固定Post到智慧云https地址及端口
    sendMCloudRequest: function sendMCloudRequest(name, params) {
        var _this3 = this;

        var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : { isShowLoading: true, isValidate: true };

        return new Promise(function (resolve, reject) {
            var self = _this3;
            if (_this3.isDummy != true) {
                _this3.getItem("masterId", function (resdata) {
                    var msgid = self.genMessageId();
                    var masterId = resdata.data;
                    var sendData = {};
                    sendData.url = self.serviceList[name] ? self.serviceList[name] : name;
                    sendData.params = Object.assign({
                        applianceId: masterId + "",
                        msgid: msgid
                    }, params);
                    if (options.isShowLoading) {
                        _this3.showLoading();
                    }
                    bridgeModule.sendMCloudRequest(sendData, function (resData) {
                        _debugUtil2.default.debugLog(debugLogSeperator, 'request(' + msgid + '): ', sendData);
                        _debugUtil2.default.debugLog('response(' + msgid + '): ', resData, debugLogSeperator);
                        if (typeof resData == 'string') {
                            resData = JSON.parse(resData);
                        }
                        if (options.isShowLoading) {
                            _this3.hideLoading();
                        }

                        if (options.isValidate) {
                            //resData.status为5.0判断；resData.errorCode为4.判断
                            if (resData.errorCode == 0) {
                                resolve(resData);
                            } else if (resData.status === true) {
                                resolve(resData);
                            } else {
                                reject(resData);
                            }
                        } else {
                            resolve(resData);
                        }
                    }, function (error) {
                        _debugUtil2.default.debugLog(debugLogSeperator, 'request(' + msgid + '): ', sendData);
                        _debugUtil2.default.debugLog('=======> error(' + msgid + '): ', error, debugLogSeperator);
                        if (options.isShowLoading) {
                            _this3.hideLoading();
                        }
                        if (typeof error == 'string') {
                            error = JSON.parse(error);
                        }
                        reject(error);
                    });
                });
            } else {
                var resData = _this3.Mock.getMock(self.serviceList[name] ? self.serviceList[name] : name);
                if (options.isValidate) {
                    //resData.status为5.0判断；resData.errorCode为4.判断
                    if (resData.errorCode == 0) {
                        resolve(resData);
                    } else if (resData.status === true) {
                        resolve(resData);
                    } else {
                        reject(resData);
                    }
                } else {
                    resolve(resData);
                }
            }
        });
    },


    //^5.0.0发送中台网络请求：此接口固定Post到中台https地址及端口
    /* 
    name: 'gateway/subdevice/search', //请求接口路径url，或者serviceList的key,
    params(可选): {
        method: 'POST', //POST/GET, 默认POST
        headers: {}, //请求header
        data: {} //请求参数
        } 
    */
    sendCentralCloundRequest: function sendCentralCloundRequest(name, params) {
        var _this4 = this;

        var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : { isShowLoading: true };

        return new Promise(function (resolve, reject) {
            if (_this4.isDummy != true) {
                var msgid = _this4.genMessageId();
                var sendData = params || {};
                sendData.url = _this4.serviceList[name] ? _this4.serviceList[name] : name;
                if (options.isShowLoading) {
                    _this4.showLoading();
                }
                bridgeModule.sendCentralCloundRequest(sendData, function (resData) {
                    _debugUtil2.default.debugLog(debugLogSeperator, 'request(' + msgid + '): ', sendData);
                    _debugUtil2.default.debugLog('response(' + msgid + '): ', resData, debugLogSeperator);
                    if (typeof resData == 'string') {
                        try {
                            resData = JSON.parse(resData);
                        } catch (e) {}
                    }
                    if (options.isShowLoading) {
                        _this4.hideLoading();
                    }

                    resolve(resData);
                }, function (error) {
                    _debugUtil2.default.debugLog(debugLogSeperator, 'request(' + msgid + '): ', sendData);
                    _debugUtil2.default.debugLog('=======> error(' + msgid + '): ', error, debugLogSeperator);
                    if (options.isShowLoading) {
                        _this4.hideLoading();
                    }
                    if (typeof error == 'string') {
                        try {
                            error = JSON.parse(error);
                        } catch (e) {}
                    }
                    reject(error);
                });
            } else {
                var resData = _this4.Mock.getMock(_this4.serviceList[name] ? _this4.serviceList[name] : name);
                resolve(resData);
            }
        });
    },


    //AEM系统发送请求
    retransmissionCloundRequestSend: function retransmissionCloundRequestSend(url, params) {
        var _this5 = this;

        var method = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 'get';
        var options = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {};

        var param = {
            url: url,
            method: method,
            data: _extends({}, params)
        };
        return new Promise(function (resolve, reject) {
            // nativeService.retransmissionCloundRequest(url, params, options).then((res) => {
            _this5.retransmissionCloundRequest(param, options).then(function (res) {
                if (parseInt(res.code, 10) === 200) {
                    resolve(res);
                } else {
                    reject(res);
                }
            }).catch(function (error) {
                reject(error);
            });
        });
    },
    retransmissionCloundRequest: function retransmissionCloundRequest(params) {
        var _this6 = this;

        var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : { isShowLoading: false };

        var param = Object.assign({
            operation: 'retransmissionCloundRequest',
            params: params
        });
        // return this.commandInterfaceWrapper(param);
        return new Promise(function (resolve, reject) {
            if (options.isShowLoading) {
                _this6.showLoading();
            }
            // this.alert(JSON.stringify(param))
            bridgeModule.commandInterface(JSON.stringify(param), function (resData) {
                if (options.isShowLoading) {
                    _this6.hideLoading();
                }
                resolve(_this6.convertToJson(resData));
            }, function (error) {
                if (options.isShowLoading) {
                    _this6.hideLoading();
                }
                reject(error);
            });
        });
    },

    //发送POST网络请求：URL自定义
    /* params: {
        url: url,
        type: 'text',
        method: "POST",
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: {
            'objectId': objectId,
            'format': 'base64'
        }
    } */
    sendHttpRequest: function sendHttpRequest(params) {
        var _this7 = this;

        var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : { isShowLoading: true, isValidate: true };

        return new Promise(function (resolve, reject) {
            var requestParams = JSON.parse(JSON.stringify(params));
            var self = _this7;
            if (_this7.isDummy != true) {
                var defaultParams = {
                    method: "POST",
                    type: 'json'
                };
                requestParams = Object.assign(defaultParams, requestParams);

                /* body 参数仅支持 string 类型的参数，请勿直接传递 JSON，必须先将其转为字符串。
                GET 请求不支持 body 方式传递参数，请使用 url 传参。 */
                if (requestParams.body && requestParams.method == "GET") {
                    var bodyStr = _this7.convertRequestBody(requestParams.body);
                    if (requestParams.url.indexOf("?") > -1) {
                        requestParams.url += "&" + bodyStr;
                    } else {
                        requestParams.url += "?" + bodyStr;
                    }
                    requestParams.body = "";
                } else if (requestParams.body && requestParams.method == "POST") {
                    requestParams.body = requestParams.body;
                }

                if (options.isShowLoading) {
                    _this7.showLoading();
                }
                var msgid = self.genMessageId();
                stream.fetch(requestParams, function (resData) {
                    _debugUtil2.default.debugLog(debugLogSeperator, 'request(' + msgid + '): ', requestParams);
                    _debugUtil2.default.debugLog('response(' + msgid + '): ', resData, debugLogSeperator);
                    if (options.isShowLoading) {
                        _this7.hideLoading();
                    }
                    if (!resData.ok) {
                        if (typeof resData == 'string') {
                            resData = JSON.parse(resData);
                        }
                        reject(resData);
                    } else {
                        var result = resData.data;
                        if (typeof result == 'string') {
                            result = JSON.parse(result);
                        }
                        resolve(result);
                    }
                });
            } else {
                var resData = _this7.Mock.getMock(params.url);
                resolve(resData);
            }
        });
    },
    convertRequestBody: function convertRequestBody(obj) {
        var param = "";
        for (var name in obj) {
            if (typeof obj[name] != 'function') {
                param += "&" + name + "=" + encodeURI(obj[name]);
            }
        }
        return param.substring(1);
    },

    //发送指令透传接口
    startCmdProcess: function startCmdProcess(name, messageBody, callback, callbackFail) {
        var commandId = Math.floor(Math.random() * 1000);
        var param = {
            commandId: commandId
        };
        if (messageBody != undefined) {
            param.messageBody = messageBody;
        }
        var finalCallBack = function finalCallBack(resData) {
            if (typeof resData == 'string') {
                resData = JSON.parse(resData);
            }
            if (resData.errorCode != 0) {
                callbackFail(resData);
            } else {
                callback(resData.messageBody);
            }
        };
        var finalCallbackFail = function finalCallbackFail(resData) {
            if (typeof resData == 'string') {
                resData = JSON.parse(resData);
            }
            callbackFail(resData);
        };
        if (this.isDummy != true) {
            if (isIos) {
                this.createCallbackFunctionListener();
                this.callbackFunctions[commandId] = finalCallBack;
                this.callbackFailFunctions[commandId] = finalCallbackFail;
            }
            bridgeModule.startCmdProcess(JSON.stringify(param), finalCallBack, finalCallbackFail);
        } else {
            callback(this.Mock.getMock(name).messageBody);
        }
    },


    //发送指令透传接口(套系)
    startCmdProcessTX: function startCmdProcessTX(name, messageBody, deviceId, callback, callbackFail) {
        var commandId = Math.floor(Math.random() * 1000);
        var param = {
            commandId: commandId
        };
        if (messageBody != undefined) {
            param.messageBody = messageBody;
        }
        if (deviceId != undefined) {
            param.deviceId = deviceId;
        }
        var finalCallBack = function finalCallBack(resData) {
            if (typeof resData == 'string') {
                resData = JSON.parse(resData);
            }
            if (resData.errorCode != 0) {
                callbackFail(resData);
            } else {
                callback(resData.messageBody);
            }
        };
        var finalCallbackFail = function finalCallbackFail(resData) {
            if (typeof resData == 'string') {
                resData = JSON.parse(resData);
            }
            callbackFail(resData);
        };
        if (this.isDummy != true) {
            if (isIos) {
                this.createCallbackFunctionListener();
                this.callbackFunctions[commandId] = finalCallBack;
                this.callbackFailFunctions[commandId] = finalCallbackFail;
            }
            bridgeModule.startCmdProcess(JSON.stringify(param), finalCallBack, finalCallbackFail);
        } else {
            callback(this.Mock.getMock(name).messageBody);
        }
    },

    /* 服务透传接口。提供给插件发送请求至事业部的品类服务器。此接口美居APP会将请求内容加密，然后发送给“云平台”进行中转发送至事业部品类服务器。
        params: {
            type:服务类型，如果weex没有传，或者传入类似""的空字节，则取当前插件类型作为该数值
            queryStrings:与H5内容一致
            transmitData:与H5内容一致
        }
    */
    requestDataTransmit: function requestDataTransmit(params) {
        var _this8 = this;

        return new Promise(function (resolve, reject) {
            bridgeModule.requestDataTransmit(JSON.stringify(params), function (resData) {
                resolve(_this8.convertToJson(resData));
            }, function (error) {
                reject(error);
            });
        });
    },


    /* *****即将删除, IOS已经做了改进，不在需要已callbackFunction回调callback ********/
    isCreateListener: false,
    createCallbackFunctionListener: function createCallbackFunctionListener() {
        var _this9 = this;

        if (!this.isCreateListener) {
            this.isCreateListener = true;
            globalEvent.addEventListener("callbackFunction", function (result) {
                //IOS消息返回处理
                var commandId = result.commandId;
                if (commandId) {
                    _this9.callbackFunction(commandId, result);
                }
            });
        }
    },

    callbackFunctions: {},
    callbackFailFunctions: {},
    callbackFunction: function callbackFunction(commandId, result) {
        var jsonResult = result;
        var cbf = this.callbackFunctions[commandId];
        var cbff = this.callbackFailFunctions[commandId];
        if (jsonResult.errorCode !== undefined && jsonResult.errMessage == 'TimeOut') {
            if (typeof cbff == "function") {
                cbff(-1); //表示指令超时 －1
            }
        } else {
            if (typeof cbf == "function") {
                cbf(jsonResult);
            }
        }
        delete this.callbackFunctions[commandId];
        delete this.callbackFailFunctions[commandId];
    },

    /* *****即将删除, IOS已经做了改进，不在需要已callbackFunction回调callback ********/

    //发送Lua指令接口
    sendLuaRequest: function sendLuaRequest(params) {
        var _this10 = this;

        var isShowLoading = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;

        return new Promise(function (resolve, reject) {
            if (!params.operation) {
                params.operation = "luaQuery"; //luaQuery or luaControl
            }
            if (!params.params) {
                params.params = {};
            }

            if (_this10.isDummy != true) {
                if (isShowLoading && params.operation == 'luaQuery') {
                    _this10.showLoading();
                }
                var msgid = _this10.genMessageId();
                bridgeModule.commandInterface(JSON.stringify(params), function (resData) {
                    _debugUtil2.default.debugLog(debugLogSeperator, 'Lua request(' + msgid + '): ', params);
                    _debugUtil2.default.debugLog('Lua response(' + msgid + '):', resData, debugLogSeperator);
                    if (typeof resData == 'string') {
                        resData = JSON.parse(resData);
                    }
                    if (isShowLoading) {
                        _this10.hideLoading();
                    }
                    if (resData.errorCode == 0) {
                        //成功
                        resolve(resData);
                    } else {
                        reject(resData);
                    }
                }, function (error) {
                    // this.alert(error)
                    _debugUtil2.default.debugLog(debugLogSeperator, 'Lua request(' + msgid + '): ', params);
                    _debugUtil2.default.debugLog('=======> Lua error(' + msgid + '): ', error, debugLogSeperator);
                    if (isShowLoading) {
                        _this10.hideLoading();
                    }
                    if (typeof error == 'string') {
                        error = JSON.parse(error);
                    }
                    reject(error);
                });
            } else {
                var resData = void 0;
                if (params['operation'] || params['name']) {
                    if (params['name']) {
                        resData = Mock.getMock(params['name']);
                    } else {
                        resData = Mock.getMock(params['operation']);
                    }
                }
                _debugUtil2.default.debugLog("Mock: ", resData);
                resolve(resData);
            }
        });
    },

    //**********网络请求接口***************END


    //**********APP业务接口***************START
    updateTitle: function updateTitle(title, showLeftBtn, showRightBtn) {
        var params = {
            title: title,
            showLeftBtn: showLeftBtn,
            showRightBtn: showRightBtn
        };
        if (this.isDummy != true) {
            bridgeModule.updateTitle(JSON.stringify(params));
        }
    },
    getAuthToken: function getAuthToken() {
        var _this11 = this;

        return new Promise(function (resolve, reject) {
            bridgeModule.getAuthToken({}, function (resData) {
                resolve(_this11.convertToJson(resData));
            }, function (error) {
                reject(error);
            });
        });
    },

    // 获取套系列表
    getTxList: function getTxList() {
        var _this12 = this;

        var isShowLoading = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : true;

        // if (this.isDummy != true) {
        return new Promise(function (resolve, reject) {
            if (isShowLoading) {
                _this12.showLoading();
            }
            bridgeModule.getTXList({}, function (resData) {
                if (typeof resData == 'string') {
                    // this.alert(resData)
                    var resDataObj = JSON.parse(resData);
                    if (isShowLoading) {
                        _this12.hideLoading();
                    }
                    if (resDataObj.errorCode && resDataObj.errorCode !== 0) {
                        //失败
                        reject(resDataObj);
                    } else {
                        //成功
                        resolve(resDataObj);
                    }
                } else {
                    //Android 可能直接传个对象
                    var resDataObj = resData;
                    if (isShowLoading) {
                        _this12.hideLoading();
                    }
                    if (resDataObj.errorCode && resDataObj.errorCode !== 0) {
                        //失败
                        reject(resDataObj);
                    } else {
                        //成功
                        resolve(resDataObj);
                    }
                }
            }, function (error) {
                if (typeof error == 'string') {
                    error = JSON.parse(error);
                    mm.modal({ "message": error }, 3);
                }
                reject(error);
            });
        });
        // }else{
        //     return new Promise((resolve, reject) => {
        //         let data = Mock.getMock('queryTXList');
        //         resolve(data)
        //     })
        // }
    },
    showSharePanel: function showSharePanel(params, callback, callbackFail) {
        return new Promise(function (resolve, reject) {
            bridgeModule.showSharePanel(params, function (resData) {
                resolve(resData);
            }, function (error) {
                reject(error);
            });
        });
    },


    /*
     * created by zhouhg 20180621 start
     */
    //根据设备信息获取插件信息
    getDevicePluginInfo: function getDevicePluginInfo(params) {
        var _this13 = this;

        return new Promise(function (resolve, reject) {
            if (_this13.isDummy != true) {
                bridgeModule.getDevicePluginInfo(params, function (resData) {
                    resolve(resData);
                }, function (error) {
                    reject(error);
                });
            } else {
                var data = Mock.getMock('getDevicePluginInfo');
                resolve(data);
            }
        });
    },

    //下载插件接口
    downLoadDevicePlugin: function downLoadDevicePlugin(params, callback, callbackFail) {
        var that = this;
        if (this.isDummy != true) {
            bridgeModule.downLoadDevicePlugin(params, function (resData) {
                callback(resData);
            }, function (error) {
                callbackFail(error);
            });
        } else {
            var data = Mock.getMock('downLoadDevicePlugin');
            setTimeout(function () {
                callback(data);
            }, 3000);
        }
    },
    getDeviceOnlineStatus: function getDeviceOnlineStatus(params, callback, callbackFail) {
        var _this14 = this;

        return new Promise(function (resolve, reject) {
            var that = _this14;
            bridgeModule.getDeviceOnlineStatus(params, function (resData) {
                resolve(resData);
            }, function (error) {
                reject(error);
            });
        });
    },

    //设备主动上报在线离线状态
    deviceOnlineStatus: function deviceOnlineStatus() {
        var params = {
            operation: 'deviceOnlineStatus'
        };
        return this.commandInterfaceWrapper(params);
    },

    //更新下载插件并解压后，需要替换加载新下载的插件
    loadingLatestPlugin: function loadingLatestPlugin(params, callback, callbackFail) {
        //  	let params = {};
        return new Promise(function (resolve, reject) {
            bridgeModule.loadingLatestPlugin(params, function (resData) {
                resolve(resData);
            }, function (error) {
                reject(error);
            });
        });
    },

    //重新加载当前页面
    reload: function reload(callback, callbackFail) {
        var params = {};
        bridgeModule.reload(params, function (resData) {
            if (callback) callback(resData);
        }, function (error) {
            if (callbackFail) callbackFail(error);
        });
    },

    /*
     * created by zhouhg 20180621 end
     */

    //统一JS->Native接口
    commandInterfaceWrapper: function commandInterfaceWrapper(param) {
        var _this15 = this;

        return new Promise(function (resolve, reject) {
            bridgeModule.commandInterface(JSON.stringify(param), function (resData) {
                resolve(_this15.convertToJson(resData));
            }, function (error) {
                reject(error);
            });
        });
    },

    //获取用户信息
    getUserInfo: function getUserInfo() {
        var param = {
            operation: 'getUserInfo'
        };
        return this.commandInterfaceWrapper(param);
    },

    //打电话
    /* param: {
        tel: '10086',
        title: '客户服务',
        desc: '拨打热线电话：'
    } */
    callTel: function callTel(params) {
        var param = Object.assign(params, {
            operation: 'callTel'
        });
        return this.commandInterfaceWrapper(param);
    },

    //弹出全局电话列表
    /* param: [{
        tel: '10086',
        title: '客户服务',
        desc: '拨打热线电话：'
    },{...}] */
    callTelList: function callTelList(params) {
        var param = {
            'operation': 'callTelList',
            'params': params
        };
        return this.commandInterfaceWrapper(param);
    },

    //触发手机震动  intensity 1：轻微震动 2：中等震动 3：强烈震动  intensity为空：猛烈♂震动
    hapticFeedback: function hapticFeedback(intensity) {
        var param = void 0;
        if (intensity && typeof intensity == 'number') {
            param = {
                operation: 'hapticFeedback',
                intensity: intensity
            };
        } else {
            param = {
                operation: 'hapticFeedback'
            };
        }
        return this.commandInterfaceWrapper(param);
    },

    //打开指定的系统设置，比如蓝牙
    openNativeSystemSetting: function openNativeSystemSetting(settingName) {
        var param = {
            operation: 'openNativeSystemSetting',
            setting: settingName || 'bluetooth'
        };
        return this.commandInterfaceWrapper(param);
    },
    shareMsg: function shareMsg(params) {
        /* params =  {
            "type": "wx", //分享类型，wx表示微信分享，qq表示qq分享，sms表示短信分享，weibo表示新浪微博，qzone表示QQ空间，wxTimeline表示微信朋友圈
            "title": "xxxxxx", //分享的标题
            "desc": "xxxxxx",//分享的文本内容
            "imgUrl": "xxxxxx",//分享的图片链接
            "link": "xxxxxx" //分享的跳转链接
        } */
        var param = {
            'operation': 'shareMsg',
            'params': params
        };
        return this.commandInterfaceWrapper(param);
    },

    //获取当前设备网络信息
    getNetworkStatus: function getNetworkStatus() {
        var param = {
            operation: 'getNetworkStatus'
        };
        return this.commandInterfaceWrapper(param);
    },

    //获取当前家庭信息
    getCurrentHomeInfo: function getCurrentHomeInfo() {
        var param = {
            operation: 'getCurrentHomeInfo'
        };
        return this.commandInterfaceWrapper(param);
    },

    //获取当前设备信息
    getDeviceInfo: function getDeviceInfo() {
        var param = {
            operation: 'getDeviceInfo'
        };
        if (this.isDummy == true) {
            return new Promise(function (resolve, reject) {
                try {
                    var resData = Mock.getMock(param.operation);
                    if (resData.errorCode == 0) {
                        resolve(resData);
                    } else {
                        reject(resData);
                    }
                } catch (error) {
                    reject("获取模拟数据出错");
                }
            });
        } else {
            return this.commandInterfaceWrapper(param);
        }
    },

    //更新当前设备信息
    updateDeviceInfo: function updateDeviceInfo(params) {
        var param = Object.assign(params, {
            operation: 'updateDeviceInfo'
        });
        return this.commandInterfaceWrapper(param);
    },

    //打开指定的原生页面
    jumpNativePage: function jumpNativePage(params) {
        /* params =  {
            "pageName": "xxxx", //跳转的目标页面
            "data": {xxxxxx}, //传参，为json格式字符串
        } */
        var param = Object.assign(params, {
            operation: 'jumpNativePage'
        });
        return this.commandInterfaceWrapper(param);
    },

    //跳转到h5页面
    weexBundleToWeb: function weexBundleToWeb(params) {
        /* params =  {
            url: "xxxx", //跳转的目标页面
            title: "h5标题"
        } */
        var param = Object.assign(params, {
            operation: 'weexBundleToWeb'
        });
        return this.commandInterfaceWrapper(param);
    },

    //设置是否监控安卓手机物理返回键功能, v4.4.0
    setBackHandle: function setBackHandle(status) {
        /* params =  {
            "pageName": "xxxx", //跳转的目标页面
            "isMonitor": on,  //on: 打开监控，off: 关闭监控
        } */
        var params = {
            operation: 'setBackHandle',
            isMonitor: status
        };
        return this.commandInterfaceWrapper(params);
    },

    //二维码/条形码扫码功能，用于读取二维码/条形码的内容
    scanCode: function scanCode() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        var param = Object.assign(params, {
            operation: 'scanCode'
        });
        return this.commandInterfaceWrapper(param);
    },

    //获取wifi列表
    getWifiList: function getWifiList() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        var param = Object.assign(params, {
            operation: 'getWifiList'
        });
        return this.commandInterfaceWrapper(param);
    },

    //开启麦克风录音，可以保存录音文件或者把声音转换成文字
    startRecordAudio: function startRecordAudio(params) {
        /* params =  {
            max:number, //最长录音时间, 单位为秒
            isSave:true/false, //是否保存语音录音文件
            isTransform:true/false, //是否需要转换语音成文字
        } */
        var param = Object.assign(params, {
            operation: 'startRecordAudio'
        });
        return this.commandInterfaceWrapper(param);
    },

    //开启麦克风录音后，自行控制结束录音
    stopRecordAudio: function stopRecordAudio() {
        var params = {
            operation: 'stopRecordAudio'
        };
        return this.commandInterfaceWrapper(params);
    },
    takePhoto: function takePhoto(params) {
        /* params =  {
            compressRage:60, , //number, 返回照片的压缩率，范围为0~100，数值越高保真率越高
            type:'jpg', //值为jpg或png，指定返回相片的格式
            isNeedBase64: true/false //是否需要返回相片base64数据
        } */
        var param = Object.assign(params, {
            operation: 'takePhoto'
        });
        return this.commandInterfaceWrapper(param);
    },

    /* 选择相册照片，并返回相片数据 */
    choosePhoto: function choosePhoto(params) {
        /* params =  {
            compressRage:60, , //number, 返回照片的压缩率，范围为0~100，数值越高保真率越高
            type:'jpg', //值为jpg或png，指定返回相片的格式
            isNeedBase64: true/false //是否需要返回相片base64数据
        } */
        var param = Object.assign(params, {
            operation: 'choosePhoto'
        });
        return this.commandInterfaceWrapper(param);
    },

    /* 选择多张相册照片，并返回相片数据，不支持base64的转换 */
    chooseMulPhoto: function chooseMulPhoto(params) {
        /* params =  {
            max:number, //一次最多可选择的数量，默认为9，最多9张。
        } */
        var param = Object.assign(params, {
            operation: 'chooseMulPhoto'
        });
        return this.commandInterfaceWrapper(param);
    },
    getGPSInfo: function getGPSInfo(params) {
        /* params =  {
            desiredAccuracy: "10",  //定位的精确度，单位：米
            alwaysAuthorization: "0",  //是否开启实时定位功能，0: 只返回一次GPS信息（默认），1:APP在前台时，每移动distanceFilter的距离返回一次回调。2:无论APP在前后台，每移动distanceFilter的距离返回一次回调（注意耗电）
            distanceFilter: "10", //alwaysAuthorization为1或2时有效，每移动多少米回调一次定位信息
        } */
        var param = Object.assign(params, {
            operation: 'getGPSInfo'
        });
        return this.commandInterfaceWrapper(param);
    },
    getCityInfo: function getCityInfo(params) {
        var param = Object.assign(params, {
            operation: 'getCityInfo'
        });
        return this.commandInterfaceWrapper(param);
    },

    /*  ^5.0.0 根据getCityInfo获得的城市对应的气象局ID获取城市天气信息， 比如温度， 风向等信息 */
    getWeatherInfo: function getWeatherInfo(params) {
        var param = Object.assign(params, {
            operation: 'getWeatherInfo'
        });
        return this.commandInterfaceWrapper(param);
    },

    /*  ^5.0.0  百度开放接口，通过经纬度返回对应的位置信息 */
    baiduGeocoder: function baiduGeocoder(params) {
        var param = Object.assign(params, {
            operation: 'baiduGeocoder'
        });
        return this.commandInterfaceWrapper(param);
    },

    //获取登录态信息
    getLoginInfo: function getLoginInfo() {
        var param = {
            operation: 'getLoginInfo'
        };
        return this.commandInterfaceWrapper(param);
    },

    /* ^5.0.0 打开用户手机地图软件，传入标记地点。（打开地图软件后，用户可以使用地图软件的功能，比如导航等）
    ios: 如果用户安装了百度地图，则跳转到百度地图app，没有安装，则跳转Safar，使用网页导航
    android: 如果用户安装了百度地图，则跳转到百度地图app，没有安装，则跳转使用外部浏览器，使用网页导航（用户选择合适的浏览器，原生toast引导，存在选择错误应用的风险） */
    launchMapApp: function launchMapApp(params) {
        /* params =  {
            from:{ //当前用户地点
                latitude: string, //纬度
                longitude: string //经度
            },
            to:{ //目的地地点
                latitude: string, //纬度
                longitude: string //经度
            }
        } */
        var param = Object.assign(params, {
            operation: 'launchMapApp'
        });
        return this.commandInterfaceWrapper(param);
    },

    /* 根据模糊地址，返回地图服务的查询结果数据。 */
    searchMapAddress: function searchMapAddress(params) {
        /* params =  {
            city: "", //需要查询的城市(范围)
            keyword: "美的" //需要查询的地址
        } */
        var param = Object.assign(params, {
            operation: 'searchMapAddress'
        });
        return this.commandInterfaceWrapper(param);
    },

    /* 选择通讯录的好友，可以获取电话号码，好友信息 */
    getAddressBookPerson: function getAddressBookPerson() {
        var param = {
            operation: 'getAddressBookPerson'
        };
        return this.commandInterfaceWrapper(param);
    },
    downloadImageWithCookie: function downloadImageWithCookie(params) {
        var param = Object.assign(params, {
            operation: 'downloadImageWithCookie'
        });
        return this.commandInterfaceWrapper(param);
    },


    //调用第三方SDK统一接口
    interfaceForThirdParty: function interfaceForThirdParty() {
        bridgeModule.interfaceForThirdParty.apply(bridgeModule, arguments);
    },

    //
    updateAutoList: function updateAutoList() {
        bridgeModule.updateAutoList();
    },

    /*发送埋点数据*/
    burialPoint: function burialPoint(params) {
        var param = Object.assign(params, {
            operation: 'burialPoint'
        });
        return this.commandInterfaceWrapper(param);
    },

    /* weex卡片页打开控制页页面接口 */
    showControlPanelPage: function showControlPanelPage() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        bridgeModule.showControlPanelPage(params);
    },

    /* 上传图片文件，调用一次，上传一份图片文件 */
    uploadImgFile: function uploadImgFile(params, callback, callbackFail) {
        /* params = {
            path: string, //值为 图片在手机中的路径
            url: string, //值为服务器上传图片的url
            maxWidth: number, //最大宽度，如果不设置，则使用图片宽度
            maxHeight: number, //最大高度，如果不设置，则使用图片高度
            compressRage: number, //图片的压缩率，范围为0~100，数值越高保真率越高。默认值：100，不压缩，直接上传图片 ps: 压缩后的图片文件格式，固定为jpg 格式
            netParam: {
                xxx: xxx, //weex需要原生填充给服务器的post 表单参数1
                xxx: xxx, //weex需要原生填充给服务器的post 表单参数2
            },
            fileKey: string, //值为原生在post表单中传输图片文件的key值，缺省默认值为“file”
        } */
        var param = Object.assign(params, {
            operation: 'uploadImgFile'
        });
        bridgeModule.commandInterface(param, callback, callbackFail);
    },
    uploadImgFileToMas: function uploadImgFileToMas(params, callback, callbackFail) {
        /* params = {
            path: string, //值为 图片在手机中的路径
            url: string, //值为服务器上传图片的url
            maxWidth: number, //最大宽度，如果不设置，则使用图片宽度
            maxHeight: number, //最大高度，如果不设置，则使用图片高度
            compressRage: number, //图片的压缩率，范围为0~100，数值越高保真率越高。默认值：100，不压缩，直接上传图片 ps: 压缩后的图片文件格式，固定为jpg 格式
            netParam: {
                xxx: xxx, //weex需要原生填充给服务器的post 表单参数1
                xxx: xxx, //weex需要原生填充给服务器的post 表单参数2
            },
            fileKey: string, //值为原生在post表单中传输图片文件的key值，缺省默认值为“file”
        } */
        var param = Object.assign(params, {
            operation: 'uploadImgFileToMas'
        });
        bridgeModule.commandInterface(param, callback, callbackFail);
    },

    //LottieView接口
    showLottieView: function showLottieView() {},

    /* setIdleTimerDisabled 设置屏幕常亮 ^5.7
        1.插件调用setIdleTimerDisabled,原生APP定时60秒后重新开启系统自动屏灭的操作。
        1.1 假如插件要长时间保持屏亮，需要调用setIdleTimerDisabled后，隔60秒后再次调用来维持一直屏亮。
        1.2 插件调用setIdleTimerDisabled，间隔不到60秒又调用setIdleTimerDisabled，原生app的定时时间，重新设置，60秒后再重新启动系统的自动灭屏操作！
    */
    setIdleTimerDisabled: function setIdleTimerDisabled() {
        var param = {
            operation: 'setIdleTimerDisabled'
        };
        bridgeModule.commandInterface(param, function () {}, function () {});
    },

    /*  
     * ^5.7.0 [subscribeMessage]-订阅设备状态推送
     * @params: { deviceId: []}  
     * deviceId是想订阅的设备id,空数组-清空订阅设备，['all']-订阅用户该家庭所有设备消息推送， [deviceId]订阅指定设备
    */
    subscribeMessage: function subscribeMessage(params) {
        var param = Object.assign(params, {
            operation: 'subscribeMessage'
        });
        return this.commandInterfaceWrapper(param);
    },

    /*  
     * ^5.11.0 [subscribeMessage]-订阅设备状态推送
     * @params: { data: xxxxx}  
     * xxxx是加密的SN
    */
    decrptySN: function decrptySN(params) {
        var param = Object.assign(params, {
            operation: 'decrptySN'
        });
        return this.commandInterfaceWrapper(param);
    },

    //**********APP业务接口***************END


    //**********蓝牙接口***************START ==》此接口为二进制传输接口，已经在5.9作废
    // blueToothModuleWrapper(apiName, param) {
    //     return new Promise((resolve, reject) => {
    //         blueToothModule[apiName](JSON.stringify(param),
    //             (resData) => {
    //                 resolve(this.convertToJson(resData))
    //             },
    //             (error) => {
    //                 reject(error)
    //             })
    //     })
    // },
    //获取蓝牙开启状态
    /* return:
        {status:1, //1表示蓝牙已打开，0：蓝牙关闭状态，2:：蓝牙正在重置，3：设备不支持蓝牙，4：蓝牙未授权}
    */
    // getBlueStatus(params = {}) {
    //     return this.blueToothModuleWrapper("getBlueStatus", params)
    // },
    //开始扫描蓝牙 
    /*  param:{duration: number //持续时间, 单位：秒}
        当扫描到的蓝牙设备（蓝牙信息），app-->插件:
        receiveMessageFromApp({messageType:"blueScanResult",messageBody:{name:"xxx", deviceKey:"xxxxx"}})
     */
    // startBlueScan(params = {}) {
    //     return this.blueToothModuleWrapper("startBlueScan", params)
    // },
    //停止蓝牙扫描
    /* 当扫描结束（停止或超时），app -> 插件:
    receiveMessageFromApp({ messageType: "blueScanStop", messageBody: {} })
    */
    // stopBlueScan(params = {}) {
    //     return this.blueToothModuleWrapper("stopBlueScan", params)
    // },
    //保存蓝牙信息
    /* param:{deviceType:品类码, name:"xxx", deviceKey:"xxxxx"} */
    // addDeviceBlueInfo(params = {}) {
    //     return this.blueToothModuleWrapper("addDeviceBlueInfo", params)
    // },
    //获取之前保存的蓝牙信息
    /* param:{ deviceType: 品类码 }
       result:{status：0, //0: 执行成功, 1:执行失败, name:"xxx", deviceKey:"xxxxx"}
    */
    // getDeviceBlueInfo(params = {}) {
    //     return this.blueToothModuleWrapper("getDeviceBlueInfo", params)
    // },
    //根据蓝牙信息建立蓝牙连接
    /* param:{name:"xxx", 
        deviceKey:"xxxxx",
        service:"uuid", //蓝牙服务特征，使用者根据设备信息传入
        writeCharacter:"uuid", //蓝牙写入通道特征，使用者根据设备信息传入
        readCharacter:"uuid" //蓝牙读取通道特征，使用者根据设备信息传入
    } */
    /* 当收到蓝牙数据，app -> 插件: 
    receiveMessageFromApp({ messageType: "receiveBlueInfo", messageBody: { deviceKey:"xxxxx", data: "xxx" } })
    */
    // setupBlueConnection(params = {}) {
    //     return this.blueToothModuleWrapper("setupBlueConnection", params)
    // },
    // 向蓝牙设备传输数据
    /* param:{
        deviceKey:"xxxxx", 
        data:"xxx" 
    } */
    // writeBlueInfo(params = {}) {
    //     return this.blueToothModuleWrapper("writeBlueInfo", params)
    // },
    //断开当前蓝牙连接
    /* 若是蓝牙意外断开, app -> 插件: 
       receiveMessageFromApp({ messageType: "blueConnectionBreak", messageBody: {} }) 
    */
    // disconnectBlueConnection(params = {}) {
    //     return this.blueToothModuleWrapper("disconnectBlueConnection", params)
    // },
    //**********蓝牙接口***************END


    //**********新蓝牙接口^5.9.0***************START
    singleBlueToothModuleWrapper: function singleBlueToothModuleWrapper(apiName, param) {
        var _this16 = this;

        return new Promise(function (resolve, reject) {
            if (_util2.default.toNum(weex.config.env.appVersion) >= _util2.default.toNum("5.9.0")) {
                singleBlueToothModule[apiName](JSON.stringify(param), function (resData) {
                    resolve(_this16.convertToJson(resData));
                }, function (error) {
                    reject(error);
                });
            } else {
                reject({ errorCode: -1, errorMsg: "version not support" });
            }
        });
    },

    //获取蓝牙开启状态
    /* return:
        当获取到蓝牙状态/蓝牙状态变更
        receiveMessageFromApp({messageType:"singleBlueStatus",messageBody:{status:1, //1表示蓝牙已打开，0：蓝牙关闭状态，2:：蓝牙正在重置，3：设备不支持蓝牙，4：蓝牙未授权}})
    */
    getBlueStatus: function getBlueStatus() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.singleBlueToothModuleWrapper("getBlueStatus", params);
    },

    //开始扫描蓝牙
    /*  param:{
        name:"midea_xx_xxxx",//选填
        mac:"xxxxxxxxxxxx",//选填
        duration: number //持续时间, 单位：秒}
        当扫描到的蓝牙设备（蓝牙信息），app-->插件:
        receiveMessageFromApp({messageType:"singleBlueScanStop",messageBody:{}})
     */
    startBlueScan: function startBlueScan() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.singleBlueToothModuleWrapper("startBlueScan", params);
    },

    //停止蓝牙扫描
    /* 当扫描结束（停止或超时），app -> 插件:
    receiveMessageFromApp({ messageType: "blueScanStop", messageBody: {} })
    */
    stopBlueScan: function stopBlueScan() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.singleBlueToothModuleWrapper("stopBlueScan", params);
    },

    //根据蓝牙信息建立蓝牙连接
    /* param:{
        name:"midea_xx_xxxx", //蓝牙名称
        token:"xxxx",//鉴权 长度32
        mac:"xxxx"//蓝牙mac地址
        applianceId:"xxx"//设备id
    } 
     失败回调:errorCode:-1, //-1:连接失败, -2:发现服务失败, -3:密钥协商失败, -4:token校验失败, -5:10s超时
    */
    setupBlueConnection: function setupBlueConnection() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.singleBlueToothModuleWrapper("setupBlueConnection", params);
    },


    //查询设备当前状态,连接之后立马查询

    /* param:{
        mac:"xxxx",//12位蓝牙Mac地址
        name:"midea_xx_xxxx",//蓝牙名称
        applianceId:"xxx"//设备id
    } 
    当收到蓝牙数据时，APP通知插件结果:
    receiveMessageFromApp({ messageType: "receiveSingleBlueLuaInfo", messageBody: { applianceId:"xxx", data: {luaKey1:"xxx",luaKey2:"xxx"}}})
    */
    queryBlueLuaStatus: function queryBlueLuaStatus() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.singleBlueToothModuleWrapper("queryBlueLuaStatus", params);
    },


    //查询设备当前状态,连接之后立马查询

    /* param:{
        mac:"xxxx",//12位蓝牙Mac地址
        name:"midea_xx_xxxx",//蓝牙名称
        applianceId:"xxx"
        data:{
            luaKey1:"xxx",
            luaKey2:"xxx"
        } //期望控制
    } 
    当收到蓝牙数据时，APP通知插件结果:
    receiveMessageFromApp({ messageType: "receiveSingleBlueLuaInfo", messageBody: { applianceId:"xxx", data: {luaKey1:"xxx",luaKey2:"xxx"}}})
    */
    sendBlueLuaRequest: function sendBlueLuaRequest() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.singleBlueToothModuleWrapper("sendBlueLuaRequest", params);
    },


    //断开当前蓝牙连接
    /* param:{
        mac:"xxxx",//12位蓝牙Mac地址
        name:"midea_xx_xxxx",//蓝牙名称
        } 
    若是蓝牙意外断开, app -> 插件: 
       receiveMessageFromApp({ messageType: "singleBlueConnectionBreak", messageBody: {mac:"xxxx", name:"midea_xx_xxxx"} }) 
    */
    disconnectBlueConnection: function disconnectBlueConnection() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.singleBlueToothModuleWrapper("disconnectBlueConnection", params);
    },


    //下载文件
    /* param:{
        mac:"xxxx",//12位蓝牙Mac地址
        name:"midea_xx_xxxx",//蓝牙名称
        } 
        result: {
            path:"xxx"//,下载文件本地路径
        }
    */
    downFile: function downFile() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.singleBlueToothModuleWrapper("downFile", params);
    },

    //查询当前固件指令
    /* param:{
            mac:"xxxx",//12位蓝牙Mac地址
            name:"midea_xx_xxxx",//蓝牙名称
        } 
    当收到蓝牙数据时，APP通知插件结果:
        receiveMessageFromApp({ messageType: "receiveSingleBlueFirmwareStatus", messageBody: {mac:"xxxx", name:"midea_xx_xxxx",data: {
            otaVersion:"xxx"//固件版本
            status:"",//固件状态
            revisonL:"xxx",//大版本号
            revisionS:""//小版本号
        }}}) 
    */
    readFirmwareStatus: function readFirmwareStatus() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.singleBlueToothModuleWrapper("readFirmwareStatus", params);
    },

    //开始ota升级
    /* param:{
            mac:"xxxx",//12位蓝牙Mac地址
            name:"midea_xx_xxxx",//蓝牙名称
            source:"xxx"//bin文件路径
        } 
    当收到蓝牙数据时，APP通知插件结果:
        receiveMessageFromApp({ messageType: "receiveSingleBlueOtaProcess", messageBody: {mac:"xxxx", name:"midea_xx_xxxx",data: {
            status:0//0:成功, -1:失败
            process:1//1:擦拭空间, 2:请求写入, 3:写数据（写数据进度看progress）, 4:crc校验, 5:升级指令
            progress：0.5//写bin文件进度,当process=3时使用
        }}}) 
    */
    startFirmwareOta: function startFirmwareOta() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.singleBlueToothModuleWrapper("startFirmwareOta", params);
    },

    //重启蓝牙模块
    /* param:{
        mac:"xxxx",//12位蓝牙Mac地址
        name:"midea_xx_xxxx",//蓝牙名称
        } 
    当收到蓝牙数据时，APP通知插件结果:
        receiveMessageFromApp({ messageType: "receiveSingleBlueRestart", messageBody: {mac:"xxxx", name:"midea_xx_xxxx",data: {
            status:0//0成功，-1失败,
        }}}) 
    */
    restartBlueDevice: function restartBlueDevice() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.singleBlueToothModuleWrapper("restartBlueDevice", params);
    },

    //**********蓝牙接口新蓝牙接口^5.9.0***************END


    //**********蓝牙MESH接口***************START
    blueToothMeshModuleWrapper: function blueToothMeshModuleWrapper(apiName, param) {
        var _this17 = this;

        return new Promise(function (resolve, reject) {
            blueToothMeshModule[apiName](JSON.stringify(param), function (resData) {
                resolve(_this17.convertToJson(resData));
            }, function (error) {
                reject(error);
            });
        });
    },

    //根据蓝牙信息建立蓝牙连接
    /* param:{
        mac:"xxx", //设备mac地址，可通getDeviceBlueMeshInfo接口获取
        ssid:"xxxxx", //设备ssid，可通getDeviceBlueMeshInfo接口获取
    } */
    /* 当收到蓝牙数据，app -> 插件: 
    receiveMessageFromApp({ messageType: "receiveBlueInfo", messageBody: { deviceKey:"xxxxx", data: "xxx" } })
    */
    setupBlueMeshConnection: function setupBlueMeshConnection() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.blueToothMeshModuleWrapper("setupBlueMeshConnection", params);
    },

    //断开当前蓝牙连接
    /* 若是蓝牙意外断开, app -> 插件: 
       receiveMessageFromApp({ messageType: "blueConnectionBreak", messageBody: {} }) 
    */
    disconnectBlueMeshConnection: function disconnectBlueMeshConnection() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.blueToothMeshModuleWrapper("disconnectBlueMeshConnection", params);
    },

    //获取当前家庭的所有Mesh设备的信息
    /* param:{ deviceType: 品类码 }
       result:{status：0, //0: 执行成功, 1:执行失败, name:"xxx", deviceKey:"xxxxx"}
    */
    getDeviceBlueMeshListInfo: function getDeviceBlueMeshListInfo() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.blueToothModuleWrapper("getDeviceBlueMeshListInfo", params);
    },

    // 向蓝牙Mesh发送控制指令
    /* param:{
        destAddress: xxx  //目标控制地址  ，可为 单播地址，群播地址
        name:xxx //例如 GenericOnOff 、GenericLevel 、LightCtlTemperature
        params :{     // name字段的不同，params需要不同的数据，例如  ,
        onoff:  xxx // 0 或1 ,name 为 GenericOnOff 需要  0或者1
        level:    xxx // GenericLevel 需要 0~100 之类的数值
        temperature:  xxxx //  LightCtlTemperature 才会需要的温度数值
        deltaUV: xxxx // LightCtlTemperature 才会需要
    } */
    sendBlueMeshControlMessage: function sendBlueMeshControlMessage() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.blueToothModuleWrapper("sendBlueMeshControlMessage", params);
    },

    // 蓝牙Mesh增加群订阅
    /*  ps1:一个mesh node element 可以订阅多个群地址
        ps2:一个群地址可以配置多个modelNumberId，以响应不同的控制消息
    param:{
        groupAddress:xxx  // 组播地址  这个理论上是 事业部应用服务器从 iot服务器上申请分配，建议从0xD000开始分配
        deviceAddress: xxx  //mesh node 的 element 单播地址
        modelNumberId:xxx // 控制模式的id , 例如  GenericOnOff 组播，需要传入 0x1000 ,之后就可以通过 sendBlueMeshControlMessage {name : “GenericOnOff”  群控制设备开关 }
    } */
    addBlueMeshModelSubscription: function addBlueMeshModelSubscription() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.blueToothModuleWrapper("addBlueMeshModelSubscription", params);
    },

    // 蓝牙Mesh取消群订阅
    /* param:{
        groupAddress:xxx  // 组播地址  这个理论上是 事业部应用服务器从 iot服务器上申请分配，建议从0xD000开始分配
        deviceAddress: xxx  //mesh node 的 element 单播地址
        modelNumberId:xxx // 控制模式的id , 例如  GenericOnOff 组播，需要传入 0x1000 ,之后就可以通过 sendBlueMeshControlMessage {name : “GenericOnOff”  群控制设备开关 }
    } */
    deleteBlueMeshModelSubscription: function deleteBlueMeshModelSubscription() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.blueToothModuleWrapper("deleteBlueMeshModelSubscription", params);
    },

    //**********蓝牙接口***************END


    //**********思必驰语音识别接口***************START
    // 启动语音监听
    /*
    param为对象:
        {
        auto: true/false，是否启动后马上监听还是处于暂停状态，默认是true (^5.10.0)
        mode: local/online, //设置是APP本地词库识别还是网络在线识别，默认为local本地词库识别 (^5.10.0)
        deviceType: "xxxx", //设备类型，如0xAC，可选项，当需要控制指定设备时填写 (^5.10.0)
        deviceId: "xxxxx", //设备ID，可选项，可选项，当需要控制指定设备时填写 (^5.10.0)
        }
        当收到语音识别数据，app -> 插件: 
        receiveMessageFromApp({ messageType: "aiSpeechNotification", messageBody: {key:"xxxxxxxx"} }) //xxxxxx为匹配到的热词
         当收到语音执行结果，app -> 插件: 
        receiveMessageFromApp({ messageType: "aiSpeechAcyionResult", messageBody: {...} }) //messageBody为思必驰执行返回结果
    */
    startSpeechMonitor: function startSpeechMonitor() {
        var _this18 = this;

        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return new Promise(function (resolve, reject) {
            aiSpeechModule["startSpeechMonitor"](JSON.stringify(params), function (resData) {
                resolve(_this18.convertToJson(resData));
            }, function (error) {
                reject(error);
            });
        });
    },
    stopSpeechMonitor: function stopSpeechMonitor() {
        var _this19 = this;

        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return new Promise(function (resolve, reject) {
            aiSpeechModule["stopSpeechMonitor"](JSON.stringify(params), function (resData) {
                resolve(_this19.convertToJson(resData));
            }, function (error) {
                reject(error);
            });
        });
    },

    /* (^5.10.0) 恢复监听。在暂停状态下可以恢复。 */
    resumeSpeechMonitor: function resumeSpeechMonitor() {
        var _this20 = this;

        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return new Promise(function (resolve, reject) {
            aiSpeechModule["resumeSpeechMonitor"](JSON.stringify(params), function (resData) {
                resolve(_this20.convertToJson(resData));
            }, function (error) {
                reject(error);
            });
        });
    },

    /* (^5.10.0)暂停监听。在监听状态下可以停止。 */
    pauseSpeechMonitor: function pauseSpeechMonitor() {
        var _this21 = this;

        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return new Promise(function (resolve, reject) {
            aiSpeechModule["pauseSpeechMonitor"](JSON.stringify(params), function (resData) {
                resolve(_this21.convertToJson(resData));
            }, function (error) {
                reject(error);
            });
        });
    },

    /* (^5.10.0)播报文字。
        params为对象:
        {
            content: string，//需要语音播报的句子
        }
    */
    textToSpeech: function textToSpeech() {
        var _this22 = this;

        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return new Promise(function (resolve, reject) {
            aiSpeechModule["textToSpeech"](JSON.stringify(params), function (resData) {
                resolve(_this22.convertToJson(resData));
            }, function (error) {
                reject(error);
            });
        });
    },
    getLanguage: function getLanguage() {
        var params = {
            operation: 'getLanguage'
        };
        return this.commandInterfaceWrapper(params);
    }

    //**********思必驰语音识别接口***************START

};

/***/ }),

/***/ 11:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
// ************ push 相关 *************
var util = {
    dateFormat: function dateFormat(dateTime, fmt) {
        // 对Date的扩展，将 Date 转化为指定格式的String
        // 月(M)、日(d)、小时(h)、分(m)、秒(s)、季度(q) 可以用 1-2 个占位符， 
        // 年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字) 
        // 例子： 
        // dateFormat(new Date(), "yyyy-MM-dd hh:mm:ss.S") ==> 2006-07-02 08:09:04.423 
        // dateFormat(new Date(), "yyyy-M-d h:m:s.S")      ==> 2006-7-2 8:9:4.18 
        if (!dateTime) {
            return dateTime;
        }
        if (typeof dateTime == 'string' && !isNaN(dateTime)) {
            dateTime = +dateTime;
        }
        dateTime = new Date(dateTime);
        var o = {
            "M+": dateTime.getMonth() + 1, //月份 
            "d+": dateTime.getDate(), //日 
            "h+": dateTime.getHours(), //小时 
            "m+": dateTime.getMinutes(), //分 
            "s+": dateTime.getSeconds(), //秒 
            "q+": Math.floor((dateTime.getMonth() + 3) / 3), //季度 
            "S": dateTime.getMilliseconds() //毫秒 
        };
        if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (dateTime.getFullYear() + "").substr(4 - RegExp.$1.length));
        for (var k in o) {
            if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ("00" + o[k]).substr(("" + o[k]).length));
        }return fmt;
    },
    getParameters: function getParameters(url, key) {
        var theRequest = new Object();
        if (url.indexOf("?") != -1) {
            var queryString = url.substr(url.indexOf("?") + 1);
            var strs = queryString.split("&");
            for (var i = 0; i < strs.length; i++) {
                theRequest[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);
            }
        }
        return key ? theRequest[key] : theRequest;
    },
    toNum: function toNum(a) {
        var a = a.toString();
        var c = a.split('.');
        var num_place = ["", "0", "00", "000", "0000"],
            r = num_place.reverse();
        for (var i = 0; i < c.length; i++) {
            var len = c[i].length;
            c[i] = r[len] + c[i];
        }
        var res = c.join('');
        return res;
    }
};

exports.default = util;

/***/ }),

/***/ 12:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _nativeService = __webpack_require__(1);

var _nativeService2 = _interopRequireDefault(_nativeService);

var _debugUtil = __webpack_require__(5);

var _debugUtil2 = _interopRequireDefault(_debugUtil);

var _header = __webpack_require__(9);

var _header2 = _interopRequireDefault(_header);

var _Process = __webpack_require__(4);

var _Process2 = _interopRequireDefault(_Process);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var appDataTemplate = {};

var bundleUrl = weex.config.bundleUrl;
var match = /.*\/(T0x.*)\//g.exec(bundleUrl);
var plugin_name = match ? match[1] : 'common'; //appConfig.plugin_name
var srcFileName = bundleUrl.substring(bundleUrl.lastIndexOf('/') + 1, bundleUrl.lastIndexOf('.js'));

var globalEvent = weex.requireModule('globalEvent');
var storage = weex.requireModule('storage');

var appDataChannel = new BroadcastChannel(plugin_name + 'appData');
var pushDataChannel = new BroadcastChannel(plugin_name + 'pushData');

// Vue.config.errorHandler = function (err, vm, info) {
//     console.error(err)
// }

Vue.config.errorHandler = function (err, vm, info) {
    var errObj = {
        path: weex.config.bundleUrl,
        errDesc: err,
        errDetail: JSON.stringify(err),
        info: info
    };
    var errMsg = '\u6267\u884C\u65F6\u9519\u8BEF\u4FE1\u606F:\xA0\n' + JSON.stringify(errObj, null, 4);
    console.log(errMsg);
    // (weex.config.bundleUrl.indexOf('http') !== -1) && (nativeService.alert(errMsg));
    // nativeService.alert(errMsg)
};

exports.default = {
    components: {
        mideaHeader: _header2.default
    },
    data: function data() {
        return {
            title: '',
            isIos: weex.config.env.platform == 'iOS' ? true : false,
            srcFileName: srcFileName,
            pluginVersion: '1.0.0',
            pluginName: plugin_name,
            isMixinCreated: true,
            isNavigating: false,
            appDataKey: plugin_name + 'appData',
            appDataChannel: appDataChannel,
            pushKey: 'receiveMessage',
            pushDataChannel: pushDataChannel,

            appData: appDataTemplate,
            langCode: 'en'
        };
    },
    computed: {
        pageHeight: function pageHeight() {
            return 750 / weex.config.env.deviceWidth * weex.config.env.deviceHeight;
        },

        isImmersion: function isImmersion() {
            var result = true;
            if (weex.config.env.isImmersion == "false") {
                result = false;
            }
            return result;
        },
        isipx: function isipx() {
            return weex && (weex.config.env.deviceModel === 'iPhone10,3' || weex.config.env.deviceModel === 'iPhone10,6' //iphoneX
            || weex.config.env.deviceModel === 'iPhone11,8' //iPhone XR
            || weex.config.env.deviceModel === 'iPhone11,2' //iPhone XS
            || weex.config.env.deviceModel === 'iPhone11,4' || weex.config.env.deviceModel === 'iPhone11,6' //iPhone XS Max
            || weex.config.env.deviceModel === 'iPhone12,3' //iPhone11 pro
            );
        },
        statusBarHeight: function statusBarHeight() {
            var result = '20';
            if (weex.config.env.statusBarHeight) {
                if (weex.config.env.platform == 'iOS') {
                    //iOS使用pt为单位
                    result = weex.config.env.statusBarHeight;
                } else {
                    //安卓使用px为单位
                    result = weex.config.env.statusBarHeight / weex.config.env.scale;
                }
            }
            return result;
        },
        headerStyleObj: function headerStyleObj() {
            var result = void 0,
                isImmersion = void 0;
            if (this.isImmersion != null) {
                isImmersion = this.isImmersion;
            } else {
                isImmersion = weex.config.env.isImmersion == "false" ? false : true;
            }
            if (isImmersion) {
                //全屏显示，weex自行处理状态栏高度
                result = _extends({
                    backgroundColor: 'rgba(255,255,255,' + this.titleOpacity + ')',
                    paddingTop: this.statusBarHeight + 'wx',
                    height: this.titleOpacity !== 0 && this.name.length > 4 ? +this.statusBarHeight + 54 + 'wx' : +this.statusBarHeight + 44 + 'wx'
                }, this.custStyleObj);
            } else {
                //非全屏显示，APP已经处理状态栏高度
                result = _extends({
                    backgroundColor: 'rgba(255,255,255,' + this.titleOpacity + ')',
                    height: '44wx'
                }, this.custStyleObj);
            }

            return result;
        }
    },
    methods: {
        viewappear: function viewappear() {},
        viewdisappear: function viewdisappear() {
            _debugUtil2.default.resetDebugLog();
        },

        getParameterByName: function getParameterByName(name) {
            var url = this.$getConfig().bundleUrl;
            name = name.replace(/[\[\]]/g, "\\$&");
            var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
                results = regex.exec(url);
            if (!results) return null;
            if (!results[2]) return '';
            return decodeURIComponent(results[2].replace(/\+/g, " "));
        },
        goTo: function goTo(pageName) {
            var _this = this;

            var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
            var params = arguments[2];

            if (!this.isNavigating) {
                this.isNavigating = true;
                // 离开时同步全局应用数据
                _nativeService2.default.setItem(this.appDataKey, this.appData, function () {
                    //跳转页面
                    var path = pageName + ".js";
                    if (params) {
                        path += '?' + Object.keys(params).map(function (k) {
                            return encodeURIComponent(k) + '=' + encodeURIComponent(params[k]);
                        }).join('&');
                    }
                    options.viewTag = pageName;
                    _nativeService2.default.goTo(path, options);
                    setTimeout(function () {
                        _this.isNavigating = false;
                    }, 500);
                });
            }
        },
        back: function back() {
            //返回上一页
            _nativeService2.default.goBack();
        },
        exit: function exit() {
            _nativeService2.default.backToNative();
        },
        getAppData: function getAppData() {
            var _this2 = this;

            //获取全局应用数据
            return new Promise(function (resolve, reject) {
                _nativeService2.default.getItem(_this2.appDataKey, function (resp) {
                    var data = void 0;
                    if (resp.result == 'success') {
                        data = resp.data;
                        if (typeof data == 'string') {
                            try {
                                data = JSON.parse(data);
                            } catch (error) {}
                        }
                    }
                    if (!data) {
                        data = _this2.appData;
                    }
                    resolve(data);
                });
            });
        },
        updateAppData: function updateAppData(data) {
            //更新全局应用数据
            this.appData = Object.assign(this.appData, data);
            appDataChannel.postMessage(this.appData);
        },
        resetAppData: function resetAppData() {
            var _this3 = this;

            //重置全局应用数据
            return new Promise(function (resolve, reject) {
                _nativeService2.default.removeItem(_this3.appDataKey, function (resp) {
                    _this3.appData = JSON.parse(JSON.stringify(appDataTemplate));
                    appDataChannel.postMessage(_this3.appData);
                    resolve();
                });
            });
        },
        handleNotification: function handleNotification(data) {
            //处理推送消息
            _debugUtil2.default.debugLog(srcFileName, this.pushKey, data);
        },
        reload: function reload() {
            weex.config.bundleUrl.indexOf('http') !== -1 && _nativeService2.default.reload();
        }
    },
    created: function created() {
        var _this4 = this;

        // nativeService.alert(weex.config.bundleUrl.indexOf('http') !== -1);

        _Process2.default.initLangEnv(function (langCode) {
            _this4.langCode = langCode;
        });

        console.log("created");
        //若isMixinCreated为false, 则不继承
        if (!this.isMixinCreated) return;

        //Debug Log相关信息
        _debugUtil2.default.isEnableDebugInfo = false; //开启关闭debuglog功能
        _debugUtil2.default.debugLog("@@@@@@ " + this.title + "(" + plugin_name + "-" + srcFileName + ") @@@@@@");

        //监听全局推送(native->weex)
        globalEvent.addEventListener(this.pushKey, function (data) {
            _debugUtil2.default.debugLog(_this4.title + "=>" + _this4.pushKey + ": " + data);
            //触发本页面处理事件
            _this4.handleNotification(data || {});
            //触发其他页面处理事件
            pushDataChannel.postMessage(data);
        });
        //监听全局推送通信渠道(weex->weex)
        pushDataChannel.onmessage = function (event) {
            _this4.handleNotification(event.data || {});
        };

        //监听全局应用数据通信渠道(weex->weex)
        appDataChannel.onmessage = function (event) {
            _this4.appData = event.data || {};
        };
        //页面创建时获取全局应用数据
        this.getAppData().then(function (data) {
            _this4.appData = data || {};
        });
    }
};

/***/ }),

/***/ 13:
/***/ (function(module, exports) {

module.exports = {
  "box": {
    "width": 750,
    "display": "inline-flex",
    "flexDirection": "row",
    "flexWrap": "nowrap",
    "justifyContent": "space-between",
    "alignItems": "center"
  },
  "immersion": {
    "paddingTop": 40,
    "height": 128
  },
  "immersion-ipx": {
    "paddingTop": 88,
    "height": 176
  },
  "header-title": {
    "flex": 1,
    "fontFamily": "PingFangSC-Medium",
    "fontWeight": "600",
    "width": 574,
    "lines": 1,
    "textOverflow": "ellipsis",
    "textAlign": "center"
  },
  "header-left-image-wrapper": {
    "width": 88,
    "height": 88,
    "display": "flex",
    "justifyContent": "center",
    "alignItems": "flex-start",
    "paddingLeft": 10
  },
  "header-left-image": {
    "height": 58,
    "width": 58
  },
  "header-right-image-wrapper": {
    "width": 88,
    "height": 88,
    "display": "flex",
    "justifyContent": "center",
    "alignItems": "flex-end",
    "paddingRight": 32
  },
  "header-right-image": {
    "height": 44,
    "width": 44
  },
  "header-right": {
    "position": "absolute",
    "right": 0,
    "height": 88,
    "display": "flex",
    "justifyContent": "center",
    "alignItems": "center"
  },
  "header-right-text": {
    "fontFamily": "PingFangSC-Regular",
    "fontSize": 28,
    "paddingLeft": 20,
    "paddingRight": 32,
    "textAlign": "right"
  }
}

/***/ }),

/***/ 14:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var _nativeService = __webpack_require__(1);

var _nativeService2 = _interopRequireDefault(_nativeService);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    props: {
        title: {
            type: String,
            default: ''
        },
        bgColor: {
            type: String,
            default: '#ffffff'
        },
        fontSize: {
            type: String,
            default: '32'
        },
        titleText: {
            type: String,
            default: '#000000'
        },
        isImmersion: {
            type: Boolean,
            default: null
        },
        leftImg: {
            type: String,
            default: './img/header/public_ic_back@3x.png'
        },
        rightImg: {
            type: String,
            default: './img/header/me_ic_set@3x.png'
        },
        showLeftImg: {
            type: Boolean,
            default: true
        },
        showRightImg: {
            type: Boolean,
            default: false
        },
        showRightText: {
            type: Boolean,
            default: false
        },
        rightText: {
            type: String,
            default: ''
        },
        rightColor: {
            type: String,
            default: '#666666'
        },
        custStyleObj: {
            type: Object,
            default: function _default() {
                return {};
            }
        }
    },
    computed: {
        isipx: function isipx() {
            return weex && (weex.config.env.deviceModel === 'iPhone10,3' || weex.config.env.deviceModel === 'iPhone10,6' //iphoneX
            || weex.config.env.deviceModel === 'iPhone11,8' //iPhone XR
            || weex.config.env.deviceModel === 'iPhone11,2' //iPhone XS
            || weex.config.env.deviceModel === 'iPhone11,4' || weex.config.env.deviceModel === 'iPhone11,6' //iPhone XS Max
            || weex.config.env.deviceModel === 'iPhone12,3' //iPhone11 pro
            );
        },
        statusBarHeight: function statusBarHeight() {
            var result = '20';
            if (weex.config.env.statusBarHeight) {
                if (weex.config.env.platform == 'iOS') {
                    //iOS使用pt为单位
                    result = weex.config.env.statusBarHeight;
                } else {
                    //安卓使用px为单位
                    result = weex.config.env.statusBarHeight / weex.config.env.scale;
                }
            }
            return result;
        },
        headerStyleObj: function headerStyleObj() {
            var result = void 0,
                isImmersion = void 0;
            if (this.isImmersion != null) {
                isImmersion = this.isImmersion;
            } else {
                isImmersion = weex.config.env.isImmersion == "false" ? false : true;
            }
            if (isImmersion) {
                //全屏显示，weex自行处理状态栏高度
                result = _extends({
                    backgroundColor: this.bgColor,
                    paddingTop: this.statusBarHeight + 'wx',
                    height: +this.statusBarHeight + 44 + 'wx'
                }, this.custStyleObj);
            } else {
                //非全屏显示，APP已经处理状态栏高度
                result = _extends({
                    backgroundColor: this.bgColor,
                    height: '44wx'
                }, this.custStyleObj);
            }

            return result;
        }
    },
    data: function data() {
        return {};
    },

    methods: {
        leftImgClick: function leftImgClick() {
            if (!this.showLeftImg) {
                return;
            }
            this.$emit('leftImgClick');
        },
        rightImgClick: function rightImgClick() {
            if (!this.showRightImg) {
                return;
            }
            this.$emit('rightImgClick');
        },
        rightTextClick: function rightTextClick() {
            if (!this.showRightText) {
                return;
            }
            this.$emit('rightTextClick');
        },
        headerClick: function headerClick() {
            this.$emit('headerClick');
        }
    }
};

/***/ }),

/***/ 15:
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: ["wrapper"],
    staticStyle: {
      width: "750px"
    }
  }, [_c('div', {
    staticClass: ["box"],
    style: _vm.headerStyleObj
  }, [_c('div', {
    staticClass: ["header-left-image-wrapper"],
    on: {
      "click": _vm.leftImgClick
    }
  }, [(_vm.showLeftImg) ? _c('image', {
    staticClass: ["header-left-image"],
    attrs: {
      "src": _vm.leftImg
    }
  }) : _vm._e()]), _c('div', {
    on: {
      "click": _vm.headerClick
    }
  }, [_c('text', {
    staticClass: ["header-title"],
    style: {
      color: _vm.titleText,
      fontSize: _vm.fontSize + 'px'
    }
  }, [_vm._v(_vm._s(_vm.title))])]), _c('div', {
    staticClass: ["header-right-image-wrapper"],
    on: {
      "click": _vm.rightImgClick
    }
  }, [_vm._t("rightContent", [(_vm.showRightImg) ? _c('image', {
    staticClass: ["header-right-image"],
    attrs: {
      "src": _vm.rightImg
    }
  }) : _vm._e()])], 2), (_vm.showRightText) ? _c('div', {
    staticClass: ["header-right"],
    on: {
      "click": _vm.rightTextClick
    }
  }, [_c('text', {
    staticClass: ["header-right-text"],
    style: {
      color: _vm.rightColor
    }
  }, [_vm._v(_vm._s(_vm.rightText))])]) : _vm._e(), _vm._t("customerContent")], 2)])
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),

/***/ 16:
/***/ (function(module, exports) {

module.exports = {"login":{"en":"Login","ch":"登录","fr":"Connexion","ja":"ログイン","it":"Accesso","sp":"iniciar sesión","pt":"Conecte-se","de":"Anmeldung","ru":"войти","vi":"Đăng nhập","th":"ล็อกอิน","id":"Masuk","zh-tw":"登入","ar":"تسجيل الدخول"},"device_is_power_off":{"en":"Device is power off","ch":"设备已关机","fr":"L'appareil est éteint","ja":"デバイスの電源が切れています。","it":"L'impianto è spento","sp":"El dispositivo está apagado","pt":"Dispositivo desligado","de":"Gerät ist ausgeschaltet","ru":"Устройство выключено","vi":"Thiết bị đã bị tắt","th":"อุปกรณ์ปิดอยู่","id":"Perangkat dimatikan","zh-tw":"設備已關機","ar":"تسجيل الدخول"},"ECO_can_not_be_used_under_current_mode":{"en":"ECO is not available in current mode","ch":"ECO无法在当前模式下使用","fr":"Eco ne peut pas être utilisé en mode actuel","ja":"現在のモードではECO は使用できません。","it":"Eco non può essere utilizzato nella modalità corrente","sp":"Eco no se puede utilizar en el modo actual","pt":"Eco não pode ser utilizado no modo actual","de":"Eco kann im aktuellen Modus nicht benutzt werden","ru":"ЭКО нельзя использовать в текущем режиме","vi":"Không thể sử dụng ECO ở chế độ hiện tại","th":"ไม่สามารถใช้ ECO ได้ในโหมดปัจจุบัน","id":"ECO tidak bisa digunakan dalam mode ini","zh-tw":"ECO無法在當前模式下使用","ar":"لا يمكن استخدام وظيفة ايكو تحت الوضع الحالي"},"Turbo_can_not_be_used_under_current_mode":{"en":"Boost is not available in current mode","ch":"强劲无法在当前模式下使用","fr":"Boost n'est pas pris en charge dans ce mode","ja":"このモードではターボはサポートされていません。","it":"Boost non è supportato in questa modalità.","sp":"Boost no es soportado en este modo","pt":"Boost não é suportado neste modo","de":"Boost ist in diesem Modus nicht unterstützt.","ru":"стимулировать нельзя использовать в текущем режиме","vi":"Chế độ Tăng cường không được hỗ trợ","th":"ไม่รองรับเทอร์โบในโหมดนี้","id":"Boost tidak didukung dalam mode ini","zh-tw":"強勁無法在當前模式下使用","ar":"وظيفة تيربو غير مدعومة في هذا الوضع"},"ElecHeat_can_not_be_used_under_current_mode":{"en":"ElecHeat is not available in current mode","ch":"电辅热无法在当前模式下使用","fr":"ElecHeat ne peut pas être utilisé sous le mode actuel","ja":"現在のモードでは、ElecHeat は使用できません。","it":"ElecHeat non può esssere usato nella modalità corrente","sp":"La calefacción eléctrica no se puede utilizar en el modo actual","pt":"O ElecHeat não pode ser usado no modo atual","de":"ElecHeat is not available in current mode","ru":"ЭлекОбогрев нельзя использовать в текущем режиме","vi":"Không thể sử dụng ElecHeat ở chế độ hiện tại","th":"ไม่สามารถใช้ ElecHeat ได้ในโหมดปัจจุบัน","id":"ElecHeat tidak bisa digunakan dalam mode ini","zh-tw":"電輔熱無法在當前模式下使用","ar":"لا يمكن استخدام وظيفة التدفئة الكهربائية تحت الوضع الحالي"},"Dry_can_not_be_used_under_current_mode":{"en":"This function is not available in current mode","ch":"此功能无法在当前模式下使用","fr":"Cette fonction ne peut pas être utilisée sous le mode actuel","ja":"現在のモードでは、ドライは使用できません。","it":"Questa funzione non può essere utilizzata nella modalità corrente","sp":"Esta función no se puede usar en el modo actual","pt":"Esta função não pode ser usada no modo atual","de":"Diese Funktion kann im aktuellen Modus nicht verwendet werden ","ru":"Данная функция нельзя использовать в текущем режиме","vi":"Không thể sử dụng chức năng này trong chế độ hiện tại","th":"ไม่สามารถใช้ฟังก์ชันนี้ได้ในโหมดปัจจุบัน","id":"Fungsi ini tidak bisa digunakan dalam mode ini","zh-tw":"此功能無法在當前模式下使用","ar":"لا يمكن استخدام هذه الوظيفة تحت الوضع الحالي"},"SetTemperature_can_not_be_used_under_current_mode":{"en":"Temperature can't be changed under Fan mode","ch":"温度设置无法在当前模式下使用","fr":"La température ne peut pas être modifiée en mode ventilateur","ja":"SetTemperature は、現在のモードでは使用できません。","it":"La temperatura non può essere cambiata in modalità Ventilatore","sp":"La temperatura no se puede cambiar en el modo Ventilador","pt":"Temperatura não pode ser alterada no modo de Ventoínha","de":"Temperatur kann im Lüfter-Modus nicht geändert werden","ru":"Температура нельзя использовать в текущем режиме","vi":"Không thể thay đổi nhiệt độ trong chế độ hiện tại","th":"ไม่สามารถเปลี่ยนอุณหภูมิได้หากอยู่ในโหมดพัดลม","id":"Suhu tidak bisa diganti dalam mode Kipas","zh-tw":"溫度設定無法在當前模式下使用","ar":"لا يمكن تغيير درجة الحرارة تحت وضع المروحة"},"Fan Speed_can_not_be_used_under_current_mode":{"en":"Fan Speed is not available in current mode","ch":"风扇设置无法在当前模式下使用","fr":"La vitesse du ventilateur ne peut pas être utilisée en mode actuel","ja":"現在のモードでは、ファンスピードは使用できません。","it":"La velocità della ventola non può essere utilizzata nella modalità corrente","sp":"La velocidad del ventilador no se puede usar en el modo actual","pt":"A velocidade do ventilador não pode ser usada no modo atual","de":"Die Lüftergeschwindigkeit kann im aktuellen Modus nicht verwendet werden","ru":"Скорость вентилятора нельзя использовать в текущем режиме","vi":"Không thể sử dụng Tốc độ Quạt trong chế độ hiện tại","th":"ไม่สามารถใช้ความเร็วพัดลมได้ในโหมดปัจจุบัน","id":"Kecepatan Kipas tidak bisa digunakan dalam mode ini","zh-tw":"風速設置無法在當前模式下使用","ar":"لا يمكن استخدام سرعة المروحة تحت الوضع الحالي"},"Please_clean_the_filter":{"en":"Please clean the filter","ch":"请清洗滤网","fr":"Veuillez nettoyer le filtre","ja":"フィルターを清掃してください。","it":"Pulire il filtro","sp":"Por favor, limpie el filtro","pt":"Limpe o filtro","de":"Bitte den Filter reinigen","ru":"Очистите фильтр","vi":"Hãy vệ sinh bộ lọc","th":"โปรดทำความสะอาดไส้กรอง","id":"Mohon bersihkan filter","zh-tw":"請清洗濾網","ar":"يرجى تنظيف الفلتر"},"Please_replace_the_filter":{"en":"Please replace the filter","ch":"请替换滤网","fr":"Veuillez remplacer le filter","ja":"フィルターを交換してください","it":"Si prega di sostituire il filtro","sp":"Por favor, sustituya el filtro","pt":"Favor substituir o filtro","de":"Bitte ersetzen Sie den Filter","ru":"Пожалуйста, замените фильтр","vi":"Vui lòng thay bộ lọc","th":"กรุณาเปลี่ยนตัวกรอง","id":"Sila tukar penapis","zh-tw":"請替換濾網","ar":"يرجى استبدال المرشح"},"Outdoor":{"en":"Outdoor","ch":"室外","fr":"Extérieur","ja":"屋外","it":"Esterna","sp":"Exterior","pt":"Exterior","de":"Außen","ru":"На улице","vi":"Ngoài trời","th":"กลางแจ้ง","id":"Luar Ruangan","zh-tw":"室外","ar":"خارجي"},"Indoor":{"en":"Indoor","ch":"室内","fr":"Intérieur","ja":"室内","it":"Interno","sp":"Interior","pt":"Interior","de":"Innen","ru":"В помещении","vi":"Trong nhà","th":"ในร่ม","id":"Dalam Ruangan","zh-tw":"室內","ar":"داخلي"},"Air Conditioner":{"en":"Air Conditioner","ch":"空调","fr":"Climatisation","ja":"クーラー","it":"Condizionatore d'aria","sp":"Aire acondicionado","pt":"Aire acondicionado","de":"Klimaanlage","ru":"Бытовой кондиционер","vi":"Máy lạnh","th":"เครื่องปรับอากาศ","id":"Pengkondisi Udara","zh-tw":"空調","ar":"تكييف الهوا"},"Fan_Speed":{"en":"Fan Speed","ch":"风速设置","fr":"Vitesse du ventilateur","ja":"ファンの速度","it":"Vel. Ventola","sp":"Veloc. Vent.","pt":"Vel.Ventoín","de":"Lüfterdrehzahl","ru":"Скорость вентилятора","vi":"Tốc độ Quạt ","th":"ความเร็วพัดลม","id":"Kecepatan Kipas","zh-tw":"風速設置","ar":"سرعة المروحة"},"Refresh successed":{"en":"Refresh successed","ch":"刷新成功","fr":"Actualisation réussie","ja":"リフレッシュに成功","it":"Aggiornamento riuscito","sp":"Actualización exitosa","pt":"Atualização bem-sucedida","de":"Aktualisierung erfolgreich","ru":"Обновление успешно выполнено","vi":"Làm sạch thành công","th":"รีเฟรชเรียบร้อยแล้ว","id":"Berhasil Menyegarkan","zh-tw":"整理成功","ar":"نجح التحديث"},"Function":{"en":"Function","ch":"功能","fr":"Fonction","ja":"機能","it":"Funzione","sp":"Función","pt":"Função","de":"Funktion","ru":"Функция","vi":"Chức năng","th":"ฟังก์ชัน","id":"Fungsi","zh-tw":"功能","ar":"الوظيفة"},"Units":{"en":"Units","ch":"单位","fr":"Unités","ja":"ユニット","it":"Unità","sp":"Unidades","pt":"Unidades","de":"Einheiten","ru":"Единицы","vi":"Đơn vị","th":"หน่วย","id":"Unit","zh-tw":"單位","ar":"الوحدات"},"Schedule":{"en":"Schedule","ch":"周定时","fr":"l'horaire","ja":"スケジュール","it":"Orari","sp":"Horarios","pt":"Cronograma","de":"Zeitpläne","ru":"График","vi":"Lịch","th":"กำหนดการ","id":"Jadwal","zh-tw":"周定時","ar":"الجدول الزمني"},"Check":{"en":"Check","ch":"故障检测","fr":"Vérifier","ja":"チェック","it":"Verifica","sp":"Verificar","pt":"Verificar","de":"Prüfen","ru":"Проверить","vi":"Kiểm tra","th":"ตรวจสอบ","id":"Periksa","zh-tw":"故障檢測","ar":"الفحص"},"About device":{"en":"About device","ch":"设备信息","fr":"A propos de l'appareil","ja":"デバイスについて","it":"Informazioni sul dispositivo","sp":"Acerca del dispositivo","pt":"Sobre o dispositivo","de":"Über das Gerät","ru":"Об устройстве","vi":"Thông tin thiết bị","th":"เกี่ยวกับอุปกรณ์","id":"Mengenai Perangkat","zh-tw":"裝置訊息","ar":"حول الجهاز"},"Cool":{"en":"Cool","ch":"制冷","fr":"Cool","ja":"クール","it":"Freddo","sp":"Enfriar","pt":"Frio","de":"Cool","ru":"Охлаждение","vi":"Làm lạnh","th":"ทำความเย็น","id":"Sejuk","zh-tw":"製冷","ar":"تبريد"},"Dry":{"en":"Dry","ch":"干燥","fr":"Sec","ja":"ドライ","it":"Asciutto","sp":"Seco","pt":"Seco","de":"Trocken","ru":"Осушение","vi":"Hút ẩm","th":"เป่าแห้ง","id":"Kering","zh-tw":"乾燥","ar":"تجفيف"},"Heat":{"en":"Heat","ch":"加热","fr":"Chaleur","ja":"ヒート","it":"Calore","sp":"Calefacción","pt":"Calor","de":"Hitze","ru":"Обогрев","vi":"Sưởi","th":"ทำความร้อน","id":"Panas","zh-tw":"加熱","ar":"تدفئة"},"Fan":{"en":"Fan","ch":"送风","fr":"Ventilateur","ja":"ファン","it":"Ventola","sp":"Ventilador","pt":"Ventoínha","de":"Ventilator","ru":"Скорость","vi":"Quạt","th":"พัดลม","id":"Kipas","zh-tw":"送風","ar":"المروحة"},"Cool, Dry & Heat Mode":{"en":"Cooling & Heating","ch":"制冷和制热","fr":"Refroidissement et Chauffage","ja":"クール、ドライ、ヒートモード","it":"Raffreddamento e riscaldamento","sp":"Refrigeración y Calefacción","pt":"Arrefecimento e Aquecimento","de":"Kühlen und Heizen","ru":"Режим охлаждения, осушения и обогрева","vi":"Làm mát và Sưởi","th":"ทำความเย็นและทำความร้อน","id":"Pendinginan & Pemanasan","zh-tw":"製冷和制熱","ar":"التبريد والتدفئة"},"Auto,Cool,Dry,Heat,Fan":{"en":"Auto,Cool,Dry,Heat,Fan","ch":"自动、制冷、干燥、制热、送风","fr":"Auto, Cool, Sec, Chaleur, Ventilateur","ja":"オート、クール、ドライ、ヒート、ファン","it":"Automatico, Raffreddamento, Essiccazione, Riscaldamento, Ventilatore","sp":"Auto, Frío, Seco, Calor, Ventilador","pt":"Auto, Frio, Seco, Calor, Ventoínha","de":"Auto,Kühlen,Trocknen,Heizen,Lüfter","ru":"Авто,Охлаждение,Осушение,Обогрев,Вентиляция","vi":"Tự động, Làm mát, Sấy khô, Sưởi, Quạt","th":"อัตโนมัติ ทำความเย็น เป่าแห้ง ทำความร้อน พัดลม","id":"Auto, Sejuk, Kering, Panas, Kipas","zh-tw":"自動、製冷、乾燥、制熱、送風","ar":"تلقائي، تبريد، تجفيف، تدفئة، مروحة"},"Cool & Dry Mode":{"en":"Cooling Only","ch":"单冷","fr":"Refroidissement Uniquement","ja":"冷却のみ","it":"Solo raffreddamento","sp":"Solo Enfriamiento","pt":"Só Arrefecimento","de":"Nur kühlen","ru":"Режим охлаждения и осушения","vi":"Chỉ làm mát","th":"ทำความเย็นเท่านั้น","id":"Pendinginan Saja","zh-tw":"單冷","ar":"تبريد فقط"},"Auto,Cool,Dry,Fan":{"en":"Auto,Cool,Dry,Fan","ch":"自动、制冷、干燥、送风","fr":"Auto, Cool, Sec, Ventilateur","ja":"オート、クール、ドライ、ヒート、ファン","it":"Automatico, Raffreddamento, Essiccazione, Ventilatore","sp":"Auto, Frío, Seco, Ventilador","pt":"Auto, Frio, Seco, Ventoínha","de":"Auto,Kühlen,Trocknen,Lüfter","ru":"Авто,Охлаждение,Осушение,Вентиляция","vi":"Tự động, Làm mát, Sấy khô, Quạt","th":"อัตโนมัติ ทำความเย็น เป่าแห้ง พัดลม","id":"Auto, Sejuk, Kering, Kipas","zh-tw":"自動、製冷、乾燥、送風","ar":"تلقائي، تبريد، تجفيف، مروحة"},"Cool Mode":{"en":"Cooling Special","ch":"制冷专用","fr":"Spécial Refroidissement","ja":"クールモード","it":"Speciale raffreddamento","sp":"Enfriamiento Especia","pt":"Arrefecimento Especial","de":"Sonderkühlung","ru":"Режим охлаждения","vi":"Làm mát Đặc biệt","th":"ทำความเย็นเป็นพิเศษ","id":"Khusus Pendinginan","zh-tw":"製冷專用","ar":"تبريد خاص"},"Cool,Fan":{"en":"Cool,Fan","ch":"制冷、送风","fr":"Cool,Ventilateur","ja":"クール、ファン","it":"Raffreddamento, Ventilatore","sp":"Frío,Ventilador","pt":"Frio,Ventoínha","de":"Kühlen,Lüfter","ru":"Охлаждение,Вентиляция","vi":"Làm mát, Quạt","th":"ทำความเย็น พัดลม","id":"Sejuk, Kipas","zh-tw":"製冷、送風","ar":"تبريد، مروحة"},"Heat Mode":{"en":"Heating Only","ch":"单热","fr":"Chauffage Seulement","ja":"ヒートモード","it":"Solo riscaldamento","sp":"Sólo Calefacción","pt":"Só Aquecimento","de":"Nur Heizen","ru":"Режим обогрева","vi":"Chỉ sưởi","th":"ทำความร้อนเท่านั้น","id":"Hanya Pemanasan","zh-tw":"單熱","ar":"تدفئة فقط"},"Auto,Heat,Fan":{"en":"Auto,Heat,Fan","ch":"自动、制热、送风","fr":"Auto, Chaleur, Ventilateur","ja":"オート、ヒート、ファン","it":"Automatico, Riscaldamento, Ventilatore","sp":"Auto, Calor, Ventilador","pt":"Auto, Calor, Ventoínha","de":"Auto,Heizen,Lüfter","ru":"Авто,Обогрев,Вентиляция","vi":"Tự động, Sưởi, Quạt","th":"อัตโนมัติ ทำความร้อน พัดลม","id":"Auto, Panas, Kipas","zh-tw":"自動、制熱、送風","ar":"تلقائي، تدفئة، مروحة"},"Medium":{"en":"Medium","ch":"中等","fr":"Médium","ja":"中","it":"Medio","sp":"Medio","pt":"Médio","de":"Mittel","ru":"Средний","vi":"Trung bình","th":"ปานกลาง","id":"Medium","zh-tw":"中等","ar":"متوسط"},"Fan Speed can not be used under current mode":{"en":"Fan Speed is not available in current mode","ch":"风速设置无法在当前模式下使用","fr":"La vitesse du ventilateur ne peut pas être utilisée en mode actuel","ja":"現在のモードではファンスピードは使用できません。","it":"La velocità della ventola non può essere utilizzata nella modalità corrente","sp":"La velocidad del ventilador no se puede usar en el modo actual","pt":"A velocidade do ventilador não pode ser usada no modo atual","de":"Die Lüftergeschwindigkeit kann im aktuellen Modus nicht verwendet werden","ru":"Скорость вентилятора нельзя использовать в текущем режиме","vi":"Không thể sử dụng Tốc độ Quạt ở chế độ hiện tại","th":"ไม่สามารถใช้ความเร็วพัดลมได้ในโหมดปัจจุบัน","id":"Kecepatan Kipas tidak bisa digunakan dalam mode ini","zh-tw":"風速設置無法在當前模式下使用","ar":"لا يمكن استخدام سرعة المروحة تحت الوضع الحالي"},"Device is power off":{"en":"The device cannot be operated when it is turned off.","ch":"设备已关机","fr":"L'appareil est éteint","ja":"デバイスの電源が切れています。","it":"L'impianto è spento","sp":"El dispositivo está apagado","pt":"Dispositivo desligado","de":"Gerät ist ausgeschaltet","ru":"Устройство выключено","vi":"Thiết bị bị tắt nguồn","th":"อุปกรณ์ปิดอยู่","id":"Perangkat dimatikan","zh-tw":"裝置已關機","ar":"الجهاز متوقف عن التشغيل"},"Turbo can not be used under current mode":{"en":"Boost is not available in current mode","ch":"强劲无法在当前模式下使用","fr":"Boost n'est pas pris en charge dans ce mode","ja":"ターボは現在のモードでは使用できません。","it":"Boost non è supportato in questa modalità.","sp":"Boost no es soportado en este modo","pt":"Boost não é suportado neste modo","de":"Boost ist in diesem Modus nicht unterstützt.","ru":"стимулировать нельзя использовать в текущем режиме","vi":"Chế độ tăng cường không được hỗ trợ","th":"ไม่รองรับเทอร์โบในโหมดนี้","id":"Boost tidak didukung dalam mode ini","zh-tw":"強勁無法在當前模式下使用","ar":"وظيفة تيربو غير مدعومة في هذا الوضع"},"ECO can not be used under current mode":{"en":"ECO is not available in current mode","ch":"ECO无法在当前模式下使用","fr":"Eco ne peut pas être utilisé en mode actuel","ja":"現在のモードではECOは使用できません。","it":"Eco non può essere utilizzato nella modalità corrente","sp":"Eco no se puede utilizar en el modo actual","pt":"Eco não pode ser utilizado no modo actual","de":"Eco kann im aktuellen Modus nicht benutzt werden","ru":"ЭКО нельзя использовать в текущем режиме","vi":"Không thể sử dụng ECO ở chế độ hiện tại","th":"ไม่สามารถใช้ ECO ได้ในโหมดปัจจุบัน","id":"ECO tidak bisa digunakan dalam mode ini","zh-tw":"ECO無法在當前模式下使用","ar":"لا يمكن استخدام وظيفة ايكو تحت الوضع الحالي"},"Dry can not be used under current mode":{"en":"This function is not available in current mode","ch":"干燥无法在当前模式下使用","fr":"Cette fonction ne peut pas être utilisée sous le mode actuel","ja":"ドライは現在のモードでは使用できません。","it":"Questa funzione non può essere utilizzata nella modalità corrente","sp":"Esta función no se puede usar en el modo actual","pt":"Esta função não pode ser usada no modo atual","de":"Diese Funktion kann im aktuellen Modus nicht verwendet werden ","ru":"Осушение нельзя использовать в текущем режиме","vi":"Không thể sử dụng chức năng Hút ẩm ở chế độ hiện tại","th":"ไม่สามารถใช้ฟังก์ชันนี้ได้ในโหมดปัจจุบัน","id":"Fungsi ini tidak bisa digunakan dalam mode ini","zh-tw":"乾燥無法在當前模式下使用","ar":"لا يمكن استخدام هذه الوظيفة تحت الوضع الحالي"},"ElecHeat can not be used under current mode":{"en":"ElecHeat is not available in current mode","ch":"电辅热无法在当前模式下使用","fr":"ElecHeat ne peut pas être utilisé sous le mode actuel","ja":"現在のモードではElecHeat は使用できません。","it":"ElecHeat non può essere usato nella modalità corrente","sp":"La calefacción eléctrica no se puede utilizar en el modo actual","pt":"O ElecHeat não pode ser usado no modo atual","de":"Gerät ist ausgeschaltet","ru":"ЭлекОбогрев нельзя использовать в текущем режиме","vi":"Không thể sử dụng ElecHeat ở chế độ hiện tại","th":"ไม่สามารถใช้ ElecHeat ได้ในโหมดปัจจุบัน","id":"ElecHeat tidak bisa digunakan dalam mode ini","zh-tw":"電輔熱無法在當前模式下使用","ar":"لا يمكن استخدام وظيفة التدفئة الكهربائية تحت الوضع الحالي"},"Temperature can't be changed under Fan mode":{"en":"Temperature can't be changed under Fan mode","ch":"温度设置无法在当前模式下使用","fr":"La température ne peut pas être modifiée en mode ventilateur","ja":"SetTemperature は現在のモードでは使用できません。","it":"La temperatura non può essere cambiata in modalità Ventilatore","sp":"La temperatura no se puede cambiar en el modo Ventilador","pt":"Temperatura não pode ser alterada no modo de Ventoínha","de":"Temperatur kann im Lüfter-Modus nicht geändert werden","ru":"Нельзя изменить температуру в режиме вентилятора","vi":"Không thể thay đổi nhiệt độ ở chế độ Quạt","th":"ไม่สามารถเปลี่ยนอุณหภูมิได้หากอยู่ในโหมดพัดลม","id":"Suhu tidak bisa diganti dalam mode Kipas","zh-tw":"溫度設定無法在當前模式下使用","ar":"لا يمكن تغيير درجة الحرارة تحت وضع المروحة"},"device is power off":{"en":"The device cannot be operated when it is turned off.","ch":"设备已关机","fr":"L'appareil est éteint","ja":"デバイスの電源がきれています。","it":"L'impianto è spento","sp":"El dispositivo está apagado","pt":"Dispositivo desligado","de":"Gerät ist ausgeschaltet","ru":"устройство выключено","vi":"Thiết bị bị tắt nguồn","th":"อุปกรณ์ปิดอยู่","id":"Perangkat dimatikan","zh-tw":"裝置已關機","ar":"الجهاز متوقف عن التشغيل"},"8°Heat is not supported at this mode":{"en":"8°Heat is not available in current mode","ch":"该模式下，不支持8°加热","fr":"8 °C Heat n'est pas pris en charge dans ce mode","ja":"8°このモードではHeat に対応していません。","it":"8 ° C Il calore non è supportato in questa modalità","sp":"Temperatura de 8 °C no es soportado en este modo","pt":"8 °C Calor não é suportado neste modo","de":"8 ° C Wärme wird in diesem Modus nicht unterstützt","ru":"8°Обогрев не поддерживается в этом режиме","vi":"8°Heat không được hỗ trợ ở chế độ này","th":"ไม่รองรับการทำความร้อนที่ 8° ในโหมดนี้","id":"Kipas \"8\" tidak didukung dalam mode ini","zh-tw":"該模式下，不支持8°加熱","ar":"وظيفة 8°تدفئة غير مدعومة في هذا الوضع"},"Breezeless can not be used under current mode":{"en":"Breezeless is not available in current mode","ch":"无风设置无法在当前模式下使用","fr":"Breezeless ne peut pas être utilisé en mode actuel","ja":"現在のモードでは、Breezeless は使用できません。","it":"Breezeless non può essere utilizzato nella modalità corrente","sp":"Breezeless no se puede utilizar en el modo actual","pt":"Breezeless não pode ser utilizado no modo actual","de":"Breezeless kann im aktuellen Modus nicht verwendet werden","ru":"Breezeless нельзя использовать в текущем режиме","vi":"Không thể sử dụng Breezeless ở chế độ hiện tại","th":"ไม่สามารถใช้โหมดไม่มีลมอ่อนได้ในโหมดปัจจุบัน","id":"Breezeless (Tanpa Angin) tidak bisa digunakan dalam mode ini","zh-tw":"無風設定無法在當前模式下使用","ar":"لا يمكن استخدام وظيفة بدون نسيم  تحت الوضع الحالي"},"CoolFlash can not be used under current mode":{"en":"CoolFlash is not available in current mode","ch":"无风设置无法在当前模式下使用","fr":"CoolFlash ne peut pas être utilisé en mode actuel","ja":"現在のモードでは、CoolFlash は使用できません。","it":"CoolFlash non può essere utilizzato nella modalità corrente","sp":"CoolFlash no se puede utilizar en el modo actual","pt":"CoolFlash não pode ser utilizado no modo actual","de":"CoolFlash kann im aktuellen Modus nicht verwendet werden","ru":"CoolFlash нельзя использовать в текущем режиме","vi":"Không thể sử dụng CoolFlash ở chế độ hiện tại","th":"ไม่สามารถใช้การไม่มีลมอ่อนได้ในโหมดปัจจุบัน","id":"CoolFlash (Tanpa Angin) tidak bisa digunakan dalam mode ini","zh-tw":"無風設定無法在當前模式下使用","ar":"لا يمكن استخدام وظيفة بدون نسيم  تحت الوضع الحالي"},"HeatFlash can not be used under current mode":{"en":"HeatFlash is not available in current mode","ch":"无风设置无法在当前模式下使用","fr":"HeatFlash ne peut pas être utilisé en mode actuel","ja":"現在のモードでは、HeatFlash は使用できません。","it":"HeatFlash non può essere utilizzato nella modalità corrente","sp":"HeatFlash no se puede utilizar en el modo actual","pt":"HeatFlash não pode ser utilizado no modo actual","de":"HeatFlash kann im aktuellen Modus nicht verwendet werden","ru":"HeatFlash нельзя использовать в текущем режиме","vi":"Không thể sử dụng HeatFlash ở chế độ hiện tại","th":"ไม่สามารถใช้การไม่มีลมอ่อนได้ในโหมดปัจจุบัน","id":"HeatFlash (Tanpa Angin) tidak bisa digunakan dalam mode ini","zh-tw":"無風設定無法在當前模式下使用","ar":"لا يمكن استخدام وظيفة بدون نسيم  تحت الوضع الحالي"},"Wind ON me can not be used under current mode":{"en":"Wind ON me is not available in current mode","ch":"风吹人无法在当前模式下使用","fr":"Wind ON me ne peut pas être utilisé en mode actuel","ja":"現在のモードでは、「風ON」は使用できません。","it":"Wind ON me non può essere utilizzato in modalità corrente","sp":"Wind ON me no se puede utilizar en el modo actual","pt":"Wind ON me não pode ser utilizado no modo actual","de":"Wind ON me kann im aktuellen Modus nicht verwendet werden","ru":"Прямой обдув нельзя использовать в текущем режиме","vi":"Không thể sử dụng Wind ON me ở chế độ hiện tại","th":"ไม่สามารถเปิดลมมาทางฉันได้ในโหมดปัจจุบัน","id":"Angin ON tidak bisa digunakan dalam mode ini","zh-tw":"風吹人無法在當前模式下使用","ar":"لا يمكن استخدام وظيفة تشغيل نفخ الهواء تحت الوضع الحالي"},"Wind OFF me can not be used under current mode":{"en":"Wind OFF me is not available in current mode","ch":"风避人无法在当前模式下使用","fr":"Wind OFF me ne peut pas être utilisé en mode actuel","ja":"現在のモードでは、「風OFF」は使用できません。","it":"Wind OFF me non può essere utilizzato in modalità corrente","sp":"Wind OFF me no se puede utilizar en el modo actual","pt":"Wind OFF me não pode ser utilizado no modo actual","de":"Wind OFF me kann im aktuellen Modus nicht verwendet werden","ru":"Предотвращение прямого обдува нельзя использовать в текущем режиме","vi":"Không thể sử dụng Wind OFF me ở chế độ hiện tại","th":"ไม่สามารถปิดลมมาทางฉันได้ในโหมดปัจจุบัน","id":"Angin OFF tidak bisa digunakan dalam mode ini","zh-tw":"風避人無法在當前模式下使用","ar":"لا يمكن استخدام وظيفة إيقاف تشغيل نفخ الهواء تحت الوضع الحالي"},"Breeze Away can not be used under current mode":{"en":"Breeze Away is not available in current mode","ch":"风避人无法在当前模式下使用","fr":"Breeze Away ne peut pas être utilisé en mode actuel","ja":"現在のモードでは、「ブリーズアウェイ」は使用できません。","it":"Breeze Away non può essere utilizzato nella modalità corrente","sp":"Breeze Away no se puede utilizar en el modo actual","pt":"Breeze Away não pode ser utilizado no modo actual","de":"Breeze Away kann im aktuellen Modus nicht verwendet werden","ru":"Breeze Away нельзя использовать в текущем режиме","vi":"Không thể sử dụng Breeze Away me ở chế độ hiện tại","th":"ไม่สามารถใช้ไม่ต้องการลมอ่อนได้ในโหมดปัจจุบัน","id":"Angin Semilir tidak bisa digunakan dalam mode ini","zh-tw":"風避人無法在當前模式下使用","ar":"لا يمكن استخدام وظيفة نسيم بعيد تحت الوضع الحالي"},"Breeze Mild can not be used under current mode":{"en":"Breeze Mild is not available in current mode","ch":"柔风感无法在当前模式下使用","fr":"Breeze Mild ne peut pas être utilisé en mode actuel","ja":"現在のモードでは、「ブリーズマイルド」は使用できません。","it":"Breeze Mild non può essere utilizzato nella modalità corrente","sp":"Breeze Mild no se puede utilizar en el modo actual","pt":"Breeze Mild não pode ser utilizado no modo actual","de":"Breeze Mild kann im aktuellen Modus nicht verwendet werden","ru":"Breeze Mild нельзя использовать в текущем режиме","vi":"Không thể sử dụng Breeze Mild me ở chế độ hiện tại","th":"ไม่สามารถใช้ลมอ่อนได้ในโหมดปัจจุบัน","id":"Angin Lembut tidak bisa digunakan dalam mode ini","zh-tw":"柔風感無法在當前模式下使用","ar":"لا يمكن استخدام وظيفة Breeze Mild تحت الوضع الحالي"},"Equipment communication failure, Please retry later":{"en":"Control failed, please try again","ch":"控制失败，请再次尝试","fr":"Le contrôle a échoué, veuillez réessayer","ja":"機器の通信障害、後で再試行してください。","it":"Controllo fallito, riprovare.","sp":"Falla de control, intente de nuevo.","pt":"Falha no controlo. Tente novamente.","de":"Steuerung fehlgeschlagen, bitte erneut versuchen.","ru":"Ошибка связи с оборудованием, Повторите попытку позже","vi":"Điều khiển không thành công, vui lòng thử lại","th":"การควบคุมล้มเหลว โปรดลองอีกครั้ง","id":"Kontrol gagal, mohon coba lagi","zh-tw":"控制失敗，請再次嘗試","ar":"فشل التحكم، يرجى المحاولة مرة أخرى"},"week_everyday":{"en":"Everyday","ch":"每天","fr":"Tous les jours","ja":"日常","it":"Ogni giorno","sp":"Todos los días","pt":"Todos os dias","de":"Täglich","ru":"Каждый день","vi":"Mỗi ngày","th":"ทุกวัน","id":"Setiap hari","zh-tw":"每天","ar":"كل يوم"},"Copy Successful":{"en":"Copy Successful","ch":"复制成功","fr":"Copie réussie","ja":"コピー成功","it":"Copia riuscita","sp":"Copia exitosa","pt":"Copiar com Sucesso","de":"Kopieren erfolgreich","ru":"Копировать успешно","vi":"Sao chép thành công","th":"คัดลอกสำเร็จ","id":"Salin berhasil","zh-tw":"複製成功","ar":"نسخة ناجحة"},"Network Timeout, Please retry later":{"en":"Control failed, please try again.","ch":"控制失败，请再次尝试","fr":"Le contrôle a échoué, veuillez réessayer","ja":"ネットワークタイムアウト、後で再試行してください。","it":"Controllo fallito, riprovare.","sp":"Falla de control, intente de nuevo.","pt":"Falha no controlo. Tente novamente.","de":"Steuerung fehlgeschlagen, bitte erneut versuchen.","ru":"Ошибка управления, повторите попытку позже","vi":"Hết thời gian kết nối, vui lòng thử lại","th":"การควบคุมล้มเหลว โปรดลองอีกครั้ง","id":"Kontrol gagal, mohon coba lagi","zh-tw":"控制失敗，請再次嘗試","ar":"فشل التحكم، يرجى المحاولة مرة أخرى."},"Please select device type":{"en":"Choose Device Type","ch":"选择设备类型","fr":"Choisissez le type de périphérique","ja":"デバイスタイプの選択","it":"Scegli il tipo di impianto","sp":"Elija el Tipo de Dispositivo","pt":"Escolha o Tipo de Dispositivo","de":"Wählen Sie den Gerätetyp aus","ru":"Выберите тип устройства","vi":"Chọn Loại Thiết bị","th":"เลือกประเภทของอุปกรณ์","id":"Pilih Jenis Perangkat","zh-tw":"選擇裝置類別","ar":"اختر نوع الجهاز"},"Custom Dry":{"en":"Custom Dry","ch":"自定义干燥模式","fr":"Mode de séchage personnalisé","ja":"カスタム乾燥モード","it":"Asciugatura personalizzata","sp":"Modo de secado personalizado","pt":"Modo de secagem personalizado","de":"Benutzerdefinierter Trocknungsmodus","ru":"Пользовательский режим сушки","vi":"Chế độ Hút ẩm tùy chỉnh","th":"โหมดการอบแห้งแบบกำหนดเอง","id":"Mod pengeringan tersuai","zh-tw":"自定義乾燥模式","ar":"وضع التجفيف المخصص"},"Vertical S":{"en":"Vertical Swing","ch":"左右风","fr":"vent gauche et droit","ja":"左右の風","it":"vento sinistro e destro","sp":"viento izquierdo y derecho","pt":"vento esquerdo e direito","de":"Links- und Rechtswind","ru":"Жалюзи влево-вправо","vi":"Đảo cánh dọc","th":"ลมซ้ายและขวา","id":"angin kiri dan kanan","zh-tw":"左右風","ar":"الريح اليمنى واليسرى"},"Horizontal S":{"en":"Horizontal Swing","ch":"上下风","fr":"haut et bas","ja":"上下の風","it":"su e giù","sp":"arriba y abajo","pt":"para cima e para baixo","de":"auf und ab","ru":"Жалюзи вверх-вниз","vi":"Đảo cánh ngang","th":"ขึ้นและลง","id":"atas dan bawah","zh-tw":"上下風","ar":"اعلى واسفل"},"ECO":{"en":"ECO","ch":"ECO","fr":"ECO","ja":"ECO","it":"ECO","sp":"ECO","pt":"ECO","de":"ECO","ru":"ECO","vi":"ECO","th":"ECO","id":"ECO","zh-tw":"ECO","ar":"ECO"},"Temp Unit":{"en":"Temp Unit","ch":"温度单位","fr":"Temp Unit","ja":"温度ユニット","it":"Temp Unità","sp":"Unidad de temp.","pt":"Unidade de Tempo","de":"Temp Unit","ru":"Единица Темп","vi":"Đơn vị Nhiệt độ","th":"หน่วยของอุณหภูมิ","id":"Unit Suhu","zh-tw":"溫度單位","ar":"وحدة درجة الحرارة"},"Elec Heat":{"en":"Elec Heat","ch":"电热","fr":"chauffage électrique","ja":"電気暖房","it":"Risc Elet","sp":" Calefacción eléctrica","pt":"aquecimento elétrico","de":"Elec Heat","ru":"электрическое отопление","vi":" nhiệt điện","th":"เครื่องทำความร้อนไฟฟ้า","id":"pemanasan elektrik","zh-tw":"電熱","ar":"تدفئة كهربائية"},"FP":{"en":"FP","ch":"防冻","fr":"Antigel","ja":"フロスト保護","it":"Antigelo","sp":"Anticongelante","pt":"Anticongelante","de":"Frostschutzmittel","ru":"Дежурный обогрев","vi":"chất chống đông","th":"สารป้องกันการแข็งตัว","id":"antibeku","zh-tw":"防凍","ar":"مضاد للتجمد"},"Wind ON me":{"en":"Wind ON me","ch":"风吹人","fr":" le vent souffle les gens","ja":"風が吹く","it":" il vento soffia le persone","sp":"el viento sopla a la gente","pt":"o vento sopra as pessoas","de":"Wind weht Menschen","ru":"ветер дует людей","vi":"Gió thổi lên người","th":"ลมพัด","id":"angin meniup orang","zh-tw":"風吹人","ar":"تهب الرياح الناس"},"Wind OFF me":{"en":"Wind OFF me","ch":"风避人","fr":"éviter les gens","ja":"人を避ける","it":"evitare le persone","sp":" evitar a la gente","pt":"evitar pessoas","de":"Menschen meiden","ru":"избегать людей","vi":"Tránh gió lên người","th":"เลี่ยงคน","id":"elakkan orang","zh-tw":"風避人","ar":"تجنب الناس"},"LED":{"en":"LED","ch":"LED","fr":"LED","ja":"LED","it":"LED","sp":"LED","pt":"LED","de":"LED","ru":"LED","vi":"LED","th":"LED","id":"LED","zh-tw":"LED","ar":"LED"},"Breezeless":{"en":"Breezeless","ch":"无风","fr":"Sans vent","ja":"風のない","it":"Senza vento","sp":"Sin brisa","pt":"Sem Brisa","de":"Atemlos","ru":"Безветренный","vi":"Không có gió","th":"ไม่มีลมอ่อน","id":"Breezeless (Tanpa Angin)","zh-tw":"無風","ar":"بدون نسيم"},"Elec":{"en":"Elec","ch":"Elec","fr":"Elec","ja":"Elec","it":"Elec","sp":"Elec","pt":"Elec","de":"Elec","ru":"Элек","vi":"Elec","th":"Elec","id":"Elec","zh-tw":"Elec","ar":"Elec"},"Active Clean":{"en":"Active Clean","ch":"自清洁","fr":"autonettoyant","ja":"セルフクリーニング","it":"autopulente","sp":"autolimpiante","pt":"autolimpante","de":"selbstreinigend","ru":"Самоочистка","vi":" tự làm sạch","th":"ทำความสะอาดตัวเอง","id":"pembersihan diri","zh-tw":"自清潔","ar":"التنظيف الذاتي"},"Breeze Away":{"en":"Breeze Away","ch":"防直吹","fr":"Empêcher le soufflage direct","ja":"直接吹き付けを防ぐ","it":"Prevenire il soffiaggio diretto","sp":"Prevenir el soplado directo","pt":"Brisa Distante","de":"Direktes Anblasen verhindern","ru":"Мягкое охлаждение","vi":"Phân phối luồng gió","th":"ป้องกันการเป่าโดยตรง","id":"Elakkan tiupan langsung","zh-tw":"防直接吹風","ar":"منع النفخ المباشر"},"Breeze Mild":{"en":"Breeze Mild","ch":"柔风","fr":"vent doux","ja":"やわらかい風","it":"vento morbido","sp":"viento suave","pt":"vento suave","de":"weicher wind","ru":"мягкий ветер","vi":"Gió nhẹ","th":"ลมอ่อนๆ","id":"angin lembut","zh-tw":"柔風","ar":"الرياح لينة"},"AvoidMe":{"en":"Avoid Me","ch":"上下防直吹","fr":"Avoid Me","ja":"私を避けて","it":"Evitami","sp":"Recuérdame","pt":"vento suave","de":"Vermeide mich","ru":"Избегайте меня","vi":"Tránh xa tôi ra","th":"หลีกเลี่ยงฉัน","id":"Menghindari Aku","zh-tw":"上下防直吹","ar":"أعلى وأسفل تهب مباشرة"},"Upper":{"en":"Upper","ch":"更高","fr":"Supérieur","ja":"上段","it":"Superiore","sp":"Superior","pt":"Alto","de":"Obere","ru":"Верхний","vi":"Phía trên","th":"ด้านบน","id":"Atas","zh-tw":"更高","ar":"العلوي"},"Lower":{"en":"Lower","ch":"更低","fr":"Inférieure","ja":"下","it":"Inferiore","sp":"Inferior","pt":"Baixar","de":"Untere","ru":"Нижний","vi":"Thấp hơn","th":"ต่ำกว่า","id":"Lebih rendah","zh-tw":"更低","ar":"أدنى"},"Upper and lower ambient wind":{"en":"Upper and lower ambient wind","ch":"上下环境风","fr":"Vent ambiant supérieur et inférieur","ja":"上下の環境風","it":"Vento ambientale superiore e inferiore","sp":"Viento ambiente superior e inferior","pt":"Vento ambiente superior e inferior","de":"Oberer und unterer Umgebungswind","ru":"Верхний и нижний окружающий ветер","vi":"Gió xung quanh trên và dưới","th":"ลมบนและล่าง","id":"Angin sekitar atas dan bawah","zh-tw":"上下環境風","ar":"لرياح المحيطة العلوية والسفلية"},"Eco Sensoric":{"en":"ECO Intelligent Eye","ch":"智慧眼","fr":"ECO Intelligent Eye","ja":"エコ・センソリック","it":"ECO Intelligent Eye","sp":"ECO Intelligent Eye","pt":"ECO Intelligent Eye","de":"ECO Intelligent Eye","ru":"Эко Сенсорик","vi":"Eco Sensoric","th":"ระบบเซ็นเซอร์แบบ Eco","id":"ECO Intelligent Eye","zh-tw":"智慧眼","ar":"ايكو سينسوريك"},"update success":{"en":"update success","ch":"更新成功","fr":"succès de la mise à jour","ja":"アップデート成功","it":"aggiornamento avvenuto","sp":"actualización exitosa","pt":"Atualização Bem Sucedida","de":"Aktualisierung erfolgreich","ru":"обновление выполнено успешно","vi":"cập nhật thành công","th":"อัปเดตเรียบร้อยแล้ว","id":"pembaruan berhasil","zh-tw":"更新成功","ar":"نجح التحديث"},"update fail":{"en":"update fail","ch":"更新失败","fr":"échec de la mise à jour","ja":"アップデート失敗","it":"aggiornamento fallito","sp":"actualización fallida","pt":"Falha de Atualização","de":"Aktualisierung fehlgeschlagen","ru":"ошибка обновления","vi":"cập nhật không thành công","th":"การอัปเดตล้มเหว","id":"pembaruan gagal","zh-tw":"更新失敗","ar":"تعذر التحديث"},"Detail":{"en":"Detail","ch":"详情","fr":"Détail","ja":"詳細","it":"Dettagli","sp":"Detalle","pt":"Detalhe","de":"Einzelheit","ru":"Подробно","vi":"Chi tiết","th":"รายละเอียด","id":"Rincian","zh-tw":"詳情","ar":"التفاصيل"},"Scanning":{"en":"Scanning","ch":"扫描","fr":"Scanne","ja":"スキャン","it":"Scansione","sp":"Exploración","pt":"A pesquisar","de":"Scannen","ru":"Сканирование","vi":"Đang quét","th":"กำลังสแกน","id":"Pemindaian","zh-tw":"掃瞄","ar":"المسح"},"Testing":{"en":"Testing","ch":"测试","fr":"Essai","ja":"テスト","it":"Test","sp":"Probando","pt":"A testar","de":"Testen","ru":"Тест","vi":"Đang kiểm tra","th":"กำลังทดสอบ","id":"Pengujian","zh-tw":"測試","ar":"الاختبار"},"Normal":{"en":"Normal","ch":"正常","fr":"Ordinaire","ja":"正常","it":"Normale","sp":"Normal","pt":"Normal","de":"Normal","ru":"Норма","vi":"Bình thường","th":"ปกติ","id":"Normal","zh-tw":"正常","ar":"طبيعي"},"Abnormal":{"en":"Abnormal","ch":"异常","fr":"Anormal","ja":"異常","it":"Anomalo","sp":"Anormal","pt":"Anormal","de":"Anormal","ru":"Ошибка","vi":"Bất thường","th":"ผิดปกติ","id":"Tidak Normal","zh-tw":"異常","ar":"غير طبيعي"},"Done":{"en":"Done","ch":"完成","fr":"Terminé","ja":"完了","it":"Fatto","sp":"Hecho","pt":"Concluído","de":"Fertig","ru":"Готово","vi":"Xong","th":"เรียบร้อย","id":"Selesai","zh-tw":"完成","ar":"تم"},"Save changes":{"en":"Save changes?","ch":"保存更改?","fr":"Sauvegarder les modifications?","ja":"変更の保存?","it":"Salvo le modifiche?","sp":"Guardar cambios?","pt":"Salvar alterações?","de":"Änderungen speichern?","ru":"Сохранить изменения","vi":"Lưu thay đổi?","th":"บันทึกการเปลี่ยนแปลง?","id":"Simpan perubahan?","zh-tw":"保存更改?","ar":"حفظ التغييرات؟"},"Ok":{"en":"Ok","ch":"确定","fr":"D'accord","ja":"OK","it":"Ok","sp":"Okay","pt":"Está bem","de":"Ok","ru":"Да","vi":"Được","th":"ตกลง","id":"Oke","zh-tw":"確定","ar":"موافق"},"OK":{"en":"Ok","ch":"确定","fr":"D'accord","ja":"OK","it":"Ok","sp":"Okay","pt":"Está bem","de":"Ok","ru":"Да","vi":"Được","th":"ตกลง","id":"Oke","zh-tw":"確定","ar":"موافق"},"Repeat":{"en":"Repeat","ch":"重复","fr":"Répéter","ja":"繰り返し","it":"Ripeti","sp":"Repetir","pt":"Repetir","de":"Wiederholen","ru":"Повторить","vi":"Lặp lại","th":"ทำซ้ำ","id":"Ulangi","zh-tw":"重複","ar":"التكرار"},"Label":{"en":"Label","ch":"标签","fr":"Étiquette","ja":"ラベル","it":"Etichette","sp":"Etiqueta","pt":"Rótulo","de":"Etikett","ru":"Ярлык","vi":"Nhãn","th":"ฉลาก","id":"Label","zh-tw":"標識","ar":"التسمية"},"Unnamed":{"en":"Unnamed","ch":"未命名","fr":"Sans nom","ja":"名称未設定","it":"Senza nome","sp":"Sin nombre","pt":"Sem nome","de":"Unbenannt","ru":"Без имени","vi":"Chưa được đặt tên","th":"ไม่มีชื่อ","id":"Tidak Bernama","zh-tw":"未命名","ar":"بدون اسم"},"Delete":{"en":"Delete","ch":"删除","fr":"Supprimer","ja":"削除","it":"Cancella","sp":"Eliminar","pt":"Apagar","de":"Löschen","ru":"Удалить","vi":"Xóa","th":"ลบ","id":"Hapus","zh-tw":"移除","ar":"حذف"},"Maximum temperature":{"en":"Maximum temperature","ch":"最高温度","fr":"Température maximale","ja":"最高温度","it":"Temperatura massima","sp":"Temperatura máxima","pt":"Temperatura máxima","de":"Max. Temperatur","ru":"Максимальная температура","vi":"Nhiệt độ tối đa","th":"อุณหภูมิสูงสุด","id":"Suhu Maksimal","zh-tw":"最高溫度","ar":"درجة الحارة القصوى"},"Minimum temperature":{"en":"Minimum temperature","ch":"最低温度","fr":"Température minimum","ja":"最低温度","it":"Temperatura minima","sp":"Temperatura mínima","pt":"Temperatura mínima","de":"Min. Temperatur","ru":"Минимальная температура","vi":"Nhiệt độ tối thiểu","th":"อุณหภูมิต่ำสุด","id":"Suhu Minimal","zh-tw":"最低溫度","ar":"درجة الحرارة الدنيا"},"Delete schedule":{"en":"Delete schedule","ch":"删除周定时","fr":"Certain d’effacer","ja":"スケジュールの削除","it":"Cancella piano","sp":"Seguro para eliminar","pt":"Tem a certeza que deseja apagar","de":"Zeitplan löschen","ru":"Удалить график","vi":"Xóa lịch trình","th":"ลบกำหนดการ","id":"Hapus jadwal","zh-tw":"移除周定時","ar":"مسح الجدول الزمني"},"Please add a schedule":{"en":"Please add a schedule…","ch":"请添加周定时…","fr":"Veuillez ajouter un horaire…","ja":"スケジュールを追加してください...","it":"Aggiungi un piano...","sp":"Añade un horario …","pt":"Adicione um cronograma …","de":"Bitte einen Zeitplan hinzufügen","ru":"Добавьте график","vi":"Vui lòng thêm lịch trình","th":"โปรดเพิ่มกำหนดการ","id":"Mohon tambah sebuah jadwal","zh-tw":"請新增周定時…","ar":"يرجى إضافة جدول زمني..."},"Every day":{"en":"Every day","ch":"每天","fr":"Tous les jours","ja":"毎日","it":"Ogni giorno","sp":"Todos los días","pt":"Todos os dias","de":"Täglich","ru":"Каждый день","vi":"Mỗi ngày","th":"ทุกวัน","id":"Setiap hari","zh-tw":"每天","ar":"كل يوم"},"Weekdays":{"en":"Weekdays","ch":"工作日","fr":"Jour de travail","ja":"平日","it":"Fine settimana","sp":"Dia de trabajo","pt":"Dias úteis","de":"Wochentags","ru":"Будние дни","vi":"Các ngày trong tuần","th":"วันธรรมดา","id":"Hari kerja","zh-tw":"工作日","ar":"أيام الأسبوع"},"Only once":{"en":"Only once","ch":"仅一次","fr":"Juste une fois","ja":"一度だけ","it":"Solo 1 volta","sp":"Sólo una vez","pt":"Apenas uma vez","de":"Nur einmal","ru":"Только один раз","vi":"Chỉ một lần","th":"แค่ครั้งเดียว","id":"Hanya sekali","zh-tw":"僅一次","ar":"مرة واحدة فقط"},"Monday":{"en":"Monday","ch":"星期一","fr":"Lundi","ja":"月曜日","it":"Lunedì","sp":"Lunes","pt":"Segunda","de":"Montag","ru":"Понедельник","vi":"Thứ Hai","th":"วันจันทร์","id":"Senin","zh-tw":"星期一","ar":"الاثنين"},"Mon.":{"en":"Mon.","ch":"星期一","fr":"Lun.","ja":"月曜.","it":"Lun.","sp":"Lun.","pt":"Seg.","de":"Mon.","ru":"Пн.","vi":"T2","th":"จ.","id":"Sen.","zh-tw":"星期一","ar":"الاثنين"},"Tuesday":{"en":"Tuesday","ch":"星期二","fr":"Mardi","ja":"火曜日","it":"Martedì","sp":"Martes","pt":"Terça","de":"Dienstag","ru":"Вторник","vi":"Thứ Ba","th":"วันอังคาร","id":"Selasa","zh-tw":"星期二","ar":"الثلاثاء"},"Tue.":{"en":"Tue.","ch":"星期二","fr":"Mar.","ja":"火曜.","it":"Mar.","sp":"Mar.","pt":"Ter.","de":"Die.","ru":"Вт.","vi":"T3","th":"อ.","id":"Sel.","zh-tw":"星期二","ar":"الثلاثاء"},"Wednesday":{"en":"Wednesday","ch":"星期三","fr":"Mercredi","ja":"水曜日","it":"Mercoledì","sp":"Miércoles","pt":"Quarta","de":"Mittwoch","ru":"Среда","vi":"Thứ Tư","th":"วันพุธ","id":"Rabu","zh-tw":"星期三","ar":"الأربعاء"},"Wed.":{"en":"Wed.","ch":"星期三","fr":"Merc.","ja":"水曜.","it":"Mer.","sp":"Mie.","pt":"Qua.","de":"Mit.","ru":"Ср.","vi":"T4","th":"พ.","id":"Rab.","zh-tw":"星期三","ar":"الأربعاء"},"Thursday":{"en":"Thursday","ch":"星期四","fr":"Jeudi","ja":"木曜日","it":"Giovedì","sp":"Jueves","pt":"Quinta","de":"Donnerstag","ru":"Четверг","vi":"Thứ Năm","th":"วันพฤหัสบดี","id":"Kamis","zh-tw":"星期四","ar":"الخميس"},"Thur.":{"en":"Thur.","ch":"星期四","fr":"Jeu.","ja":"木曜.","it":"Gio.","sp":"Jue.","pt":"Qui.","de":"Don.","ru":"Чт.","vi":"T5","th":"พฤ.","id":"Kam.","zh-tw":"星期四","ar":"الخميس"},"Friday":{"en":"Friday","ch":"星期五","fr":"Vendredi","ja":"金曜日","it":"Venerdì","sp":"Viernes","pt":"Sexta","de":"Freitag","ru":"Пятница","vi":"Thứ Sáu","th":"วันศุกร์","id":"Jumat","zh-tw":"星期五","ar":"الجمعة"},"Fri.":{"en":"Fri.","ch":"星期五","fr":"Ven.","ja":"金曜","it":"Ven.","sp":"Vie.","pt":"Sex.","de":"Fre.","ru":"Пт.","vi":"T6","th":"ศ.","id":"Jum.","zh-tw":"星期五","ar":"الجمعة"},"Saturday":{"en":"Saturday","ch":"星期六","fr":"Samedi","ja":"土曜日","it":"Sabato","sp":"Sábado","pt":"Sábado","de":"Samstag","ru":"Суббота","vi":"Thứ Bảy","th":"วันเสาร์","id":"Sabtu","zh-tw":"星期六","ar":"السبت"},"Sat.":{"en":"Sat.","ch":"星期六","fr":"Sam.","ja":"土曜.","it":"Sab.","sp":"Sáb.","pt":"Sáb.","de":"Sam.","ru":"Сб.","vi":"T7","th":"ส.","id":"Sab.","zh-tw":"星期六","ar":"السبت"},"Sunday":{"en":"Sunday","ch":"星期日","fr":"Dimanche","ja":"日曜日","it":"Domenica","sp":"Domingo","pt":"Domingo","de":"Sonntag","ru":"Воскресенье","vi":"Chủ Nhật","th":"วันอาทิตย์","id":"Minggu","zh-tw":"星期日","ar":"الأحد"},"Sun.":{"en":"Sun.","ch":"星期日","fr":"Soleil.","ja":"日曜","it":"Dom.","sp":"Dom.","pt":"Dom.","de":"Son.","ru":"Вс.","vi":"CN","th":"อา.","id":"Ahad","zh-tw":"星期日","ar":"الأحد"},"The label cannot exceed 15 characters!":{"en":"The label cannot exceed 15 characters!","ch":"标签不得超过15个字符!","fr":"L'étiquette ne peut pas dépasser 15 caractères!","ja":"ラベルの文字数は15文字までです。","it":"L'etichetta non può superare 15 caratteri!","sp":"¡La etiqueta no puede superar los 15 caracteres!","pt":"O rótulo não pode exceder 15 caracteres!","de":"Das Etikett darf 15 Zeichen nicht überschreiten!","ru":"Ярлык не может превышать 15 символов!","vi":"Nhãn không thể dài quá 15 ký tự!","th":"ฉลากต้องไม่เกิน 15 อักขระ","id":"Label tidak boleh melebihi 15 karakter!","zh-tw":"標識不得超過15個字元!","ar":"لا يمكن ان يتجاوز الاسم 15 حرفاً!"},"Current_humidity":{"en":"Room Humidity","ch":"室内湿度","fr":"Humidité de la pièce","ja":"部屋の湿度","it":"Umidità della stanza","sp":"Humedad de la Habitación","pt":"Humidade do Quarto","de":"Zimmerfeuchtigkeit","ru":"Текущая_влажность","vi":"Độ ẩm Phòng","th":"ความชื้นของห้อง","id":"Kelembaban Ruangan","zh-tw":"室內濕度","ar":"رطوبة الغرفة"},"Humidity":{"en":"Humidity","ch":"湿度","fr":"Humidité","ja":"湿度","it":"Umidità","sp":"Humedad","pt":"Humidade","de":"Feuchtigkeit","ru":"Влажность","vi":"Độ ẩm","th":"ความชื้น","id":"Kelembaban","zh-tw":"濕度","ar":"الرطوبة"},"Full water time":{"en":"Water full time","ch":"水满时间","fr":"Eau à plein temps","ja":"フルタイムの水","it":"Acqua a tempo pieno","sp":"Agua a tiempo completo","pt":"Água em tempo integral","de":"Wasser ganztägig","ru":"Время наполнения водой","vi":"Thời gian đầy nước","th":"เวลาที่น้ำจะเต็ม","id":"Air sepanjang hari","zh-tw":"水滿時間","ar":"وقت ملئ الماء"},"Hour":{"en":"Hours","ch":"小时","fr":"Heures","ja":"時間","it":"Ore","sp":"Horas","pt":"Horas","de":"Stunde","ru":"Час","vi":"Giờ","th":"ชั่วโมง","id":"Jam","zh-tw":"小時","ar":"ساعات"},"Hours":{"en":"Hours","ch":"小时","fr":"Heures","ja":"時間","it":"Ore","sp":"Horas","pt":"Horas","de":"Stunde","ru":"Час","vi":"Giờ","th":"ชั่วโมง","id":"Jam","zh-tw":"小時","ar":"ساعات"},"Tank full":{"en":"Water tank full","ch":"水箱水满","fr":"Réservoir d'eau plein","ja":"水タンクがいっぱい","it":"Serbatoio dell'acqua pieno","sp":"Tanque de agua lleno","pt":"Tanque de água cheio","de":"Wassertank voll","ru":"Полный бак","vi":"Bình đầy nước","th":"ถังเก็บน้ำเต็ม","id":"Tangki air penuh","zh-tw":"水箱水滿","ar":"خزان الماء ممتلئ"},"anion":{"en":"anion","ch":"负离子","fr":"anion","ja":"アニオン","it":"anione","sp":"anión","pt":"ânion","de":"Anion","ru":"анион","vi":"anion","th":"ประจุลบ","id":"anion","zh-tw":"負離子","ar":"أنيون"},"Low":{"en":"Low","ch":"低风","fr":"Faible","ja":"低","it":"Basso","sp":"Bajo","pt":"Baixa","de":"Niedrig","ru":"Низкий","vi":"Thấp","th":"ต่ำ","id":"Rendah","zh-tw":"低風","ar":"منخفض"},"Mid":{"en":"Mid","ch":"中风","fr":"Médium","ja":"中","it":"Medio","sp":"Medio","pt":"Média","de":"Mittel","ru":"Средний","vi":"Trung bình","th":"กลาง","id":"Sedang","zh-tw":"中風","ar":"متوسط"},"High":{"en":"High","ch":"高风","fr":"Haut","ja":"高","it":"Alto","sp":"Alto","pt":"Alta","de":"Hoch","ru":"Высокий","vi":"Cao","th":"สูง","id":"Tinggi","zh-tw":"高風","ar":"مرتفع"},"Auto":{"en":"Auto","ch":"自动","fr":"Auto","ja":"オート","it":"Automatico","sp":"Auto","pt":"Automático","de":"Auto","ru":"Авто","vi":"Tự động","th":"อัตโนมัติ","id":"Auto","zh-tw":"自動","ar":"تلقائي"},"Turbo":{"en":"Boost","ch":"增压","fr":"Turbo","ja":"ブースト","it":"Turbo","sp":"Aumento","pt":"Impulso","de":"Turbo","ru":"Tурбо","vi":"Tăng cường","th":"กระตุ้น","id":"Turbo (Dorongan)","zh-tw":"增壓","ar":"تعزيز"},"water_level":{"en":"Water level","ch":"水位","fr":"Niveau d'eau","ja":"水位","it":"Livello dell'acqua","sp":"Nivel de agua","pt":"Nível de água","de":"Wasserstand","ru":"Уровень воды","vi":"Mức nước","th":"ระดับน้ำ","id":"Tingkat air","zh-tw":"水位","ar":"مستوى الماء"},"1st gear":{"en":"1st gear","ch":"1档","fr":"1ère vitesse","ja":"1速","it":"1a marcia","sp":"1ra marcha","pt":"1ª marcha","de":"1. Gang","ru":"1-я скорость","vi":"Mức thứ nhất","th":"เกียร์ 1","id":"Gigi 1","zh-tw":"1檔","ar":"ملف"},"2nd gear":{"en":"2nd gear","ch":"2档","fr":"2ème vitesse","ja":"2速","it":"2a marcia","sp":"2da marcha","pt":"2ª marcha","de":"2. Gang","ru":"2-я скорость","vi":"Mức thứ hai","th":"เกียร์ 2","id":"Gigi 2","zh-tw":"2檔","ar":"السرعة الثانية"},"3rd gear":{"en":"3rd gear","ch":"3档","fr":"3e vitesse","ja":"3速","it":"3a marcia","sp":"3ra marcha","pt":"3ª marcha","de":"3. Gang","ru":"3-я скорость","vi":"Mức thứ ba","th":"เกียร์ 3","id":"Gigi 3","zh-tw":"3檔","ar":"السرعة الثالثة"},"4th gear":{"en":"4th gear","ch":"4档","fr":"4e vitesse","ja":"4速","it":"4a marcia","sp":"4ta marcha","pt":"4ª marcha","de":"4. Gang","ru":"4-я скорость","vi":"Mức thứ tư","th":"เกียร์ 4","id":"Gigi 4","zh-tw":"4檔","ar":"السرعة الرابعة"},"Mode":{"en":"Mode","ch":"模式","fr":"maquette","ja":"モデル","it":"modello","sp":"Modo","pt":"modelo","de":"Modell","ru":"Режим","vi":"Chế độ","th":"แบบอย่าง","id":"model","zh-tw":"模式","ar":"نمط"},"Fan Speed":{"en":"Fan Speed","ch":"风速","fr":"vitesse du vent","ja":"風速","it":"velocità del vento","sp":"velocidad del viento","pt":"velocidade do vento","de":"Windgeschwindigkeit","ru":"Скорость вентилятора","vi":"Tốc độ quạt","th":"ความเร็วลม","id":"kelajuan angin","zh-tw":"風速","ar":"سرعة الرياح"},"Power off after sleep":{"en":"Power off after sleep","ch":"风速","fr":"vitesse du vent","ja":"風速","it":"velocità del vento","sp":"velocidad del viento","pt":"velocidade do vento","de":"Windgeschwindigkeit","ru":"Выключить после сна","vi":"Tốc độ quạt","th":"ความเร็วลม","id":"kelajuan angin","zh-tw":"風速","ar":"إيقاف الطاقة بعد النوم"},"No":{"en":"No","ch":"不","fr":"Non","ja":"いいえ","it":"No","sp":"No","pt":"No","de":"No","ru":"Нет","vi":"Không","th":"ไม่","id":"Tidak","zh-tw":"不","ar":"نمط"},"Setting Successful":{"en":"Setting Successful","ch":"设置成功","fr":"Configurer avec succès","ja":"設定に成功しました","it":"Impostazione riuscita","sp":"Configuración exitosa","pt":"Configuração com Sucesso","de":"Einstellung erfolgreich","ru":"Изменения приняты","vi":"Thiết lập thành công","th":"ตั้งค่าสำเร็จ","id":"Menetapkan Sukses","zh-tw":"設定成功","ar":"مجموعة ناجحة"},"Yes, Run":{"en":"Yes, Run","ch":"是的，运行","fr":"Oui, courir","ja":"はい、実行","it":"Sì, corri","sp":"Sí, correr","pt":"Sim, corre","de":"Ja, lauf","ru":"Да","vi":"Ừ, chạy đi","th":"ใช่ วิ่ง","id":"Yes, run","zh-tw":"是的，運行","ar":"نعم ، تشغيل"},"Future temperature will be updated.":{"en":"Future temperature will be updated.","ch":"未来温度将更新","fr":"Les températures futures seront mises à jour","ja":"将来的には温度が更新されます","it":"La temperatura futura sarà aggiornata","sp":"La temperatura se actualizará en el futuro","pt":"A temperatura futura será actualizada","de":"Zukünftige Temperatur wird aktualisiert","ru":"В будущем температура будет обновляться","vi":"Nhiệt độ sẽ được cập nhật trong tương lai","th":"จะมีการปรับปรุงอุณหภูมิในอนาคต","id":"Future temperature will be updated","zh-tw":"未來溫度將更新","ar":"سيتم تحديث درجة الحرارة في المستقبل"},"Run the new sleep curve now ?":{"en":"Run the new sleep curve now ?","ch":"现在运行新的睡眠曲线？","fr":"Exécuter une nouvelle courbe de sommeil maintenant?","ja":"新しい睡眠曲線を実行しますか？","it":"Fai la nuova curva del sonno ora?","sp":"¿¿ ahora se ejecuta una nueva curva de sueño?","pt":"Faz a nova curva de sono agora?","de":"Jetzt die neue Schlafkurve laufen lassen?","ru":"Запустить режим сна прямо сейчас?","vi":"Bây giờ chạy một đường cong giấc ngủ mới?","th":"ตอนนี้เปิดเส้นโค้งการนอนหลับใหม่?","id":"Jalankan kurva tidur baru sekarang?","zh-tw":"現在運行新的睡眠曲線？","ar":"الآن تشغيل منحنى النوم الجديد ؟"},"On/Off":{"en":"On/Off","ch":"开/关","fr":"Allumé éteint","ja":"オンオフ","it":"Acceso spento","sp":"Encendido apagado","pt":"Ligado/desligado","de":"On/Off","ru":"Вкл выкл","vi":" Bật / Tắt","th":"เปิดปิด","id":"Hidup/Mati","zh-tw":"開/關","ar":"تشغيل / إيقاف"},"Power":{"en":"Power","ch":"开关机","fr":"Allumé éteint","ja":"スイッチング","it":"Acceso spento","sp":"Encendido apagado","pt":"Ligado/desligado","de":"On/Off","ru":"Вкл выкл","vi":"Nguồn","th":"เปิดปิด","id":"Power","zh-tw":"開關機","ar":"تشغيل / إيقاف"},"Setting":{"en":"Setting","ch":"设置","fr":"Paramètre","ja":"設定","it":"Impostazione","sp":"Configuración","pt":"A definir","de":"Einstellung","ru":"Параметры","vi":"Cài đặt","th":"การตั้งค่า","id":"Pengaturan","zh-tw":"設定","ar":"الضبط"},"Set":{"en":"Setting","ch":"设置","fr":"Paramètre","ja":"設定","it":"Impostazione","sp":"Configuración","pt":"A definir","de":"Einstellung","ru":"Установить","vi":"Cài đặt","th":"การตั้งค่า","id":"Pengaturan","zh-tw":"設定","ar":"الضبط"},"Smart":{"en":"Smart","ch":"智能","fr":"Smart","ja":"スマート","it":"Smart","sp":"Inteligente","pt":"Smart","de":"Smart","ru":"Умный","vi":"Thông minh","th":"อัจฉริยะ","id":"Cerdas","zh-tw":"智能","ar":"ذكي"},"Drying Clothes":{"en":"Dryer","ch":"烘干机","fr":"Séchoir","ja":"ドライヤー","it":"Essiccatore","sp":"Secador","pt":"Secador","de":"Dryer","ru":"Осушитель","vi":"Hút ẩm quần áo","th":"เครื่องเป่าแห้ง","id":"Pengering","zh-tw":"烘乾機","ar":"المجفف"},"Drying Shoes":{"en":"Drying Shoes","ch":"干鞋","fr":"Séchage de chaussures","ja":"靴の乾燥","it":"Pattini essiccatore","sp":"Secando calzado","pt":"Secar Sapatos","de":"Drying Shoes","ru":"Сушка обуви","vi":"Hút ẩm giày","th":"การเป่าแห้งรองเท้า","id":"Sepatu Pengering","zh-tw":"幹鞋","ar":"تجفيف الاحذية"},"Continuous":{"en":"Continuous","ch":"连续","fr":"Continu","ja":"連続","it":"Continuo","sp":"Continuo","pt":"Continuous","de":"Continuous","ru":"Непрерывный","vi":"Tiếp tục","th":"ต่อเนื่อง","id":"Terus-Menerus","zh-tw":"連續","ar":"متواصل"},"Timing":{"en":"Timing","ch":"定时","fr":"Horaire","ja":"タイミング","it":"tempismo","sp":"sincronización","pt":"cronometragem","de":"zeitliche Koordinierung","ru":"Настройка времени","vi":"Thời gian","th":"การตั้งเวลา","id":"Timing","zh-tw":"定時","ar":"التوقيت"},"It can't be adjusted when the water is full":{"en":"It can't be adjusted when the water is full","ch":"水满时不可调节!","fr":"Il ne peut pas être ajusté lorsque l'eau est pleine","ja":"水がいっぱいになると調整できません","it":"Non può essere regolato quando l'acqua è piena","sp":"No se puede ajustar cuando el agua está llena.","pt":"Não pode ser ajustado quando a água está cheia","de":"Kann bei vollem Wasserstand nicht angepasst werden","ru":"Нельзя отрегулировать, когда бак заполнен водой","vi":"Không thể được điều chỉnh khi nước đầy","th":"ไม่สามารถปรับได้เมื่อน้ำเต็ม","id":"Tidak bisa diatur saat air penuh","zh-tw":"水滿時不可調節!","ar":"يمكن تعديله عندما يكون الماء ممتلئاً"},"Water tank is full":{"en":"Water tank is full!","ch":"水箱水满!","fr":"Le réservoir d'eau est plein!","ja":"水タンクがいっぱいです！","it":"Il serbatoio dell'acqua è pieno!","sp":"¡El tanque de agua está lleno!","pt":"O tanque de água está cheio!","de":"Wassertank ist voll","ru":"Бак для воды полон","vi":"Bình nước đầy","th":"ถังเก็บน้ำเต็ม!","id":"Tangki air penuh!","zh-tw":"水箱水滿!","ar":"خزان الماء ممتلئ!"},"Humidity is not adjustable in current mode":{"en":"Humidity is not adjustable in current mode!","ch":"该模式湿度不可调","fr":"L'humidité n'est pas réglable en mode actuel!","ja":"現在のモードでは湿度を調整できません！","it":"L'umidità non è regolabile nella modalità corrente!","sp":"¡La humedad no es ajustable en el modo actual!","pt":"A umidade não é ajustável no modo atual!","de":"Im aktuellen Modus ist die Feuchtigkeit nicht anpassbar!","ru":"В текущем режиме влажность не регулируется","vi":"Độ ẩm không thể điều chỉnh được ở chế độ hiện tại!","th":"ไม่สามารถปรับความชื้นได้ในโหมดปัจจุบัน!","id":"Kelembaban tidak bisa disesuaikan dalam mode ini!","zh-tw":"該模式濕度不可調","ar":"الرطوبة غير قابلة للتعديل تحت الوضع الحالي!"},"Humidity is not adjustable when water is full":{"en":"Humidity is not adjustable when water is full!","ch":"水满状态湿度不可调","fr":"L'humidité n'est pas réglable lorsque l'eau est pleine!","ja":"水がいっぱいになると湿度は調整できません！","it":"L'umidità non è regolabile quando l'acqua è piena!","sp":"¡La humedad no es ajustable cuando el agua está llena!","pt":"A umidade não é ajustável quando a água está cheia!","de":"Bei vollem Wasserstand ist die Feuchtigkeit nicht anpassbar!","ru":"Влажность не регулируется, когда бак заполнен водой","vi":"Độ ẩm không thể điều chỉnh được khi nước đầy!","th":"ไม่สามารถปรับความชื้นได้เมื่อน้ำเต็ม!","id":"Kelembaban tidak bisa disesuaikan saat air penuh!","zh-tw":"水滿狀態濕度不可調","ar":"الرطوبة غير قابلة للتعديل عندما يكون الماء ممتلئاً"},"This function is not available when water is full":{"en":"This function is not available when water is full","ch":"水满状态模式不可用","fr":"Cette fonction n'est pas disponible lorsque l'eau est pleine","ja":"水がいっぱいになると、この機能は使用できません","it":"Questa funzione non è disponibile quando l'acqua è piena","sp":"Esta función no está disponible cuando el agua está llena","pt":"Esta função não está disponível quando a água está cheia","de":"Bei vollem Wasserstand ist diese Funktion nicht verfügbar","ru":"Эта функция недоступна, когда бак заполнен водой","vi":"Chức năng này không khả dụng khi nước đầy","th":"ไม่สามารถใช้ฟังก์ชันนี้ได้เมื่อน้ำเต็ม","id":"Fungsi ini tidak tersedia saat air penuh","zh-tw":"水滿狀態模式不可用","ar":"هذه الوظيفة غير متوفرة عندما يكون الماء ممتلئاً"},"This function is not adjustable in drying clothes mode":{"en":"This function is not adjustable in dryer mode","ch":"干衣模式下该功能不可调节","fr":"Cette fonction n'est pas réglable en mode sèche-linge","ja":"この機能はドライヤーモードでは調整できません","it":"Questa funzione non è regolabile in modalità asciugatrice","sp":"Esta función no es ajustable en modo secador","pt":"Esta função não é ajustável no modo de secador","de":"Diese Funktion ist im Trockner-Modus nicht anpassbar","ru":"Эта функция не регулируется в режиме сушки одежды","vi":"Chức năng này không điều chỉnh được ở chế độ Hút ẩm quần áo","th":"ไม่สามารถปรับฟังก์ชันนี้ได้ในโหมดเครื่องเป่าแห้ง","id":"Fungsi ini tidak bisa disesuaikan dalam mode pengering","zh-tw":"幹衣模式下該功能不可調節","ar":"هذه الوظيفة غير قابلة للتعديل في وضع المجفف"},"The set humidity has reached the maximum value":{"en":"The set humidity has reached the maximum value","ch":"设定湿度已是最大值","fr":"L'humidité réglée a atteint la valeur maximale","ja":"設定湿度が最大値に達しました","it":"L'umidità impostata ha raggiunto il valore massimo","sp":"La humedad configurada ha alcanzado el valor máximo","pt":"A umidade definida atingiu o valor máximo","de":"Die eingestellte Feuchtigkeit hat den Maximalwert erreicht","ru":"Установленная влажность достигла максимального значения","vi":"Độ ẩm được cài đặt đã đạt giá trị tối đa","th":"ความชื้นที่ตั้งค่าไว้ถึงค่าสูงสุดแล้ว","id":"Kelembaban yang diatur sudah mencapai nilai maksimal","zh-tw":"設定濕度已是最大值","ar":"وصلت الرطوبة المحددة إلى القيمة القصوى"},"The set humidity has reached the minimum value":{"en":"The set humidity has reached the minimum value","ch":"设定湿度已是最小值","fr":"L'humidité réglée a atteint la valeur minimale","ja":"設定湿度が最小値に達しました","it":"L'umidità impostata ha raggiunto il valore minimo","sp":"La humedad configurada ha alcanzado el valor mínimo","pt":"A umidade definida atingiu o valor mínimo","de":"Die eingestellte Feuchtigkeit hat den Minimalwert erreicht","ru":"Установленная влажность достигла минимального значения","vi":"Độ ẩm được cài đặt đã đạt giá trị tối thiểu","th":"ความชื้นที่ตั้งค่าไว้ถึงค่าต่ำสุดแล้ว","id":"Kelembaban yang diatur sudah mencapai nilai maksimal","zh-tw":"設定濕度已是最小值","ar":"وصلت الرطوبة المحددة إلى القيمة الدنيا"},"Indoor humidity":{"en":"Room Humidity","ch":"室内湿度","fr":"Humidité de la pièce","ja":"部屋の湿度","it":"Umidità della stanza","sp":"Humedad de la Habitación","pt":"Humidade do Quarto","de":"Zimmerfeuchtigkeit","ru":"Влажность в помещении","vi":"Độ ẩm Phòng","th":"ความชื้นของห้อง","id":"Kelembaban Ruangan","zh-tw":"室內濕度","ar":"رطوبة الغرفة"},"OFF":{"en":"OFF","ch":"关","fr":"éteindre","ja":"消す","it":"Spegn","sp":"Apagar","pt":"desligar","de":"ausschalten","ru":"выключить","vi":"Tắt","th":"ปิด","id":"matikan","zh-tw":"關","ar":"اطفئه"},"Timer On":{"en":"Timer On","ch":"定时开","fr":"Minuterie activée","ja":"ON時間","it":"Timer acceso","sp":"Temp. encendido","pt":"Temporizador ON","de":"Timer ein","ru":"Таймер включен","vi":"Bộ đếm thời gian Bật","th":"เครื่องตั้งเวลาเปิดอยู่","id":"Timer Menyala","zh-tw":"定時開","ar":"تشغيل المؤقت"},"Timer Off":{"en":"Timer Off","ch":"定时关","fr":"Minuterie déactivée","ja":"OFF時間","it":"Timer spento","sp":"Temp. Apagado","pt":"Temporizador OFF","de":"Timer aus","ru":"Таймер выключен","vi":"Bộ đếm thời gian Tắt","th":"เครื่องตั้งเวลาปิดอยู่","id":"Timer Mati","zh-tw":"定時關","ar":"إيقاف تشغيل المؤقت"},"Cations and Anions":{"en":"Cations and Anions","ch":"正负离子","fr":"Cations et anions","ja":"陽イオンと陰イオン","it":"Cationi e anioni","sp":"Cationes y aniones","pt":"Cátions e ânions","de":"Kationen und Anionen","ru":"Катионы и анионы","vi":"Cation và Anion","th":"ประจุบวกและประจุลบ","id":"Kation dan Anion","zh-tw":"正負離子","ar":"الكاتيونات والأنيونات"},"Cancel Timer":{"en":"Cancel Timer","ch":"取消定时","fr":"Annuler la minuterie","ja":"タイマーをキャンセル","it":"Annulla timer","sp":"Cancelar temporizador","pt":"Cancelar cronômetro","de":"Timer abbrechen","ru":"Отменить Таймер","vi":"Hủy bỏ Bộ đếm thời gian","th":"ยกเลิกเครื่องตั้งเวลา","id":"Batalkan Timer","zh-tw":"取消定時","ar":"إلغاء المؤقت"},"Turn on dehumidifier":{"en":"Turn on dehumidifier","ch":"开启除湿机","fr":"Allumez le déshumidificateur","ja":"除湿機をオンにします","it":"Accendi il deumidificatore","sp":"Encienda el deshumidificador","pt":"Ligue o desumidificador","de":"Luftentfeuchter einschalten","ru":"Включить осушитель","vi":"Bật máy khử độ ẩm","th":"เปิดเครื่องลดความชื้น","id":"Nyalakan dehumidifier","zh-tw":"開啟除濕機","ar":"تشغيل مزيل الرطوبة"},"Turn off dehumidifier":{"en":"Turn off dehumidifier","ch":"关闭除湿机","fr":"Éteignez le déshumidificateur","ja":"除湿機をオフにします","it":"Spegni il deumidificatore","sp":"Apague el deshumidificador","pt":"Desligue o desumidificador","de":"Luftentfeuchter ausschalten","ru":"Выключить осушитель","vi":"Tắt máy khử độ ẩm","th":"ปิดเครื่องลดความชื้น","id":"Matikan dehumidifier","zh-tw":"關閉除濕機","ar":"إيقاف تشغيل مزيل الرطوبة"},"It can not be controlled when the device is off":{"en":"It can not be controlled when the device is off","ch":"设备关机状态下不可以控制","fr":"Il ne peut pas être contrôlé lorsque l'appareil est éteint","ja":"デバイスがオフのときは制御できません","it":"Non può essere controllato quando il dispositivo è spento","sp":"No se puede controlar cuando el dispositivo está apagado","pt":"Não pode ser controlado quando o dispositivo está desligado","de":"Es kann nicht gesteuert werden, wenn das Gerät ausgeschaltet ist","ru":"Невозможно управлять, когда устройство выключено","vi":"Không thể điều khiển được khi thiết bị tắt","th":"ไม่สามารถควบคุมได้เมื่ออุปกรณ์ปิดอยู่","id":"Tidak bisa dikendalikan saat perangkat mati","zh-tw":"裝置關機狀態下不可以控制","ar":"لا يمكن التحكم بها عندما يكون الجهاز متوقفاً عن التشغيل"},"Timer not available when water is full":{"en":"Timer not available when water is full","ch":"水满状态下定时不可用","fr":"Minuterie non disponible lorsque l'eau est pleine","ja":"水がいっぱいになるとタイマーは利用できません","it":"Timer non disponibile quando l'acqua è piena","sp":"Temporizador no disponible cuando el agua está llena","pt":"O temporizador não está disponível quando a água está cheia","de":"Timer nicht verfügbar, wenn das Wasser voll ist","ru":"Таймер недоступен, когда бак заполнен водой","vi":"Bộ đếm thời gian không khả dụng khi nước đầy","th":"ไม่สามารถใช้เครื่องตั้งเวลาได้เมื่อน้ำเต็ม","id":"Timer tidak tersedia saat air penuh","zh-tw":"水滿狀態下定時不可用","ar":"لا يكون المؤقت متوفراً عندما يكون الماء ممتلئاً"},"Cancel":{"en":"Cancel","ch":"取消","fr":"Annuler","ja":"取消","it":"Annulla","sp":"Cancelar","pt":"Cancelar","de":"Abbrechen","ru":"Нет","vi":"Hủy bỏ","th":"ยกเลิก","id":"Batal","zh-tw":"取消","ar":"إلغاء"},"Confirm":{"en":"Confirm","ch":"确认","fr":"Confirmer","ja":"確認","it":"Conferma","sp":"Confirmar","pt":"Confirmar","de":"Bestätigen","ru":"Подтвердить","vi":"Xác nhận","th":"ยืนยัน","id":"Konfirmasi","zh-tw":"確認","ar":"تاكيد"},"Submit":{"en":"Submit","ch":"提交","fr":"Soumettre","ja":"確認","it":"Invia","sp":"Presentación","pt":"Enviar","de":"Absenden","ru":"Подтвердить","vi":"Giới thiệu","th":"ส่ง","id":"Kirim","zh-tw":"提交","ar":"قدم"},"More":{"en":"More","ch":"更多","fr":"Plus","ja":"もっと","it":"Mostra","sp":"Más","pt":"Mais","de":"Weiter","ru":"Больше","vi":"Thêm","th":"เพิ่มเติม","id":"Lebih banyak lagi","zh-tw":"更多","ar":"المزيد"},"Device sn code":{"en":"Sn code","ch":"序列码","fr":"Numéro de série","ja":"SNコード","it":"Codice Sn","sp":"Número de serie","pt":"Código SN","de":"SN Code","ru":"Sn-код","vi":"Mã Sn","th":"รหัสประจำเครื่อง","id":"Kode SN","zh-tw":"序列碼","ar":"الرمز التسلسلي"},"Version":{"en":"Plugin Version","ch":"版本","fr":"Version","ja":"バージョン","it":"Versione","sp":"Versión","pt":"Versão","de":"Ausführung","ru":"Версия","vi":"Phiên bản","th":"เวอร์ชัน","id":"Versi","zh-tw":"版次","ar":"الإصدار"},"Device Name":{"en":"Device Name","ch":"设备名称","fr":"Nom de l'appareil","ja":"設備名","it":"Nome dell'impianto","sp":"Nombre del Disp.","pt":"Nome Dispositivo","de":"Gerätename","ru":"Имя устройства","vi":"Tên Thiết bị","th":"ชื่ออุปกรณ์","id":"Nama Perangkat","zh-tw":"裝置名稱","ar":"اسم الجهاز"},"Device name":{"en":"Device Name","ch":"设备名称","fr":"Nom de l'appareil","ja":"設備名","it":"Nome dell'impianto","sp":"Nombre del Disp.","pt":"Nome Dispositivo","de":"Gerätename","ru":"Имя устройства","vi":"Tên Thiết bị","th":"ชื่ออุปกรณ์","id":"Nama Perangkat","zh-tw":"裝置名稱","ar":"اسم الجهاز"},"水泵":{"en":"Pump","ch":"泵抽","fr":"Pompe","ja":"ポンプ","it":"Pompa","sp":"Bomba","pt":"Bombear","de":"Pumpe","ru":"Помпа","vi":"Bơm","th":"ปั๊ม","id":"Pompa","zh-tw":"泵抽","ar":"المضخة"},"Очищено":{"en":"Clean","ch":"清洗","fr":"Faire le ménage","ja":"クリーン","it":"Pulito","sp":"Limpio","pt":"Limpar","de":"Sauber","ru":"Очищено","vi":"Vệ sinh","th":"ทำความสะอาด","id":"Bersihkan","zh-tw":"清洗","ar":"تنظيف"},"取消":{"en":"Cancel","ch":"取消","fr":"Annuler","ja":"取消","it":"Annulla","sp":"Cancelar","pt":"Cancelar","de":"Stornieren","ru":"Отмена","vi":"Hủy bỏ","th":"ยกเลิก","id":"Batal","zh-tw":"取消","ar":"إلغاء"},"滤网使用时间过长，请清洗滤网":{"en":"The filter has been used for too long, please clean the filter","ch":"过滤器已使用较长时间，请清洗过滤器","fr":"Le filtre a été utilisé pendant trop longtemps, veuillez nettoyer le filtre","ja":"満水時にはタイマーが使えません。","it":"Il filtro è stato utilizzato troppo a lungo, pulire il filtro","sp":"El filtro se ha utilizado durante demasiado tiempo, límpielo","pt":"O filtro foi usado por muito tempo, por favor, limpe o filtro","de":"Der Filter wurde zu lange benutzt, bitte reinigen Sie den Filter","ru":"Фильтр использовался слишком долго, очистите фильтр","vi":"Bộ lọc đã được sử dụng quá lâu, hãy vệ sinh bộ lọc","th":"คุณใช้ไส้กรองมานานเกินไป โปรดทำความสะอาดไส้กรอง","id":"Filter sudah digunakan terlalu lama, mohon bersihkan filter","zh-tw":"篩檢程式已使用較長時間，請清洗篩檢程式","ar":"الفلتر مستخدم منذ فترة طويلة للغاية، يرجى تنظيف الفلتر"},"请清洗滤网":{"en":"Please clean the filter","ch":"请清洗过滤器","fr":"Veuillez nettoyer le filtre","ja":"フィルターを清掃してください。","it":"Pulire il filtro","sp":"Por favor, limpie el filtro","pt":"Limpe o filtro","de":"Bitte den Filter reinigen","ru":"Очистите фильтр","vi":"Hãy vệ sinh bộ lọc","th":"โปรดทำความสะอาดไส้กรอง","id":"Mohon bersihkan filter","zh-tw":"請清洗篩檢程式","ar":"يرجى تنظيف الفلتر"},"Sleep Curve":{"en":"Sleep Curve","ch":"睡眠曲线","fr":"courbe du sommeil","ja":"スリープカーブ","it":"curva del sonno","sp":"curva de sueño","pt":"Curva Sono","de":"Schlafkurve","ru":"Режим сна","vi":"Chế độ ngủ","th":"สถิติการนอนหลับ","id":"keluk tidur","zh-tw":"睡眠曲線","ar":"منحنى النوم"},"Sleep curve":{"en":"Sleep Curve","ch":"睡眠曲线","fr":"Courbe de sommeil","ja":"スリープカーブ","it":"Curva del sonno","sp":"Curva de sueño","pt":"Curva de sono","de":"Schlafkurve","ru":"Режим сна","vi":"Chế độ ngủ","th":"เส้นโค้งการนอนหลับ","id":"Kurva Tidur","zh-tw":"睡眠曲線","ar":"منحنى النوم"},"Energy Monitor":{"en":"Energy Monitor","ch":"能源监测器","fr":"Moniteur d'énergie","ja":"エネルギーモニター","it":"Monitoraggio energetico","sp":"Monitor de energía","pt":"Monitor de energia","de":"Energiemonitor","ru":"Монитор энергоэффективности","vi":"Bộ kiểm soát Năng lượng","th":"เครื่องติดตามพลังงาน","id":"Monitor Energi","zh-tw":"能源監測器","ar":"شاشة مراقبة الطاقة"},"Bill Control":{"en":"Bill Control","ch":"清单控制","fr":"Contrôle des factures","ja":"ビル管理","it":"Controllo bolletta","sp":"Control de facturas","pt":"Controle de contas","de":"Rechnungskontrolle","ru":"Контроль счетов","vi":"Kiểm soát Hóa đơn","th":"การควบคุมบิล","id":"Kendali Tagihan","zh-tw":"清單控制","ar":"التحكم بالفواتير"},"Recommend Range":{"en":"Recommend Range","ch":"建议范围","fr":"Recommander la gamme","ja":"推奨範囲","it":"Consiglia gamma","sp":"Recomendar rango","pt":"Faixa Recomendada","de":"Bereich empfehlen","ru":"Рекомендуемый диапазон","vi":"Phạm vi được Khuyến nghị","th":"ช่วงที่แนะนำ","id":"Rekomendasikan Rentang","zh-tw":"建議範圍","ar":"النطاق الموصى به"},"Real-time Power":{"en":"Real-time Power","ch":"实时功率","fr":"Puissance en temps réel","ja":"リアルタイムパワー","it":"Potenza in tempo reale","sp":"Energía en tiempo real","pt":"Poder em tempo real","de":"Echtzeitleistung","ru":"Мощность в реальном времени","vi":"Công suất Thời gian thực","th":"กำลังไฟแบบเรียลไทม์","id":"Daya Real-time","zh-tw":"即時功率","ar":"الطاقة في الوقت الحقيقي"},"Yesterday cumulative":{"en":"Yesterday cumulative","ch":"昨日累计","fr":"Hier cumulatif","ja":"昨日の累積","it":"Ieri cumulativo","sp":"Ayer acumulativo","pt":"Cumulativo de ontem","de":"Gestern kumulativ","ru":"Суммарное значение за вчерашний день","vi":"Tích lũy hôm qua","th":"ยอดสะสมของเมื่อวาน","id":"Kumulasi Kemarin","zh-tw":"昨日累計","ar":"تراكم يوم أمس"},"Monthly cumulative":{"en":"Monthly cumulative","ch":"每月累计","fr":"Cumul mensuel","ja":"月間累積","it":"Cumulativo mensile","sp":"Acumulativo mensual","pt":"Cumulativo mensal","de":"Monatlich kumulativ","ru":"Месячное суммарное значение","vi":"Tích lũy hàng tháng","th":"ยอดสะสมประจำเดือน","id":"Kumulasi Bulanan","zh-tw":"每月累計","ar":"التراكم الشهري"},"Chart":{"en":"Chart","ch":"图表","fr":"Graphique","ja":"チャート","it":"Grafico","sp":"Gráfico","pt":"Gráfico","de":"Diagramm","ru":"Диаграмма","vi":"Sơ đồ","th":"แผนภูมิ","id":"Grafik","zh-tw":"圖表","ar":"مخطط بياني"},"Time":{"en":"Time","ch":"时间","fr":"Heure","ja":"時間","it":"Tempo","sp":"Tiempo","pt":"Hora","de":"Graphique","ru":"Время","vi":"Thời gian","th":"เวลา","id":"Waktu","zh-tw":"時間","ar":"الوقت"},"Limit":{"en":"Limit","ch":"限值","fr":"Limite","ja":"制限","it":"Limite","sp":"Límite","pt":"Limite","de":"Grenze","ru":"Предел","vi":"Giới hạn","th":"ขีดจำกัด","id":"Batas","zh-tw":"限值","ar":"الحد"},"Sleep curve only available in cool or heat mode":{"en":"Sleep curve is not available in current mode","ch":"睡眠曲线无法在当前模式下使用","fr":"Sleep curve n'est pas pris en charge dans ce mode","ja":"現在のモードでは、睡眠曲線はサポートしていません。","it":"Sleep curve non è supportato in questa modalità.","sp":"Sleep curve no es soportado en este modo","pt":"Sleep curve não é suportado neste modo","de":"Sleep curve ist in diesem Modus nicht unterstützt.","ru":"Кривая сна доступна только в режиме охлаждения или обогрева","vi":"Chế độ giấc ngủ không được hỗ trợ cho Làm lạnh hay Sưởi ấm","th":"ไม่รองรับโหมด Sleep curve ในโหมดนี้","id":"Kurva tidur tidak didukung dalam mode ini","zh-tw":"睡眠曲線無法在當前模式下使用","ar":"منحنى النوم غير مدعوم في هذا الوضع"},"Terminal barcode":{"en":"Terminal barcode","ch":"终端条形码","fr":"Code à barres terminal","ja":"ターミナルバーコード","it":"Cod. a barre term.","sp":"Código de Barras Terminal","pt":"Código de barras","de":"Barcode Endgerät","ru":"Штрих-код терминала","vi":"Mã vạch trạm","th":"เทอร์มินัลบาร์โค้ด","id":"Kode bar terminal","zh-tw":"終端條碼","ar":"الباركود الطرفي"},"Refresh Function":{"en":"Refresh Function","ch":"刷新功能","fr":"Fonction de rafraîchissement","ja":"リフレッシュ機能","it":"Funzione di aggiornamento","sp":"Función de actualización","pt":"Recarregar Informações","de":"Aktualisierungsfunktion","ru":"Функция Refresh","vi":"Chức năng Làm sạch","th":"ฟังก์ชันการรีเฟรช","id":"Segarkan Fungsi","zh-tw":"整理功能","ar":"وظيفة التجديد"},"Label name contains illegal characters!":{"en":"Label name contains illegal characters!","ch":"标签名称包含非法字符!","fr":"Le nom de l 'étiquette contient des caractères illégaux!","ja":"ラベル名に不正文字が含まれています！","it":"Il nome dell'etichetta contiene caratteri illegali!","sp":"¡El nombre de la etiqueta contiene caracteres ilegales!","pt":"Nome do rótulo contém caracteres ilegais!","de":"Der Name des Labels enthält illegale Zeichen!","ru":"Название лэйбла содержит запрещенные символы!","vi":"Tên nhãn có ký tự không hợp lệ!","th":"ชื่อฉลากมีอักขระที่ไม่ถูกต้อง","id":"Nama label mengandung karakter yang tidak sah!","zh-tw":"標識名稱包含非法字元!","ar":"اسم الملصق يحتوي على أحرف غير قانونية"},"You can modify sleep curve in the chart":{"en":"You can modify sleep curve in the chart","ch":"您可修改图表中的睡眠曲线","fr":"Vous pouvez modifier la courbe de sommeil dans le graphique","ja":"リフレッシュ機能チャートのスリープカーブを変更することができます。","it":"Puoi modificare la curva del sonno nel grafico","sp":"Puede modificar la curva de sueño en el gráfico.","pt":"Ajuste a temperatura a cada hora como desejar","de":"Sie können die Schlafkurve im Diagramm ändern","ru":"Вы можете изменить кривую сна на диаграмме","vi":"Bạn có thể điều chỉnh chế độ giấc ngủ trong sơ đồ","th":"คุณสามารถแก้ไขสถิติการนอนหลับได้ในแผนภูมินี้","id":"Anda bisa memodifikasi kurva tidur dalam grafik","zh-tw":"您可修改圖表中的睡眠曲線","ar":"يمكن تعديل منحنى النوم في المخطط البياني"},"JetCool":{"en":"CoolFlash","ch":"急速制冷","fr":"Refroidissement rapide","ja":"急冷","it":"Raffreddamento rapido","sp":"Enfriamiento rapido","pt":"Resfriamento rápido","de":"Schnelles Kühlen","ru":"Быстрое охлаждение","vi":"Làm lạnh nhanh","th":"ระบายความร้อนอย่างรวดเร็ว","id":"Penyejukan pantas","zh-tw":"急速製冷","ar":"التبريد السريع"},"On":{"en":"On","ch":"开","fr":"allumer","ja":"オンにする","it":"accendere","sp":"Encender","pt":"Ligado","de":"schalte ein","ru":"ВКЛ","vi":"Bật","th":"เปิด","id":"hidupkan","zh-tw":"開","ar":"شغله"},"Off":{"en":"Off","ch":"关","fr":"éteindre","ja":"消す","it":"Spegni","sp":"Apagar","pt":"desligar","de":"ausschalten","ru":"ВЫКЛ","vi":"Tắt","th":" ปิด","id":"matikan","zh-tw":"關","ar":"اطفئه"},"Temperature":{"en":"Temperature","ch":"温度","fr":"Température","ja":"温度","it":"Temperatura","sp":"temperatura","pt":"temperatura","de":"Temperatur","ru":"температура","vi":"Nhiệt độ","th":"อุณหภูมิ","id":"suhu","zh-tw":"溫度","ar":"درجة الحرارة"},"Description of device":{"en":"Description of device","ch":"设备说明","fr":"Description de l'appareil","ja":"デバイスの説明","it":"Descrizione del dispositivo","sp":"Descripción del dispositivo","pt":"Descrição do dispositivo","de":"Beschreibung des Geräts","ru":"Описание устройства","vi":"Mô tả thiết bị","th":"คำอธิบายของอุปกรณ์","id":"Perihalan Peranti","zh-Hant":"設備說明","ar":"وصف الجهاز"},"Firmware Update":{"en":"Firmware update","ch":"固件升级","fr":"Mise à jour du firmware","ja":"ファームウェアのアップデート","it":"Aggiornamento del firmware","sp":"Actualización del firmware","pt":"Actualização de Firmware","de":"Firmware Update","ru":"Обновление прошивки","vi":"Cập nhật phần mềm","th":"อัพเดตเฟิร์มแวร์","id":"Kemas Kini Perisian Tegar","zh-Hant":"固件升級","ar":"ترقية البرامج الثابتة"},"Firmware update automatically":{"en":"Firmware update automatically","ch":"自动固件升级","fr":"Mise à jour automatique du firmware","ja":"自動ファームウェアアップグレード","it":"Aggiornamento automatico del firmware","sp":"Actualización automática de firmware","pt":"Atualização automática de firmware","de":"Automatisches Firmware-Upgrade","ru":"Автоматическое обновление прошивки","vi":"Nâng cấp phần mềm tự động","th":"อัพเกรดเฟิร์มแวร์อัตโนมัติ","id":"Peningkatan perisian tegar automatik","zh-Hant":"自動固件升級","ar":"ترقية تلقائية للبرامج الثابتة"},"Device firmware will update to latest version automatically":{"en":"Device firmware will update to latest version automatically","ch":"设备固件将自动更新到最新版本","fr":"Le micrologiciel de l'appareil sera automatiquement mis à jour vers la dernière version","ja":"デバイスのファームウェアは自動的に最新バージョンに更新されます","it":"Il firmware del dispositivo si aggiornerà automaticamente all'ultima versione","sp":"El firmware del dispositivo se actualizará automáticamente a la última versión","pt":"O firmware do dispositivo será atualizado para a versão mais recente automaticamente","de":"Die Geräte-Firmware wird automatisch auf die neueste Version aktualisiert","ru":"Прошивка устройства автоматически обновится до последней версии","vi":"Phần mềm thiết bị sẽ tự động cập nhật lên phiên bản mới nhất","th":"เฟิร์มแวร์ของอุปกรณ์จะอัปเดตเป็นเวอร์ชันล่าสุดโดยอัตโนมัติ","id":"Perisian tegar peranti akan dikemas kini kepada versi terkini secara automatik","zh-Hant":"設備固件將自動更新到最新版本","ar":"سيتم تحديث البرامج الثابتة للجهاز إلى أحدث إصدار تلقائيًا"},"Latest version installed":{"en":"Latest version installed","ch":"已安装最新版本","fr":"La dernière version est installée","ja":"最新バージョンがインストールされています","it":"L'ultima versione è installata","sp":"La última versión está instalada","pt":"A versão mais recente está instalada","de":"Die neuste Version ist installiert","ru":"Установлена ​​последняя версия","vi":"Phiên bản mới nhất đã được cài đặt","th":"ติดตั้งเวอร์ชันล่าสุดแล้ว","id":"Versi terkini dipasang","zh-Hant":"已安裝最新版本","ar":"تم تثبيت أحدث إصدار"},"The water is full":{"en":"The condensate drain pan is full","ch":"水箱水已满","fr":"Le bac de récupération des condensats est plein","ja":"ドレンパンが満杯になっている","it":"La vaschetta di scarico della condensa è piena","sp":"La bandeja de drenaje de condensado está llena","pt":"A bandeja de drenagem de condensado está cheia","de":"Die Kondensatwanne ist voll","ru":"Поддон для слива конденсата переполнен","vi":"Nước đã đầy","th":"ถาดระบายน้ำคอนเดนเสทเต็ม","id":"Panci pembuangan kondensat penuh","zh-tw":"水箱水已满","ar":"وعاء تصريف التكثيف ممتلئ"},"sleep_curve_on":{"en":"On","ch":"开","fr":"allumer","ja":"オンにする","it":"accendere","sp":"Encender","pt":"Ligado","de":"schalte ein","ru":"включи","vi":"Bật","th":"เปิด","id":"hidupkan","zh-Hant":"開","ar":"شغله"},"sleep_curve_off":{"en":"Off","ch":"关","fr":"éteindre","ja":"消す","it":"Spegni","sp":"apagar","pt":"desligar","de":"ausschalten","ru":"выключить","vi":"Tắt","th":" ปิด","id":"matikan","zh-tw":"關","ar":"اطفئه"},"Wind blows upwad or downward to avoid direct wind on you":{"ch":"Wind blows upwad or downward to avoid direct wind on you","fr":"Wind blows upwad or downward to avoid direct wind on you","ja":"Wind blows upwad or downward to avoid direct wind on you","it":"Wind blows upwad or downward to avoid direct wind on you","sp":"Wind blows upwad or downward to avoid direct wind on you","pt":"Wind blows upwad or downward to avoid direct wind on you","de":"Wind blows upwad or downward to avoid direct wind on you","ru":"Wind blows upwad or downward to avoid direct wind on you","vi":"Wind blows upwad or downward to avoid direct wind on you","th":"Wind blows upwad or downward to avoid direct wind on you","id":"Wind blows upwad or downward to avoid direct wind on you","zh-tw":"Wind blows upwad or downward to avoid direct wind on you","ar":"Wind blows upwad or downward to avoid direct wind on you"},"FP_is_not_available_in_current_mode":{"en":"FP is not available in current mode","ch":"该模式下不支持防冻功能","fr":"La fonction antigel n'est pas prise en charge dans ce mode","ja":"このモードではフロスト保護機能はサポートされていません","it":"La funzione antigelo non è supportata in questa modalità","sp":"La función anticongelante no es compatible con este modo","pt":"A função anticongelante não é suportada neste modo","de":"Die Frostschutzfunktion wird in diesem Modus nicht unterstützt","ru":"Функция защиты от замерзания в этом режиме не поддерживается","vi":"Chức năng FP không được hỗ trợ trong chế độ này","th":"โหมดนี้ไม่รองรับฟังก์ชันป้องกันการแข็งตัว","id":"Fungsi antibeku tidak disokong dalam mod ini","zh-Hant":"該模式下不支持防凍功能","ar":"وظيفة مضاد التجمد غير مدعومة في هذا الوضع"},"FP_is_not_available_in_SleepCurve":{"en":"FP is not available in SleepCurve","ch":"睡眠曲线不支持防冻","fr":"La courbe de sommeil ne prend pas en charge la protection contre le gel","ja":"睡眠曲線はフロスト保護をサポートしていません","it":"La curva di riposo non supporta la protezione antigelo","sp":"La curva de sueño no admite la protección contra las heladas","pt":"A curva do sono não suporta a protecção contra a geada","de":"Die Schlafkurve unterstützt keinen Frostschutz","ru":"Кривая сна не поддерживает защиту от замерзания","vi":"Chế độ giấc ngủ không hỗ trợ bảo vệ sương giá","th":"สถิติการนอนหลับไม่รองรับในโหมดการป้องกันน้ำค้างแข็ง","id":"Lengkung tidur tidak menyokong antibeku","zh-Hant":"睡眠曲線不支持防凍","ar":"منحنى النوم لا يدعم التجمد"},"This_function_can_only_be_used_in_cooling_mode":{"en":"This function is not available in current mode","ch":"该功能在当前模式下不可用","fr":"Cette fonction n'est pas disponible dans le mode actuel","ja":"この機能は現在のモードでは使用できません","it":"Questa funzione non è disponibile nella modalità corrente","sp":"Esta función no está disponible en el modo actual","pt":"Esta função não está disponível no modo atual","de":"Diese Funktion ist im aktuellen Modus nicht verfügbar","ru":"Эта функция недоступна в текущем режиме","vi":"Chức năng này không khả dụng ở chế độ hiện tại","th":"ฟังก์ชันนี้ไม่พร้อมใช้งานในโหมดปัจจุบัน","id":"Fungsi ini tidak tersedia dalam mod semasa","zh-Hant":"該功能在當前模式下不可用","ar":"هذه الوظيفة غير متاحة في الوضع الحالي"},"Gear_is_not_available_in_current_mode":{"en":"Gear is not available in current mode","ch":"当前模式下不支持功率调整","fr":"Le réglage de la puissance n'est pas pris en charge dans le mode actuel","ja":"現在のモードでは、パワー調整に対応していません","it":"La regolazione della potenza non è supportata nella modalità corrente","sp":"Le réglage de la puissance n'est pas pris en charge dans le mode actuel","pt":"O ajuste da potência não é suportado no modo actual","de":"Die Leistungsanpassung wird im aktuellen Modus nicht unterstützt.","ru":"Регулировка мощности не поддерживается в текущем режиме","vi":"Chức năng tiết kiệm năng lượng Gear không được hỗ trợ ở chế độ hiện tại","th":"ไม่รองรับการปรับกำลังในโหมดปัจจุบัน","id":"Pelarasan kuasa tidak disokong dalam mod semasa","zh-Hant":"當前模式下不支持功率調整","ar":"تعديل الطاقة غير مدعوم في الوضع الحالي"},"FreshAir":{"en":"Fresh Air","ch":"新风","fr":"Air frais","ja":"新鮮な空気","it":"Aria fresca","sp":"Aire fresco","pt":"Ar fresco","de":"Frische Luft","ru":"Свежий воздух","vi":"Không khí trong lành","th":"อากาศบริสุทธิ์","id":"Udara segar","zh-Hant":"新風","ar":"رياح جديدة"},"WindDirection":{"en":"Direction","ch":"风向可视化","fr":"Visualisation du vent","ja":"風の可視化","it":"Visualizzazione del vento","sp":"Visualización del viento","pt":"Visualização do Vento","de":"Wind Visualisierung","ru":"Настройка жалюзи","vi":"Hình ảnh hóa gió","th":"การแสดทิศทางลม","id":"Visualisasi Angin","zh-Hant":"風向可視化","ar":"تصور اتجاه الرياح"},"WindDirectionUd":{"en":"Direction","ch":"风向可视化","fr":"Visualisation du vent","ja":"風の可視化","it":"Visualizzazione del vento","sp":"Visualización del viento","pt":"Visualização do Vento","de":"Wind Visualisierung","ru":"Настройка жалюзи","vi":"Hình ảnh hóa gió","th":"การแสดทิศทางลม","id":"Visualisasi Angin","zh-Hant":"風向可視化","ar":"تصور اتجاه الرياح"},"WindDirectionLr":{"en":"Direction","ch":"风向可视化","fr":"Visualisation du vent","ja":"風の可視化","it":"Visualizzazione del vento","sp":"Visualización del viento","pt":"Visualização do Vento","de":"Wind Visualisierung","ru":"Настройка жалюзи","vi":"Hình ảnh hóa gió","th":"การแสดทิศทางลม","id":"Visualisasi Angin","zh-Hant":"風向可視化","ar":"تصور اتجاه الرياح"},"WindSwing":{"en":"Wind Swing","ch":"摆风","fr":"Swing du vent","ja":"ウィンドスイング","it":"Altalena del vento","sp":"Columpio del viento","pt":"Balanço do Vento","de":"Windschaukel","ru":"Ветер Качели","vi":"Đảo gió","th":"ชิงช้าลม","id":"Ayunan Angin","zh-Hant":"擺風","ar":"سوينغ الرياح"},"TwinsType":{"en":"Twins Type","ch":"从机四向摆风","fr":"Balancement du vent dans quatre directions depuis la machine","ja":"本体からの4方向風力スイング","it":"Oscillazione del vento a quattro vie dalla macchina","sp":"Balanceo del viento en cuatro direcciones desde la máquina","pt":"Balanço do vento de quatro sentidos a partir da máquina","de":"Vierfacher Windschwung aus der Maschine","ru":"Четырехсторонние качели от машины","vi":"TwinsType","th":"สวิงสี่ทิศทางจากตัวเครื่อง","id":"Hayunan empat hala dari mesin","zh-Hant":"從機四向擺風","ar":"أربعة اتجاهات تأرجح من الجهاز"},"FourTheWind":{"en":"Four The Wind","ch":"主机四向摆风","fr":" Quatre le vent la machine principale","ja":" 本体4方向風力スイング","it":" Oscillazione del vento a quattro vie della macchina principale","sp":"Oscilación del viento en cuatro direcciones de la máquina principal","pt":"Balanço do vento de quatro direções da máquina principal","de":"Vierfache Winddrehung der Hauptmaschine","ru":"Четырехстороннее качание ветра основной машины","vi":"FourTheWind","th":"เจ้าบ้านสวิงสี่ทาง","id":"Anjurkan hayunan empat hala","zh-Hant":"主機四向擺風","ar":"تأرجح رباعي الاتجاهات"},"Up and down":{"en":"Up and down","ch":"上下","fr":"En haut et en bas","ja":"上・下","it":"Su e giù","sp":"Arriba y abajo","pt":"Acima e abaixo","de":"Auf und ab","ru":"Вверх и вниз","vi":"Lên và xuống","th":"ขึ้นและลง","id":"atas dan bawah","zh-Hant":"上下","ar":"اعلى واسفل"},"Left and right":{"en":"Left and right","ch":"左右","fr":"Gauche et droite","ja":"左右","it":"Left and right","sp":"Izquierda y derecha","pt":"Esquerda e direita","de":"Links und rechts","ru":"Слева и справа","vi":"Trái và Phải","th":"ซ้ายและขวา","id":"kiri dan kanan","zh-Hant":"左右","ar":"حول"},"Master":{"en":"Main device","ch":"主机","fr":"Appareil principal","ja":"メインデバイス","it":"Dispositivo principale","sp":"Dispositivo principal","pt":"Dispositivo principal","de":"Hauptgerät","ru":"Основное устройство","vi":"Thiết bị chính","th":"อุปกรณ์หลัก","id":"Peranti utama","zh-Hant":"主機","ar":"الجهاز الرئيسي"},"Slave":{"en":"Attributive device","ch":"从机","fr":"Appareil attributif","ja":"アトリビューションデバイス","it":"Dispositivo attributivo","sp":"Dispositivo atributivo","pt":"Dispositivo atributivo","de":"Attributives Gerät","ru":"Атрибутивное устройство","vi":"Thiết bị thuộc tính","th":"อุปกรณ์แสดงที่มา","id":"Peranti atributif","zh-Hant":"從機","ar":"جهاز الإسناد"},"Share":{"en":"Share","ch":"分享","fr":"Partager","ja":"シェア","it":"Condividi","sp":"Compartir","pt":"Partilhar","de":"Teilen Sie","ru":"Поделиться","vi":"Chia sẻ","th":"แบ่งปัน","id":"Bagikan","zh-Hant":"分享","ar":"شارك"},"Delete fail":{"en":"Delete fail","ch":"Delete fail","fr":"Delete fail","ja":"Delete fail","it":"Delete fail","sp":"Delete fail","pt":"Delete fail","de":"Delete fail","ru":"Delete fail","vi":"Xóa không thành công","th":"การลบล้มเหลว","id":"Delete fail","zh-Hant":"Delete fail","ar":"Delete fail"},"Wind blows upward to advoid direct wind on user":{"en":"Wind blows upward to advoid direct wind on user.","ch":"Wind blows upward to advoid direct wind on user.","fr":"Wind blows upward to advoid direct wind on user.","ja":"Wind blows upward to advoid direct wind on user.","it":"Wind blows upward to advoid direct wind on user.","sp":"Wind blows upward to advoid direct wind on user.","pt":"Wind blows upward to advoid direct wind on user.","de":"Wind blows upward to advoid direct wind on user.","ru":"Wind blows upward to advoid direct wind on user.","vi":"Gió thổi hướng lên trên để tránh gió thổi trực tiếp vào người sử dụng.","th":"ลมพัดขึ้นบน เพื่อหลีกเลี่ยงให้โดนผู้ใช้งาน","id":"Wind blows upward to advoid direct wind on user.","zh-Hant":"Wind blows upward to advoid direct wind on user.","ar":"Wind blows upward to advoid direct wind on user."},"Wind blows mildly":{"en":"Wind blows mildly","ch":"微风吹拂。","fr":"Le vent souffle légèrement","ja":"風は穏やかに吹く","it":"Il vento soffia lievemente","sp":"El viento sopla suavemente","pt":"O vento sopra levemente","de":"Der Wind weht mild","ru":"Ветер дует слабый","vi":"Gió thổi nhẹ","th":"สายลมพัด","id":"Angin sepoi-sepoi","zh-Hant":"微風吹拂。","ar":"ضربات النسيم"},"Windless":{"en":"Windless","ch":"无风","fr":"Sans vent","ja":"無風","it":"Senza vento","sp":"Sin viento","pt":"Sem vento","de":"Windlos","ru":"Безветренный","vi":"Không có gió","th":"ไม่มีลม","id":"Tidak ada angin","zh-Hant":"無風","ar":"لا رياح"},"Distributes a stream of air to a wider area vertically":{"en":"Distributes a stream of air to a wider area vertically","ch":"将气流垂直分布到更大的范围","fr":"Distribue un flux d'air sur une zone plus large verticalement","ja":"垂直方向により広い範囲に気流を送ることができます。","it":"Distribuisce un flusso d'aria ad un'area più ampia in verticale","sp":"Distribuye una corriente de aire a un área más amplia verticalmente","pt":"Distribui um fluxo de ar para uma área maior verticalmente","de":"Verteilt einen Luftstrom vertikal auf eine größere Fläche","ru":"Распространяет поток воздуха на большую площадь по вертикали","vi":"Phân phối luồng không khí theo chiều dọc trên một khu vực lớn hơn","th":"กระจายลมในแนวตั้งเหนือพื้นที่ขนาดใหญ่","id":"Mendistribusikan aliran udara secara vertikal ke area yang lebih luas","zh-Hant":"將氣流垂直分佈到更大的範圍","ar":"يوزع تدفق الهواء عموديًا على مساحة أكبر"},"Distributes a stream of air to a wider area horizontally":{"en":"Distributes a stream of air to a wider area horizontally","ch":"将气流水平分布到更大的范围","fr":"Distribue un flux d'air sur une zone plus large à l'horizontale","ja":"水平方向により広い範囲に風を送ることができます。","it":"Distribuisce un flusso d'aria ad un'area più ampia in orizzontale","sp":"Distribuye una corriente de aire a un área más amplia horizontalmente","pt":"Distribui um fluxo de ar para uma área maior horizontalmente","de":"Verteilt einen Luftstrom auf eine größere Fläche in horizontaler Richtung","ru":"Распределяет поток воздуха на большую площадь по горизонтали","vi":"Phân phối luồng không khí theo chiều ngang trên một khu vực lớn hơn","th":"กระจายลมในแนวนอนเหนือพื้นที่ขนาดใหญ่","id":"Distribusikan aliran udara secara horizontal ke area yang lebih luas","zh-Hant":"將氣流水平分佈到更大的範圍","ar":"توزيع تدفق الهواء أفقيًا على مساحة أكبر"},"Auto gear control to save energy":{"en":"Auto gear control to save energy","ch":"自动调节频率，节约能源","fr":"Contrôle automatique de la vitesse pour économiser l'énergie","ja":"オートギヤーコントロールで省エネ","it":"Controllo automatico della marcia per risparmiare energia","sp":"Control automático de la marcha para ahorrar energía","pt":"Controle automático de engrenagens para economizar energia","de":"Automatische Getriebesteuerung zum Energiesparen","ru":"Автоматическое управление производительностью для экономии энергии","vi":"Tự động điều chỉnh gear để tiết kiệm năng lượng","th":"ปรับความถี่อัตโนมัติเพื่อประหยัดพลังงาน","id":"Secara otomatis menyesuaikan frekuensi untuk menghemat energi","zh-Hant":"自動調節頻率，節約能源","ar":"ضبط التردد تلقائيًا لتوفير الطاقة"},"Customize the set temperature for 8 hours while you sleep":{"en":"Customize the set temperature for 8 hours while you sleep","ch":"通过设置目标温度来定制舒适睡眠","fr":"Personnalisez un sommeil confortable en définissant une température cible","ja":"目標温度を設定し、快適な眠りをカスタマイズ。","it":"Personalizzazione del sonno confortevole grazie all'impostazione della temperatura target","sp":"Personaliza un sueño confortable ajustando la temperatura objetivo","pt":"Personalizar o sono confortável, ajustando a temperatura alvo","de":"Angenehmen Schlaf durch Einstellung der Zieltemperatur","ru":"Настройте комфортный сон, задав целевую температуру","vi":"Tùy chỉnh nhiệt độ cài đặt trong 8 tiếng khi bạn ngủ","th":"ปรับแต่งการนอนหลับให้สบายด้วยการตั้งค่าอุณหภูมิ 8 ชั่วโมง","id":"Sesuaikan tidur yang nyaman dengan mengatur suhu target","zh-Hant":"通過設置目標溫度來定制舒適睡眠","ar":"قم بتخصيص نوم مريح من خلال تحديد درجة الحرارة المستهدفة"},"Customize the set temperature and sleep times":{"en":"Customize the set temperature and sleep times","ch":"通过设置目标温度来定制舒适睡眠","fr":"Personnaliser la température et la durée du sommeil","ja":"カスタム設定の温度と睡眠時間","it":"Personalizza la temperatura impostata e i tempi di sonno","sp":"Configuración personalizada de la temperatura y el tiempo de sueño","pt":"Personalize a temperatura definida e os tempos de sono","de":"Passen Sie die eingestellte Temperatur und Schlafzeiten an","ru":"Выберите условия для комфортного сна","vi":"Tùy chỉnh cài đặt nhiệt độ và thời gian ngủ","th":"กำหนดอุณหภูมิและเวลาการนอนสำหรับการตั้งค่าที่กำหนดเอง","id":"Sesuaikan tidur yang nyaman dengan mengatur suhu target","zh-Hant":"自定義設定的溫度和睡眠時間","ar":"تخصيص إعدادات درجة الحرارة و وقت النوم"},"Go to check":{"en":"Go to check","ch":"转到检查","fr":"Go to check","ja":"チェックに移動","it":"Go to check","sp":"Go to check","pt":"Ir verificar","de":"Gehe zur Überprüfung","ru":"Проверить","vi":"Đi đến kiểm tra","th":"ไปที่การตรวจสอบ","id":"Go to check","zh-Hant":"轉到檢查","ar":"الذهاب إلى التحقق من"},"Skip":{"en":"Skip","ch":"跳过","fr":"Sauter","ja":"スキップ","it":"Salta","sp":"Saltar","pt":"Saltar","de":"Überspringen","ru":"Пропустить","vi":"Bỏ qua","th":"ข้าม","id":"Langkah","zh-Hant":"跳過","ar":"تخطي"},"Next":{"en":"Next","ch":"下一步","fr":"Suivant","ja":"次へ","it":"Avanti","sp":"Siguiente","pt":"Próximo","de":"Nächster","ru":"Пропустить","vi":"Tiếp theo","th":"ถัดไป","id":"Berikutnya","zh-Hant":"下一步","ar":"التالي"},"Turn on or off the LED display on the unit.":{"en":"Turn on or off the LED display on the unit","ch":"打开或关闭设备上的LED显示","fr":"Allumez ou éteignez l'écran LED de l'unité","ja":"本体のLEDディスプレイの点灯・消灯","it":"Accendere o spegnere il display a LED dell'unità","sp":"Enciende o apaga la pantalla LED de la unidad","pt":"Ligue ou desligue o visor LED na unidade","de":"Ein- und Ausschalten der LED-Anzeige am Gerät.","ru":"Включение и выключение светодиодного дисплея на устройстве","vi":"Bật hoặc tắt màn hình LED trên thiết bị","th":"เปิดหรือปิดจอแสดงผล LED บนอุปกรณ์","id":"Nyalakan atau matikan tampilan LED pada perangkat","zh-Hant":"打開或關閉設備上的LED顯示","ar":"قم بتشغيل أو إيقاف تشغيل شاشة LED بالجهاز."},"Turn on and turn off the sound of the unit.":{"en":"Turn on and turn off the sound of the unit","ch":"打开和关闭设备的声音","fr":"Allumez et éteignez le son de l'unité","ja":"本体サウンドのON/OFF","it":"Accendere e spegnere il suono dell'unità","sp":"Enciende y apaga el sonido de la unidad","pt":"Ligue e desligue o som da unidade","de":"Ein- und Ausschalten des Geräusches des Geräts","ru":"Включение и выключение звука устройства","vi":"Bật và tắt âm thanh của thiết bị","th":"เปิดและปิดเสียงของอุปกรณ์","id":"Menghidupkan dan mematikan suara perangkat","zh-Hant":"打開和關閉設備的聲音","ar":"قم بتشغيل وإيقاف صوت الجهاز."},"The fastest way to attain the desired temperature.":{"en":"The fastest way to attain the desired temperature","ch":"以最快的方式达到所需温度","fr":"Le moyen le plus rapide d'atteindre la température souhaitée","ja":"希望の温度に最速で到達","it":"Il modo più veloce per raggiungere la temperatura desiderata","sp":"La forma más rápida de alcanzar la temperatura deseada","pt":"A maneira mais rápida de atingir a temperatura desejada","de":"Der schnellste Weg, die gewünschte Temperatur zu erreichen","ru":"Самый быстрый способ достижения желаемой температуры","vi":"Cách nhanh nhất để đạt được nhiệt độ mong muốn","th":"วิธีที่เร็วที่สุดในการเข้าถึงอุณหภูมิที่ต้องการ","id":"Cara tercepat untuk mencapai suhu yang diinginkan","zh-Hant":"以最快的方式達到所需溫度","ar":"أسرع طريقة للوصول إلى درجة الحرارة المطلوبة."},"Adjust wind direction to blow on the user.":{"en":"Adjust wind direction to blow on the user","ch":"调整风向，使其吹向用户","fr":"Réglez la direction du vent pour qu'il souffle sur l'utilisateur","ja":"風向きを調整し、風を当てないようにする","it":"Regolare la direzione del vento per evitare che soffi sull'utente","sp":"Ajustar la dirección del viento para que sople sobre el usuario","pt":"Ajuste a direção do vento para soprar sobre o usuário","de":"Einstellen der Windrichtung, damit der Wind auf den Benutzer bläst","ru":"Регулировка направления ветра, чтобы он дул на пользователя","vi":"Điều chỉnh hướng gió thổi về phía người dùng","th":"ปรับทิศทางลมให้พัดเข้าหาผู้ใช้","id":"Sesuaikan arah angin sehingga bertiup ke arah pengguna","zh-Hant":"調整風向，使其吹向用戶","ar":"اضبط اتجاه الرياح بحيث تهب باتجاه المستخدم."},"Advoid wind blowing on the user.":{"en":"Advoid wind blowing on the user","ch":"避免风吹到用户身上","fr":"Éviter que le vent ne souffle sur l'utilisateur","ja":"ユーザーに風が当たらないようにする。","it":"Evitare che il vento soffi sull'utente","sp":"Evitar que el viento sople sobre el usuario.","pt":"Evitar que o vento sopre sobre o usuário.","de":"Verhindern Sie, dass der Wind auf den Benutzer bläst","ru":"Избегайте дуновения ветра на пользователя","vi":"Tránh gió thổi vào người sử dụng","th":"หลีกเลี่ยงลมที่พัดเข้าหาผู้ใช้","id":"Hindari angin bertiup ke pengguna","zh-Hant":"避免風吹到用戶身上","ar":"تجنب هبوب الرياح للمستخدم"},"Keep the temperature at 8℃ and provide frost protection.":{"en":"Keep the temperature at 8℃ and provide frost protection","ch":"保持温度在8℃，提供防冻保护。","fr":"Maintenir la température à 8℃ et prévoir une protection contre le gel","ja":"8℃を維持し、霜対策をする。","it":"Mantenere la temperatura a 8℃ e garantire una protezione antigelo.","sp":"Mantenga la temperatura a 8℃ y proporcione protección contra las heladas.","pt":"Manter a temperatura em 8℃ e fornecer proteção contra congelamento.","de":"Halten Sie die Temperatur bei 8℃ und sorgen Sie für Frostschutz.","ru":"Поддерживайте температуру на уровне 8℃ и обеспечьте защиту от замерзания.","vi":"Giữ nhiệt độ ở 8 ° C để bảo vệ chống sương giá.","th":"รักษาอุณหภูมิไว้ที่ 8°C เพื่อป้องกันความเย็นจัด.","id":"Pertahankan suhu pada 8°C untuk memberikan perlindungan terhadap embun beku.","zh-Hant":"保持溫度在8℃，提供防凍保護。","ar":"حافظ على درجة الحرارة عند 8 درجات مئوية لتوفير الحماية من الصقيع."},"If you are away for 30mins, AC will gear down to save energy.":{"en":"If you are away for 30mins, AC will gear down to save energy","ch":"如果离开30分钟，空调就会开始自适应降频节能","fr":"Si vous vous absentez pendant 30 minutes, la climatisation se réduit pour économiser de l'énergie","ja":"30分以上不在にすると、エアコンはギアダウンして省エネになります","it":"Se ci si assenta per 30 minuti, l'AC si riduce per risparmiare energia","sp":"Si te ausentas durante 30 minutos, el aire acondicionado se reducirá para ahorrar energía","pt":"Se você estiver fora por 30mins, o ar condicionado irá se equipar para economizar energia","de":"Wenn Sie 30 Minuten abwesend sind, wird die Klimaanlage heruntergeschaltet, um Energie zu sparen","ru":"Если вы отсутствуете в течение 30 минут, кондиционер выключится для экономии энергии","vi":"Nếu bạn để trong 30 phút, máy lạnh sẽ bắt đầu giảm tần số thích ứng để tiết kiệm năng lượng","th":"หากปล่อยทิ้งไว้ 30 นาที เครื่องปรับอากาศจะเริ่มปรับลดความถี่เพื่อประหยัดพลังงาน","id":"Jika Anda pergi selama 30 menit, AC akan mulai secara adaptif mengurangi frekuensi untuk menghemat energi","zh-Hant":"如果離開30分鐘，空調就會開始自適應降頻節能","ar":"إذا غادرت لمدة 30 دقيقة ، سيبدأ مكيف الهواء في تقليل التردد بشكل تكيفي لتوفير الطاقة"},"Clean the internal side of the unit and prevent the breeding of bacteria.":{"en":"Clean the internal side of the unit and prevent the breeding of bacteria","ch":"清洁设备内部，防止细菌滋生","fr":"Nettoie la face interne de l'appareil et empêche la reproduction des bactéries","ja":"本体内部を清掃し、雑菌の繁殖を防ぐ","it":"Pulisce il lato interno dell'unità e previene la formazione di batteri","sp":"Limpie la parte interna de la unidad y evite la reproducción de bacterias","pt":"Limpe o lado interno da unidade e evite a proliferação de bactérias","de":"Reinigen Sie die Innenseite des Geräts und verhindern Sie die Vermehrung von Bakterien","ru":"Самоочистка теплообменника кондиционера и предотвращение размножения бактерий","vi":"Làm sạch bên trong thiết bị để ngăn vi khuẩn phát triển","th":"ทำความสะอาดภายในเครื่องเพื่อป้องกันการเจริญเติบโตของแบคทีเรีย","id":"Bersihkan bagian dalam perangkat untuk mencegah pertumbuhan bakteri","zh-Hant":"清潔設備內部，防止細菌滋生","ar":"نظف الجهاز من الداخل لمنع نمو البكتيريا"},"One-click to activate your pre-set favorite settings including mode, temperature and fan speed.":{"en":"One-click to activate your pre-set favorite settings including mode, temperature and fan speed","ch":"一键激活你预先设定的最爱设置，包含模式、温度和风扇速度等设置","fr":"Un seul clic pour activer vos paramètres favoris préréglés, notamment le mode, la température et la vitesse du ventilateur","ja":"モード、温度、ファンの速度など、プリセットされたお気に入りの設定をワンクリックで作動させる","it":"Basta un clic per attivare le impostazioni preferite preimpostate, tra cui modalità, temperatura e velocità della ventola","sp":"Un clic para activar sus ajustes favoritos preestablecidos, incluyendo el modo, la temperatura y la velocidad del ventilador","pt":"Um clique para ativar seus ajustes favoritos pré-definidos, incluindo modo, temperatura e velocidade do ventilador","de":"Mit einem Klick aktivieren Sie Ihre voreingestellten Lieblingseinstellungen wie Modus, Temperatur und Lüftergeschwindigkeit","ru":"Одним щелчком мыши активировать предварительно заданные любимые настройки, включая режим, температуру и скорость вентилятора","vi":"Kích hoạt bằng một nhấp chuột đối với các cài đặt yêu thích đã đặt trước, bao gồm các cài đặt như chế độ, nhiệt độ và tốc độ quạt","th":"เปิดใช้งานการตั้งค่าโปรดที่ตั้งไว้ล่วงหน้าได้ในคลิกเดียว รวมถึงการตั้งค่าต่างๆ เช่น โหมด อุณหภูมิ และความเร็วพัดลม","id":"Aktivasi sekali klik dari pengaturan favorit Anda yang telah ditentukan sebelumnya, termasuk pengaturan seperti mode, suhu, dan kecepatan kipas","zh-Hant":"一鍵激活你預先設定的最愛設置，包含模式、溫度和風扇速度等設置","ar":"تنشيط بنقرة واحدة لإعداداتك المفضلة المحددة مسبقًا ، بما في ذلك الإعدادات مثل الوضع ودرجة الحرارة وسرعة المروحة"},"Make AC work at the time set in advance":{"en":"Make AC work at the time set in advance","ch":"使空调在预先设定的时间内工作","fr":"Faites fonctionner la climatisation à l'heure fixée à l'avance","ja":"あらかじめ設定した時刻にエアコンを作動させる","it":"Far funzionare il condizionatore all'ora impostata in precedenza","sp":"Haga que el aire acondicionado funcione a la hora fijada de antemano","pt":"Faça com que a CA funcione na hora definida com antecedência.","de":"Lassen Sie die Klimaanlage zu der im Voraus eingestellten Zeit laufen.","ru":"Заставьте кондиционер работать в заранее установленное время","vi":"Làm cho máy điều hòa không khí hoạt động trong một thời gian đặt trước","th":"ทำให้เครื่องปรับอากาศทำงานตามเวลาที่ตั้งไว้ล่วงหน้า","id":"Jadikan AC berfungsi untuk waktu yang telah ditentukan sebelumnya","zh-Hant":"使空調在預先設定的時間內工作","ar":"اجعل مكيف الهواء يعمل لفترة محددة مسبقًا"},"Do not operate the device during operation":{"en":"Do not operate the device during operation.","ch":"操作过程中不要操作设备","fr":"Ne pas utiliser l'appareil pendant le fonctionnement.","ja":"操作中はデバイスを操作しないでください","it":"Non utilizzare il dispositivo durante il funzionamento","sp":"No utilice el dispositivo durante el funcionamiento","pt":"Não opere o dispositivo durante a operação","de":"Betreiben Sie das Gerät nicht während des Betriebs","ru":"Не эксплуатируйте устройство во время работы","vi":"Không vận hành thiết bị trong quá trình hoạt động","th":"ห้ามใช้งานอุปกรณ์ระหว่างการใช้งาน","id":"Jangan mengoperasikan perangkat selama pengoperasian","zh-tw":"請勿在操作過程中操作設備","ar":"لا تقم بتشغيل الجهاز أثناء التشغيل"},"Active Clean will be started soon":{"en":"Active Clean is about to start soon, it will take 20~130mins; ","ch":"即将开始主动清洁，预计需要20~130分钟","fr":"Le nettoyage actif commencera bient?t, ce qui devrait prendre de 20 à 130 minutes","ja":"間もなくアクティブクリーンが開始されます。所要時間は20〜130分です","it":"La pulizia attiva sarà avviata a breve, con una durata prevista di 20~130 minuti","sp":"La limpieza activa se iniciará pronto, lo que se espera que tome 20~130 min","pt":"A limpeza ativa será iniciada em breve, o que deve levar 20~130 min","de":"Die aktive Reinigung wird in Kürze beginnen, was voraussichtlich 20-130 Minuten dauern wird","ru":"Вскоре начнется активная очистка, которая, как ожидается, займет 20~130 минут","vi":"Hoạt động dọn dẹp sẽ sớm được bắt đầu, dự kiến sẽ mất 20 ~ 130 phút","th":"การล้างข้อมูลแบบแอคทีฟจะเริ่มต้นเร็วๆ นี้ ซึ่งคาดว่าจะใช้เวลาประมาณ 20~130 นาที","id":"Pembersihan aktif akan segera dimulai, yang diperkirakan akan memakan waktu 20~130 menit","zh-tw":"即將開始主動清潔，預計需要20~130分鐘","ar":"سيبدأ التنظيف النشط قريبًا ، والذي من المتوقع أن يستغرق من 20 إلى 130 دقيقة"},"The device cannot beoperated when it is turned off":{"en":"The device cannot beoperated when it is turned off","ch":"设备关闭时无法操作","fr":"L'appareil ne peut pas fonctionner lorsqu'il est éteint","ja":"装置の電源が切れているのに動作しない","it":"L'apparecchio non può funzionare quando è spento","sp":"El aparato no puede funcionar cuando está apagado","pt":"O dispositivo não pode ser operado quando está desligado","de":"Das Gerät kann nicht betrieben werden, wenn es ausgeschaltet ist","ru":"Устройство не может работать, когда оно выключено","vi":"Thiết bị không thể hoạt động khi nó bị tắt","th":"อุปกรณ์ไม่สามารถใช้งานได้เมื่อปิดเครื่อง","id":"Perangkat tidak dapat dioperasikan saat dimatikan","zh-tw":"設備關機後無法操作","ar":"لا يمكن تشغيل الجهاز عند إيقاف تشغيله"},"Are you sure to delete":{"en":"Are you sure to delete?","ch":"是否确认删除?","fr":"Êtes - vous sûr de vouloir supprimer ?","ja":"必ず削除する","it":"Sei sicuro di eliminare","sp":"Está seguro de que desea borrar","pt":"Are you sure to delete","de":"Are you sure to delete","ru":"Are you sure to delete","vi":"Bạn có chắc chắn muốn xóa không","th":"Are you sure to delete","id":"Are you sure to delete","zh-tw":"Are you sure to delete","ar":"Are you sure to delete"},"The water is full!":{"en":"The condensate drain pan is full！","ch":"The condensate drain pan is full！","fr":"The condensate drain pan is full！","ja":"The condensate drain pan is full！","it":"The condensate drain pan is full！","sp":"The condensate drain pan is full！","pt":"The condensate drain pan is full！","de":"The condensate drain pan is full！","ru":"The condensate drain pan is full！","vi":"Nước đã đầy!","th":"ถาดระบายน้ำคอนเดนเสทเต็ม！","id":"The condensate drain pan is full！","zh-tw":"The condensate drain pan is full！","ar":"The condensate drain pan is full！"},"My Favorite":{"en":"My Favorite","ch":"我喜愛的模式","fr":"Mon mode préféré","ja":"お気に入りのモード","it":"La mia modalità preferita","sp":"Mi modo favorito","pt":"O meu modo preferido","de":"Mein Lieblingsmodus","ru":"Любимый режим","vi":"Yêu thích","th":"ที่ฉันชื่นชอบ","id":"Mode favorit saya","zh-tw":"我喜愛的模式","ar":"وضعي المفضل"},"Run dry mode based on a target humidity level":{"en":"Run dry mode based on a target humidity level","ch":"根据目标湿度水平运行干燥模式","fr":"Faites fonctionner le mode sec en fonction d'un taux d'humidité cible","ja":"目標湿度に基づいてドライモードを実行する","it":"Eseguire la modalità a secco in base a un livello di umidità target","sp":"Funciona en modo seco en función de un nivel de humedad objetivo","pt":"Funcionamento em modo seco com base em um nível de umidade alvo","de":"Trockenmodus auf der Grundlage einer Zielfeuchtigkeitsstufe","ru":"Запускайте сухой режим на основе заданного уровня влажности","vi":"Chế độ Hút ẩm dựa trên mức độ ẩm mục tiêu","th":"เรียกใช้โหมดแห้งตามระดับความชื้นเป้าหมาย","id":"Jalankan mode kering berdasarkan tingkat kelembaban target","zh-Hant":"根據目標濕度水平運行乾燥模式","ar":"قم بتشغيل الوضع الجاف بناءً على مستوى الرطوبة المستهدف"},"Music":{"en":"Music Garden","ch":"音乐","fr":"Musique","ja":"音楽","it":"Musica","sp":"Música","pt":"Música","de":"Musik","ru":"Музыка","vi":"Nhạc","th":"ดนตรี","id":"Musik","zh-Hant":"音樂","ar":"موسيقى"},"ENNO":{"en":"iECO","ch":"iECO","fr":"iECO","ja":"iECO","it":"iECO","sp":"iECO","pt":"iECO","de":"iECO","ru":"iECO","vi":"ENNO","th":"iECO","id":"iECO","zh-Hant":"iECO","ar-sa":"iECO"},"Feature preference":{"en":"Feature preference","ch":"功能偏好","fr":"Préférence de fonctionnalité","ja":"機能の優先順位","it":"Preferenza della funzione","sp":"Preferencia de función","pt":"Preferência de características","de":"Präferenz der Funktion","ru":"Предпочтение функции","vi":"Tùy chọn tính năng","th":"คุณลักษณะที่ต้องการ","id":"Preferensi fitur","zh-Hant":"功能偏好","ar":"تفضيل الميزة"},"Run when Powered On":{"en":"Run when Powered On","ch":"开机运行","fr":"Fonctionnement sous tension","ja":"電源ON時の動作","it":"Funziona quando è acceso","sp":"Funcionar cuando está encendido","pt":"Funciona quando Ligado","de":"Einschalten, wenn eingeschaltet","ru":"Запуск при включении питания","vi":"Chạy khi bật nguồn","th":"เรียกใช้เมื่อเปิดเครื่อง","id":"Jalankan saat Dinyalakan","zh-Hant":"開機運行","ar":"تشغيل عند التشغيل"},"Save energy by intelligently adjusting frequency and temperature":{"en":"Save energy by intelligently adjusting frequency and temperature","ch":"通过智能调节","fr":"Économisez de l'énergie en ajustant intelligemment la fréquence et la température","ja":"周波数と温度をインテリジェントに調整し、エネルギーを節約します。","it":"Risparmia energia regolando in modo intelligente frequenza e temperatura","sp":"Ahorra energía ajustando de forma inteligente la frecuencia y la temperatura","pt":"Poupar energia ajustando inteligentemente a frequência e a temperatura","de":"Energie sparen durch intelligente Anpassung von Frequenz und Temperatur","ru":"Экономия энергии за счет интеллектуальной регулировки частоты и температуры","vi":"Tiết kiệm năng lượng bằng cách điều chỉnh tần số và nhiệt độ một cách thông minh","th":"ประหยัดพลังงานด้วยการปรับความถี่และอุณหภูมิอย่างชาญฉลาด","id":"Menghemat energi dengan menyesuaikan frekuensi dan suhu secara cerdas","zh-Hant":"通過智能調節","ar":"وفر الطاقة عن طريق ضبط التردد ودرجة الحرارة بذكاء"},"Model":{"en":"Model","ch":"型号","fr":"Modèle","ja":"モデル","it":"Modello","sp":"Modo","pt":"Modelo","de":"Modell","ru":"Модель","vi":"Tên sản phẩm","th":"รุ่น","id":"Model","zh-Hant":"型号","ar":"نموذج ."},"GenMode":{"en":"Gen Mode","ch":"发动机模式","fr":"Mode moteur","ja":"エンジンモード","it":"Modalità motore","sp":"Modo motor","pt":"Modo motor","de":"Motorbetrieb","ru":"Режим работы двигателя","vi":"Chế độ Gen","th":"โหมดเครื่องยนต์","id":"Mode mesin","zh-Hant":"發動機模式","ar":"وضع المحرك"},"Gear5":{"en":"Gear","ch":"Gear","fr":"Engrenage","ja":"歯車","it":"Ingranaggio","sp":"Engranaje","pt":"Equipamento","de":"Getriebe","ru":"Передача","vi":"đồ","th":"เกียร์","id":"Perlengkapan","zh-Hant":"Gear","ar":"هيأ"},"Baby":{"en":"Baby","ch":"母婴模式","fr":"Mode mère et bébé","ja":"母子手帳モード","it":"Modalità mamma e bambino","sp":"Modo madre y bebé","pt":"Modo mãe e bebé","de":"Mutter-und-Baby-Modus","ru":"Режим матери и ребенка","vi":"Trẻ em","th":"โหมดแม่ลูก","id":"Mode ibu dan bayi","zh-Hant":"母嬰模式","ar":"وضع الأم والطفل"},"Pet":{"en":"Pet","ch":"宠物模式","fr":"Mode animalier","ja":"ペットモード","it":"Modalità animale domestico","sp":"Modo mascota","pt":"Modo Pet","de":"Haustier-Modus","ru":"Режим для домашних животных","vi":"Thú cưng","th":"โหมดสัตว์เลี้ยง","id":"Mode hewan peliharaan","zh-Hant":"寵物模式","ar":"وضع الحيوانات الأليفة"},"Week":{"en":"Week","ch":"周","fr":"Semaine","ja":"週間","it":"Settimana","sp":"Semana","pt":"Semana","de":"Woche","ru":"Week","vi":"Tuần","th":"Week","id":"Week","zh-Hant":"Week","ar":"Week"},"Month":{"en":"Month","ch":"月","fr":"mois","ja":"月","it":"mese","sp":"mes","pt":"mês","de":"Monat","ru":"месяц","vi":"Tháng","th":"ดวงจันทร์","id":"Month","zh-Hant":"月","ar":"القمر"},"Year":{"en":"Year","ch":"年","fr":"Année","ja":"年","it":"Anno","sp":"Año","pt":"Ano","de":"Jahr","ru":"Год","vi":"Năm","th":"ปี","id":"Tahun","zh-Hant":"年","ar":"عام"},"Gear":{"en":"Gear","ch":"Gear","fr":"Engrenage","ja":"歯車","it":"Ingranaggio","sp":"Engranaje","pt":"Equipamento","de":"Getriebe","ru":"Передача","vi":"đồ","th":"เกียร์","id":"Perlengkapan","zh-Hant":"Gear","ar":"هيأ"},"Flash":{"en":"Flash","ch":"Flash","fr":"Puissant","ja":"パワフル","it":"Potente","sp":"Potente","pt":"Poderoso","de":"Leistungsstarke","ru":"Мощный","vi":"Chớp","th":"แฟลช","id":"Kuat","zh-Hant":"強勁","ar":"قوي"},"Cumulative":{"en":"Cumulative","ch":"累计","fr":"Cumulatif","ja":"累積","it":"Cumulativo","sp":"Acumulado","pt":"Acumulado","de":"Kumulativ","ru":"Кумулятивный","vi":"Tổng","th":"รวมทั้งหมด","id":"Kumulatif","zh-Hant":"累計","ar":"المجموع الإجمالي"},"Real-time":{"en":"Real-time","ch":"实时","fr":"Temps réel","ja":"リアルタイム","it":"Tempo reale","sp":"En tiempo real","pt":"Tempo Real","de":"Echtzeit","ru":"Реальное время","vi":"Thời gian thực","th":"เวลาจริง","id":"เวลาจริง","zh-Hant":"實時","ar":"في الوقت الحالى"},"Favorite Name":{"en":"Favorite Name","ch":"名字","fr":"Nom","ja":"名称","it":"Nome","sp":"Nombre","pt":"Nome","de":"Name","ru":"Имя","vi":"Tên yêu thích","th":"ชื่อ","id":"Nama","zh-Hant":"名字","ar":"اسم"},"Energy saver":{"en":"Energy saver","ch":"节能模式","fr":"Mode d'économie d'énergie","ja":"エナジーセービングモード","it":"Modalità di risparmio energetico","sp":"Modo de ahorro de energía","pt":"Modo de poupança de energia","de":"Energiesparmodus","ru":"Режим энергосбережения","vi":"Tiết kiệm năng lượng","th":"โหมดประหยัดพลังงาน","id":"Mode hemat energi","zh-Hant":"節能模式","ar":"وضع توفير الطاقة"},"Favorite setting":{"en":"Favorite setting","ch":"最爱设置","fr":"Cadre préféré","ja":"好きな設定","it":"Ambientazione preferita","sp":"Entorno favorito","pt":"Ambiente preferido","de":"Bevorzugte Einstellung","ru":"Любимая обстановка","vi":"Cài đặt yêu thích","th":"การตั้งค่าที่ชื่นชอบ","id":"Pengaturan favorit","zh-Hant":"最愛設置","ar":"الإعدادات المفضلة"},"has been enabled":{"en":"enable","ch":"已允许","fr":"Autorisé","ja":"許可","it":"Consentito","sp":"Permitido","pt":"Permitido","de":"Erlaubt","ru":"Разрешено","vi":"Bật","th":"อนุญาต","id":"Diizinkan","zh-Hant":"已允許","ar":"مسموح"},"enable":{"en":"enable","ch":"允许","fr":"Autorisé","ja":"許可","it":"Consentito","sp":"Permitido","pt":"Permitido","de":"Erlaubt","ru":"Разрешено","vi":"Bật","th":"อนุญาต","id":"Diizinkan","zh-Hant":"允許","ar":"السماح"},"Your favorite had been created. Do you want to run it now":{"en":"Your favorite had been created, Do you want to run it now","ch":"你的最爱设置已保存，请问要现在运行吗？","fr":"Vos paramètres préférés ont été enregistrés, voulez-vous les exécuter maintenant ?","ja":"お気に入りの設定が保存されましたが、今すぐ実行しますか？","it":"Le impostazioni preferite sono state salvate, volete eseguirle ora?","sp":"Tus ajustes favoritos se han guardado, ¿quieres ejecutarlos ahora?","pt":"As suas definições favoritas foram guardadas, quer executá-las agora?","de":"Ihre bevorzugten Einstellungen wurden gespeichert, möchten Sie sie jetzt ausführen?","ru":"Ваши любимые настройки были сохранены, хотите ли вы запустить их сейчас?","vi":"Yêu thích của bạn đã được tạo. Bạn có muốn chạy bây giờ?","th":"บันทึกการตั้งค่าโปรดของคุณแล้ว คุณต้องการเรียกใช้งานทันทีหรือไม่","id":"Pengaturan favorit Anda sudah disimpan, apakah Anda ingin menjalankannya sekarang?","zh-Hant":"你的最愛設置已保存，請問要現在運行嗎？","ar":"تم حفظ إعداداتك المفضلة ، هل ترغب في تشغيلها الآن؟"},"When powered on, the device will default to this setting":{"en":"When powered on, the device will default to this setting","ch":"当设备开机就会自动按设置运行。","fr":"Lorsque l'appareil est allumé, il fonctionne automatiquement en fonction des réglages.","ja":"電源を入れると、設定にしたがって自動的に動作します。","it":"All'accensione, il dispositivo funziona automaticamente in base alle impostazioni.","sp":"Cuando el aparato se enciende, funciona automáticamente según los ajustes.","pt":"Quando o dispositivo é ligado, funcionará automaticamente de acordo com as definições.","de":"Wenn das Gerät eingeschaltet wird, läuft es automatisch entsprechend den Einstellungen.","ru":"При включении устройства оно будет автоматически работать в соответствии с настройками.","vi":"Khi bật, thiết bị sẽ mặc định với cài đặt này","th":"เมื่อเปิดเครื่องจะทำงานโดยอัตโนมัติตามการตั้งค่า","id":"Apabila perangkat dinyalakan, maka secara otomatis akan berjalan sesuai dengan pengaturan.","zh-Hant":"當設備開機就會自動按設置運行。","ar":"عند تشغيل الجهاز ، سيتم تشغيله تلقائيًا وفقًا للإعدادات."},"Lower the level of power to save energy":{"en":"Lower the level of power to save energy","ch":"调低电量实现节能","fr":"Baisser la puissance pour économiser l'énergie","ja":"省エネのために電力を下げる","it":"Abbassare la potenza per risparmiare energia","sp":"Baja la potencia para ahorrar energía","pt":"Reduzir a potência para poupar energia","de":"Energiesparen durch Herunterfahren der Leistung","ru":"Выключите питание для экономии энергии","vi":"Giảm mức công suất để tiết kiệm năng lượng","th":"ปิดไฟเพื่อประหยัดพลังงาน","id":"Turunkan daya untuk penghematan energi","zh-Hant":"調低電量實現節能","ar":"قم بخفض الطاقة لتوفير الطاقة"},"Choose your favorite setting to activate it with one touch":{"en":"Choose your favorite setting to activate it with one touch","ch":"一键启动最爱设置","fr":"Activation d'une seule touche des réglages favoris","ja":"お気に入りの設定をワンタッチで起動","it":"Attivazione con un solo tocco delle impostazioni preferite","sp":"Activación de los ajustes favoritos con una sola pulsación","pt":"Activação com um toque das definições favoritas","de":"One-Touch-Aktivierung der bevorzugten Einstellungen","ru":"Выберите любимые настройки и активируйте их одним нажатием","vi":"Cài đặt chế độ yêu thích của bạn để kích hoạt bằng một lần chạm","th":"การตั้งค่ารายการโปรดเพียงคลิกเดียว","id":"Aktivasi pengaturan favorit dengan sekali sentuh","zh-Hant":"一鍵啟動最愛設置","ar":"بنقرة واحدة الإعدادات المفضلة"},"Choose a maximum and minimum set temperature range allowed.":{"en":"Choose your favorite setting to activate it with one touch","ch":"选择允许的最大和最小设置温度范围","fr":"Choisissez la plage de température de réglage maximale et minimale autorisée","ja":"許容最大設定温度範囲と最小設定温度範囲の選択","it":"Scegliere un intervallo di temperatura impostato massimo e minimo consentito","sp":"Elija el rango de temperatura máximo y mínimo permitido","pt":"Escolha uma faixa de temperatura máxima e mínima permitida","de":"Wählen Sie einen maximal und minimal eingestellten Temperaturbereich","ru":"Выберите максимально допустимый и минимальный диапазон температур","vi":"Chọn mức nhiệt độ tối đa và tối thiểu cho phép","th":"เลือกช่วงอุณหภูมิการตั้งค่าสูงสุดและต่ำสุดที่อนุญาต","id":"Pilih jangkauan suhu maksimum dan minimum yang diizinkan","zh-Hant":"一鍵啟動最愛設置","ar":"حدد الحد الأقصى والحد الأدنى المسموح به مجموعة درجة الحرارة"},"TempRange":{"en":"Temp. Range","ch":"温度范围","fr":"Plage de température","ja":"温度範囲","it":"Intervallo di temperatura","sp":"Temperatura","pt":"Gama de temperaturas","de":"Temperaturbereich","ru":"Температурный диапазон","vi":"Nhiệt độ. Phạm vi","th":"ช่วงอุณหภูมิ","id":"Kisaran suhu","zh-Hant":"溫度範圍","ar":"نطاق درجة حرارة"},"AiControl":{"en":"Ai Saving","ch":"智能节能","fr":"Économie d'énergie intelligente","ja":"インテリジェント・エナジー・セーブ","it":"Risparmio energetico intelligente","sp":"Ahorro inteligente de energía","pt":"Poupança inteligente de energia","de":"Intelligentes Energiesparen","ru":"Интеллектуальное энергосбережение","vi":"Ái lưu","th":"การประหยัดพลังงานอย่างชาญฉลาด","id":"Penghematan energi yang cerdas","zh-Hant":"智能節能","ar":"توفير الطاقة الذكي"},"Ai Saving":{"en":"Ai Saving","ch":"智能节能","fr":"Économie d'énergie intelligente","ja":"インテリジェント・エナジー・セーブ","it":"Risparmio energetico intelligente","sp":"Ahorro inteligente de energía","pt":"Poupança inteligente de energia","de":"Intelligentes Energiesparen","ru":"Интеллектуальное энергосбережение","vi":"Ái lưu","th":"การประหยัดพลังงานอย่างชาญฉลาด","id":"Penghematan energi yang cerdas","zh-Hant":"智能節能","ar":"توفير الطاقة الذكي"},"Cascade":{"en":"Cascade","ch":"上下环绕风","fr":"Air enveloppant de haut en bas","ja":"上下巻きのエアー","it":"Aria avvolgente su e giù","sp":"Aire envolvente arriba y abajo","pt":"Ar de enrolar para cima e para baixo","de":"Auf- und abwärts gerichtete Rundumluft","ru":"Подъем и опускание воздуха","vi":"quanh gió","th":"ลมขึ้นและลง","id":"Udara yang membungkus ke atas dan ke bawah","zh-Hant":"上下環繞風","ar":"يختفي ويهبط"},"Smart control maximizes both comfort and energy savings":{"en":"Smart control maximizes both comfort and energy savings","ch":"智能节能使舒适度和节能最大化。","fr":"L'économie d'énergie intelligente optimise le confort et l'efficacité énergétique.","ja":"インテリジェントな省エネにより、快適性とエネルギー効率を最大化します。","it":"Il risparmio energetico intelligente massimizza il comfort e l'efficienza energetica.","sp":"El ahorro inteligente de energía maximiza el confort y la eficiencia energética.","pt":"A poupança inteligente de energia maximiza o conforto e a eficiência energética.","de":"Intelligentes Energiesparen maximiert den Komfort und die Energieeffizienz.","ru":"Интеллектуальное энергосбережение обеспечивает максимальный комфорт и энергоэффективность.","vi":"Điều khiển thông minh tối đa hóa sự thoải mái và tiết kiệm năng lượng","th":"Energy Smart ช่วยเพิ่มความสะดวกสบายและประหยัดพลังงาน","id":"Penghematan energi yang cerdas memaksimalkan kenyamanan dan efisiensi energi.","zh-Hant":"智能節能使舒適度和節能最大化。","ar":"تعمل Energy Smart على زيادة الراحة وتوفير الطاقة إلى أقصى حد."},"The unit will intelligently control the device for better energy efficiency":{"en":"The unit will intelligently control the device for better energy efficiency","ch":"空调会自行调节来实现更好节能。","fr":"Le climatiseur s'ajuste lui-même pour réaliser de meilleures économies d'énergie.","ja":"エアコンはより省エネになるように自ら調整します。","it":"Il condizionatore d'aria si regolerà da solo per ottenere un migliore risparmio energetico.","sp":"El aire acondicionado se ajustará para conseguir un mayor ahorro de energía.","pt":"O ar condicionado irá ajustar-se para conseguir uma melhor poupança de energia.","de":"Das Klimagerät passt sich selbst an, um eine bessere Energieeinsparung zu erzielen.","ru":"Кондиционер настроит себя так, чтобы добиться лучшей экономии энергии.","vi":"Điều khiển thiết bị thông minh để đạt hiệu suất năng lượng tốt hơn","th":"เครื่องปรับอากาศจะปรับตัวเองเพื่อให้ได้การประหยัดพลังงานที่ดีขึ้น","id":"AC akan menyesuaikan dirinya sendiri untuk mencapai penghematan energi yang lebih baik.","zh-Hant":"空調會自行調節來實現更好節能。","ar":"سيعدل مكيف الهواء نفسه لتحقيق توفير أفضل للطاقة."},"Service Request":{"en":"Service Request","ch":"一键报修","fr":"Demandes de services","ja":"ワンタッチ修理","it":"Richiesta di servizio","sp":"Solicitud de servicio","pt":"Dienstverzoek","de":"Serviceanfrage","ru":"Просьба об обслуживании","vi":"Yêu cầu dịch vụ","th":"คำขอใช้บริการ","id":"Permintaan Servis","zh-Hant":"一鍵報修","ar":"طلب خدمة"},"Sleep Duration":{"en":"Sleep Duration","ch":"睡眠时长","fr":"Durée de la veille","ja":"スリープ時間","it":"Durata del sonno","sp":"Duração do sono","pt":"Duração do sono","de":"Dauer des Ruhezustands","ru":"Продолжительность сна","vi":"Thời gian ngủ","th":"ระยะเวลาการนอนหลับ","id":"Durasi Tidur","zh-Hant":"睡眠時長","ar":"مدة النوم"},"recommend":{"en":"recommend","ch":"建议","fr":"recommander","ja":"おすすめ","it":"consiglia","sp":"Recomendar","pt":"recomendar","de":"empfehlen","ru":"рекомендовать","vi":"gợi ý","th":"แนะนำ","id":"merekomendasikan","zh-Hant":"建議","ar":"يوصي"},"Set the temperature to change while you sleep.":{"en":"Set the temperature to change while you sleep.","ch":"调整睡眠期间的温度变化","fr":"Réglez la température pour qu'elle change pendant votre sommeil.","ja":"寝ている間に温度が変化するように設定する","it":"Impostare la variazione della temperatura durante il sonno.","sp":"Ajustar la temperatura para que cambie mientras duermes","pt":"Ajustar a temperatura para mudar enquanto dorme.","de":"Stellen Sie die Temperatur so ein, dass sie sich ändert, während Sie schlafen.","ru":"Установите изменение температуры во время сна.","vi":"Đặt nhiệt độ để thay đổi trong khi bạn ngủ.","th":"ตั้งอุณหภูมิให้เปลี่ยนแปลงในขณะที่คุณนอนหลับ","id":"Mengatur suhu agar berubah saat Anda tidur.","zh-Hant":"調整睡眠期間的溫度變化","ar":"اضبط درجة الحرارة لتغييرها أثناء النوم."},"Change to Smart Curve":{"en":"Change to Smart Curve","ch":"调整至智能曲线","fr":"Passer à la courbe intelligente","ja":"スマートカーブに変更する","it":"Passa alla curva intelligente","sp":"Cambiar a Curva Inteligente","pt":"Mudar para Smart Curve","de":"Zu Smart Curve wechseln","ru":"Переход на интеллектуальную кривую","vi":"Thay đổi thành Đường cong thông minh","th":"เปลี่ยนเป็นสมาร์ทเคิร์ฟ","id":"Mengubah ke Kurva Cerdas","zh-Hant":"調整至智能曲線","ar":"لتغيير إلى المنحنى الذكي"},"When enabled, the AC will power off at the end of the sleep cycle. When disabled,the unit will maintain the last setpoint":{"en":"When enabled, the AC will power off at the end of the sleep cycle. When disabled,the unit will maintain the last setpoint","ch":"当启用时，空调将在睡眠周期结束时关闭电源。当禁用时,设备将保持最后的设定点。","fr":"Lorsqu'il est activé, le CA s'éteint à la fin du cycle de sommeil. Lorsqu'elle est désactivée, l'unité maintient le dernier point de consigne.","ja":"有効な場合、ACはスリープサイクルの終了時に電源が切れます。無効の場合、最後の設定値を維持します。","it":"Se abilitato, il condizionatore si spegne al termine del ciclo di sonno. Se disabilitata, l'unità manterrà l'ultimo setpoint.","sp":"Si está activada, la unidad se apagará al final del ciclo de sueño. Si está desactivada, la unidad mantendrá el último valor de consigna.","pt":"Quando activado, o ar condicionado desliga-se no final do ciclo do sono. Quando desactivada, a unidade manterá o último setpoint","de":"Wenn aktiviert, schaltet sich die Klimaanlage am Ende des Schlafzyklus aus. Wenn deaktiviert, behält das Gerät den letzten Sollwert bei.","ru":"Если включена, кондиционер выключится в конце цикла сна. Если отключено, устройство будет поддерживать последнее заданное значение.","vi":"Khi được bật, AC sẽ tắt nguồn khi kết thúc chu kỳ ngủ. Khi bị tắt, thiết bị sẽ duy trì điểm cài đặt cuối cùng  ","th":"เมื่อเปิดใช้งาน AC จะปิดเมื่อสิ้นสุดรอบการนอนหลับ เมื่อปิดใช้งาน เครื่องจะรักษาค่าที่ตั้งไว้ล่าสุด  ","id":"Saat diaktifkan, AC akan mati di akhir siklus tidur. Saat dinonaktifkan, unit akan mempertahankan setpoint terakhir","zh-Hant":"當啟用時，空調將在睡眠週期結束時關閉電源。當禁用時,設備將保持最後的設定點。","ar":"عند التمكين ، سيتم إيقاف تشغيل التيار المتردد في نهاية دورة السكون. وعند التعطيل ، ستحتفظ الوحدة بآخر نقطة ضبط"}}

/***/ }),

/***/ 2:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }(); /**
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      * Created by liujim on 2017/8/26.
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      */


var _nativeService = __webpack_require__(1);

var _nativeService2 = _interopRequireDefault(_nativeService);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Helper = function () {
    function Helper() {
        _classCallCheck(this, Helper);
    }

    _createClass(Helper, null, [{
        key: "showAlertViewCommon",
        value: function showAlertViewCommon(msg, _delay) {
            var delay = _delay !== undefined ? _delay : 10;
            // setTimeout(() => {
            //     nativeService.toast(msg);    
            // }, delay);
            clearTimeout(this.requestTimer);
            this.requestTimer = setTimeout(function () {
                _nativeService2.default.toast(msg);
            }, delay);
        }
    }, {
        key: "showLoadingView",
        value: function showLoadingView(isShow) {
            if (isShow) {
                _nativeService2.default.showLoading();
            } else {
                _nativeService2.default.hideLoading();
            }
        }
    }, {
        key: "log",
        value: function log(msg) {
            console.log("weex-console ---- " + JSON.stringify(msg, null, 2));
        }
    }, {
        key: "logByTag",
        value: function logByTag(msg, tag) {
            console.log(tag + "\t" + JSON.stringify(msg, null, 2));
        }
    }, {
        key: "decimalArrayToHexStrArray",
        value: function decimalArrayToHexStrArray(origin) {
            return origin.map(function (item) {
                return item.toString(16);
            });
        }
    }, {
        key: "decimalArrayToHexStrArrayFormat",
        value: function decimalArrayToHexStrArrayFormat(origin) {
            var item = "";
            return origin.map(function (_item) {
                item = _item.toString(16);
                return item.length == 1 ? "0" + item : item;
            });
        }
    }, {
        key: "decimalArrayToHexArray",
        value: function decimalArrayToHexArray(origin) {
            return origin.map(function (item) {
                return parseInt(item); //int compatible with hex
            });
        }
    }, {
        key: "hexArrayToHexStrArray",
        value: function hexArrayToHexStrArray(origin) {
            return origin.map(function (item) {
                return item.toString(16);
            });
        }
    }, {
        key: "hexArrayToDecimalArray",
        value: function hexArrayToDecimalArray(origin) {
            return origin.map(function (item) {
                return parseInt(item) & 0xff;
            });
        }
    }, {
        key: "hexStrArrayToDecimalArray",
        value: function hexStrArrayToDecimalArray(origin) {
            return origin.map(function (item) {
                return parseInt("0x" + item) & 0xff;
            });
        }
    }, {
        key: "strArrayToIntArray",
        value: function strArrayToIntArray(origin) {
            return origin.map(function (item) {
                return parseInt(item);
            });
        }
    }, {
        key: "merge",
        value: function merge(origin, addition) {
            for (var key in addition) {
                if (_typeof(addition[key]) !== "object" || addition[key] instanceof Array) {
                    origin[key] = addition[key];
                } else {
                    this.merge(origin[key], addition[key]);
                }
            }
        }
    }, {
        key: "arrayClone",
        value: function arrayClone(orginal) {
            var result = [];

            orginal.map(function (item) {
                result.push(item);
            });

            return result;
        }
    }, {
        key: "arrayConcat",
        value: function arrayConcat(origin, addition) {
            var _this = this;

            var result = this.arrayClone(origin);
            addition.map(function (item) {
                if (!_this.inArray(result, item)) {
                    result.push(item);
                }
            });

            return result;
        }
    }, {
        key: "hexStrAlignLeft",
        value: function hexStrAlignLeft(str) {
            if (str.length < 2) {
                return "0" + str;
            } else {
                return str;
            }
        }
    }, {
        key: "inArray",
        value: function inArray(container, search) {
            var isExist = false;
            container.map(function (item) {
                if (item == search) {
                    isExist = true;
                }
            });
            return isExist;
        }
    }, {
        key: "removeSingleValueFromArray",
        value: function removeSingleValueFromArray(container, value) {
            //return by ref
            var valueIndex = 0;
            container.map(function (item, index) {
                if (item == value) {
                    valueIndex = index;
                    return;
                }
            });
            container.splice(valueIndex, 1);
        }
    }, {
        key: "getJsonLength",
        value: function getJsonLength(json) {
            var counter = 0;
            for (var i in json) {
                counter++;
            }
            return counter;
        }
    }, {
        key: "dayNameMapping",
        value: function dayNameMapping(num) {
            var dayMap = [t.getText('week_Mon'), t.getText('week_Tue'), t.getText('week_Wed'), t.getText('week_Thu'), t.getText('week_Fri'), t.getText('week_Sat'), t.getText('week_Sun')];

            var dayName = dayMap[num - 1] != undefined ? dayMap[num - 1] : "";

            return dayName;
        }
    }, {
        key: "dayArrToStr",
        value: function dayArrToStr(week) {
            var repeatDays = "";
            if (week.length != 7) {
                week.map(function (item, index) {
                    repeatDays += Helper.dayNameMapping(item);
                    if (index != week.length - 1) {
                        repeatDays += ".";
                    }
                });
            } else {
                repeatDays = t.getText('week_everyday');
            }

            return repeatDays;
        }
    }, {
        key: "UTCToLocal",
        value: function UTCToLocal(utcTime) {
            var date = new Date();
            var y = date.getUTCFullYear();
            var m = date.getUTCMonth();
            var d = date.getUTCDate();
            var s = 0;
            var utc = Date.UTC(y, m, d, parseInt(utcTime.split(":")[0]), parseInt(utcTime.split(":")[1]), s);

            var local = new Date(utc);
            var hourLocal = local.getHours().toString().length < 2 ? "0" + local.getHours() : local.getHours().toString();
            var minuteLocal = local.getMinutes().toString().length < 2 ? "0" + local.getMinutes() : local.getMinutes().toString();

            return hourLocal + ":" + minuteLocal;
        }
    }, {
        key: "localToUTC",
        value: function localToUTC(localTime) {
            var date = new Date();
            var y = date.getFullYear();
            var m = date.getMonth();
            var d = date.getDate();
            var s = 0;
            var local = new Date(y, m, d, parseInt(localTime.split(":")[0]), parseInt(localTime.split(":")[1]), s);

            var hourUTC = local.getUTCHours().toString().length < 2 ? "0" + local.getUTCHours() : local.getUTCHours().toString();
            var minuteUTC = local.getUTCMinutes().toString().length < 2 ? "0" + local.getUTCMinutes() : local.getUTCMinutes().toString();

            return hourUTC + ":" + minuteUTC;
        }
    }, {
        key: "inputFilter",
        value: function inputFilter(value) {
            //todo
            return value.replace(/[\uD83C|\uD83D|\uD83E][\uDC00-\uDFFF][\u200D|\uFE0F]|[\uD83C|\uD83D|\uD83E][\uDC00-\uDFFF]|[0-9|*|#]\uFE0F\u20E3|[0-9|#]\u20E3|[\u203C-\u3299]\uFE0F\u200D|[\u203C-\u3299]\uFE0F|[\u2122-\u2B55]|\u303D|[\\A9|\\AE]\u3030|\\uA9|\\uAE|\u3030/ig, "");
            //return value;
        }
    }, {
        key: "getShortText",
        value: function getShortText(text, maxLength) {
            var _text = text + "";
            var result = _text;

            if (_text.length > maxLength) {
                result = _text.substring(0, maxLength) + "...";
            }

            return result;
        }
    }, {
        key: "isWeixinNavigator",
        value: function isWeixinNavigator() {
            var ua = window.navigator.userAgent.toLowerCase();
            if (ua.match(/MicroMessenger/i) == 'micromessenger') {
                return true;
            } else {
                return false;
            }
        }

        /**
         * 简单数组的并集
         * @param {Array} a
         * @param {Array} b
         */


        /**
         * 简单数组的交集
         * @param {Array} a
         * @param {Array} b
         */


        /**
         * 简单数组的差集
         * @param {Array} a
         * @param {Array} b
         */

    }]);

    return Helper;
}();

Helper.clone = function (original) {
    var clone = {};
    for (var i in original) {
        if (_typeof(original[i]) === 'object') {
            clone[i] = this.clone(original[i]);
        } else {
            clone[i] = original[i];
        }
    }
    return clone;
};

Helper.cloneDeep = function (original) {
    var clone = {};
    for (var i in original) {
        if (_typeof(original[i]) === 'object' && !(original[i] instanceof Array)) {
            clone[i] = this.cloneDeep(original[i]);
        } else {
            if (original[i] instanceof Array) {
                clone[i] = this.arrayClone(original[i]);
            } else {
                clone[i] = original[i];
            }
        }
    }
    return clone;
};

Helper.parseUnsignedInt = function (origin) {
    return parseInt(origin);
};

Helper.getUnion = function (a, b) {}
//todo
;

Helper.getIntersect = function (a, b) {}
//todo
;

Helper.getDifference = function (a, b) {
    var result = [];
    result = a.concat(b).filter(function (v) {
        return a.indexOf(v) === -1 || b.indexOf(v) === -1;
    });

    return result;
};

Helper.isRealNum = function (val) {
    // 先判定是否为number
    if (typeof val !== 'number') {
        return false;
    }
    if (!isNaN(val)) {
        return true;
    } else {
        return false;
    }
};

Helper.replaceAll = function (str, placeHolder, replaceStr) {
    return str.replace(RegExp(placeHolder, "g"), replaceStr);
};

Helper.getB5LocalVersion = function () {
    // 插件缓存B5数据的版本号
    return '2023051501';
};

exports.default = Helper;

/***/ }),

/***/ 28:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  extend: function extend(targetObj, fromObj) {
    fromObj = fromObj || {};
    targetObj = targetObj || {};
    for (var key in fromObj) {
      if (fromObj.hasOwnProperty(key) && !targetObj.hasOwnProperty(key)) {
        targetObj[key] = fromObj[key];
      }
    }
    return targetObj;
  }
};

/***/ }),

/***/ 29:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = {
  arrowIcon: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABYAAAAWBAMAAAA2mnEIAAAAMFBMVEUAAAAgIyUgIyUgIyUgIyUgIyUgIyUgIyUgIyUgIyUgIyUgIyUgIyUgIyUgIyUgIyXxqNxkAAAAEHRSTlMATEYxFA4CPTgqCUMlIhsZEJGcAQAAAE5JREFUGNNjAIKLDxjgQFAewT4o6ABncwqKICQmIkkwC6oiJAyFArBKsDUKLYBzMgR3ISQKxTHZCDUIvQgzMe1CCCPchnAzwi+YfkT4HQA98hAFt122dQAAAABJRU5ErkJggg==",
  extendIcon: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA4AAAAJCAMAAAA1k+1bAAAAM1BMVEUAAACYmJiXl5eZmZmampqYmJiYmJiXl5eZmZmYmJiYmJiZmZmZmZmYmJibm5ubm5uZmZlAoLvfAAAAEHRSTlMA9fZuSmhhUfhzVziEQ0IhhORZQgAAAEJJREFUCNdFyzkSwCAMQ1Ehg9my6P6nTeF4eI3mFwJsTjNrrbn7hS2NUX4CHipxAajM6sDpUhE6o9KieOPYil96Yz7ijwK/GAbG3wAAAABJRU5ErkJggg=="
};

/***/ }),

/***/ 31:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }(); /**
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      * Created by liujim on 2017/9/25.
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      */


var _Helper = __webpack_require__(2);

var _Helper2 = _interopRequireDefault(_Helper);

var _nativeService = __webpack_require__(1);

var _nativeService2 = _interopRequireDefault(_nativeService);

var _WeexLayer = __webpack_require__(7);

var _WeexLayer2 = _interopRequireDefault(_WeexLayer);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var broadcastChannel = new BroadcastChannel('appPageData');

var MaxDelay = 3 * 1000;

var HasCache = false;

var MSmartUserManager = function () {
    function MSmartUserManager() {
        _classCallCheck(this, MSmartUserManager);
    }

    _createClass(MSmartUserManager, null, [{
        key: 'getUserInfo',
        value: function getUserInfo(success) {
            //todo
        }
    }]);

    return MSmartUserManager;
}();

var MSmartUserDeviceManager = function () {
    function MSmartUserDeviceManager() {
        _classCallCheck(this, MSmartUserDeviceManager);
    }

    _createClass(MSmartUserDeviceManager, null, [{
        key: 'getDeviceID',
        value: function getDeviceID(isWechat) {
            if (isWechat) {
                return localStorage.getItem('applianceId');
            } else {
                return bridge.getCurrentApplianceID();
            }
        }

        //getDeviceSN

        /***************************************************基础公用接口***************************************************/

    }, {
        key: 'getDeviceSN',
        value: function getDeviceSN(isWechat) {
            if (isWechat) {
                return localStorage.getItem('sn');
            } else {
                return bridge.getCurrentDevSN();
            }
        }

        /***************************************************设备通信接口***************************************************/

    }, {
        key: 'sendDeviceData',
        value: function sendDeviceData(deviceID, sendBitsDecimal, tag, context) {
            console.log("MSTransportNotification -- sending", sendBitsDecimal, tag);
            console.log("MSTransportNotification -- sending", _Helper2.default.decimalArrayToHexStrArray(sendBitsDecimal), tag);

            var _context = broadcastChannel;

            var requestToken = new Date().valueOf(); // OR CMD ID

            // Helper.decimalArrayToHexStrArray(sendBitsDecimal)

            return requestToken;
        }

        /***************************************************服务器通信接口***************************************************/

    }, {
        key: 'callWebService',
        value: function callWebService(queryString, _jsonData, success, error, _hasCache, cacheCallback) {
            //fault-tolerance
            var jsonData = {};
            for (var key in _jsonData) {
                if (_jsonData[key] != undefined && _jsonData[key] != null) {
                    jsonData[key] = _jsonData[key];
                }
            }
            // jsonData.type = '0xAC';

            var functionParamers = {
                type: '0xAC',
                queryStrings: {
                    "serviceUrl": queryString
                },
                transmitData: jsonData
            };

            //cache process A
            var hasCache = _hasCache === undefined ? HasCache : _hasCache;
            var uuid = jsonData.applianceId !== undefined ? jsonData.applianceId : "";
            uuid += queryString;
            hasCache && _WeexLayer2.default.getCache(uuid, function (data) {
                data !== null && cacheCallback && cacheCallback(data);
            });

            _nativeService2.default.requestDataTransmit(functionParamers).then(function (data) {
                _Helper2.default.logByTag(data, "======requestDataTransmit======data");

                // nativeService.toast(data);
                // nativeService.alert(JSON.stringify(data));

                //cache process B
                hasCache && _WeexLayer2.default.setCache(uuid, data);
                success && success(data);
            }).catch(function (errorMsg) {
                _Helper2.default.logByTag(errorMsg, "======requestDataTransmit======error");

                // nativeService.toast(errorMsg);

                error && error(-1, errorMsg);
            });
        }
    }, {
        key: 'errorFilter',
        value: function errorFilter(data) {
            if (data.status == 0) {
                if (data.returnData) {
                    var dataObj = JSON.parse(data.returnData);

                    if (dataObj.errCode == 0) {
                        return dataObj.result === undefined ? true : dataObj.result;
                    } else {
                        return false;
                    }
                } else {
                    return false;
                }
            } else {
                return false;
            }
        }
    }, {
        key: 'webserviceApdater',
        value: function webserviceApdater(isViaServer, url, parameters, success, error, _hasCache, cacheCallback) {
            var _this = this;

            //todo
            //let cache = this.restoreServerData(url, parameters);
            var cache = false;

            var timerKey = this.generateUri(url, parameters);

            this.callWebService(url, parameters, function (data) {
                _this.resetRequestTimer(timerKey);
                // data && this.cacheServerData(url, parameters, data);
                success && success(data);
            }, function (errorCode, errorMsg) {
                _this.resetRequestTimer(timerKey);

                if (cache !== false) {
                    success && success(cache);
                } else {
                    error && error(errorCode, errorMsg);
                }
            }, _hasCache, cacheCallback);

            // this.resetRequestTimer();
            this.requestTimer[timerKey] = setTimeout(function () {
                if (cache !== false) {
                    success && success(cache);
                }
            }, MaxDelay);
        }
    }, {
        key: 'resetRequestTimer',
        value: function resetRequestTimer(timerKey) {
            this.requestTimer[timerKey] !== null && clearTimeout(this.requestTimer[timerKey]);
        }
    }, {
        key: 'cacheServerData',
        value: function cacheServerData(url, params, data) {
            //todo
            // localStorage.setItem(this.generateUri(url, params), JSON.stringify(data));
            // console.log(this.generateUri(url, params), JSON.stringify(data), "caching....");
        }
    }, {
        key: 'restoreServerData',
        value: function restoreServerData(url, params) {
            //todo
            // let store = localStorage.getItem(this.generateUri(url, params));
            // let result = store !== undefined ? JSON.parse(store) : false;
            // return result;
            return {};
        }
    }, {
        key: 'generateUri',
        value: function generateUri(url, params) {
            return url + JSON.stringify(params);
        }
    }]);

    return MSmartUserDeviceManager;
}();

MSmartUserDeviceManager.requestTimer = [];


var SLKDecorator = {
    MSmartUserManager: MSmartUserManager,
    MSmartUserDeviceManager: MSmartUserDeviceManager
};

exports.default = SLKDecorator;

/***/ }),

/***/ 32:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }(); /**
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      * Created by liujim on 2017/10/22.
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      */


var _SLKDecorator = __webpack_require__(31);

var _SLKDecorator2 = _interopRequireDefault(_SLKDecorator);

var _nativeService = __webpack_require__(1);

var _nativeService2 = _interopRequireDefault(_nativeService);

var _Helper = __webpack_require__(2);

var _Helper2 = _interopRequireDefault(_Helper);

var _web = __webpack_require__(33);

var _web2 = _interopRequireDefault(_web);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var bridgeModule = weex.requireModule('bridgeModule');

/*OEM*/
var ElectricityLimit = "/electricityLimit/queryLimit";
var StartLimit = "/electricityLimit/startLimit";
var StopLimit = "/electricityLimit/stopLimit";
var QueryRatio = "/electricityLimit/queryRatio";
var QueryElec = "/electricity/queryElec";
var AddApplianceAppoint = "/applianceappoint/addApplianceAppoint";
var UpdateApplianceAppoint = "/applianceappoint/updateApplianceAppoint";
var StartApplianceAppoint = "/applianceappoint/startApplianceAppoint";
var CloseApplianceAppoint = "/applianceappoint/closeApplianceAppoint";
var GetApplianceAppointList = "/applianceappoint/getApplianceAppointList";
var GetSleepCurveStatus = "/sleepcurve/getSleepCurveStatus";
var StartSleepCurve = "/sleepcurve/startSleepCurve";
var CloseSleepCurve = "/sleepcurve/closeSleepCurve";
var UpdateSleepCurve = "/sleepcurve/updateSleepCurve";
var _StartACCheck = "/acCheck/startACCheck";
var _AcCheckDetails = "/acCheck/acCheckDetails";
var _getACCheckScore = "/acCheck/getACCheckScore";

/*EMS*/
var _queryOptimizeScene = "/scene/ems/queryOptimizeScene"; //7.11 查询一键优化场景
var _initOptimizeScene = "/scene/ems/initOptimizeScene"; // 7.12 初始化一键优化场景
var _setOptimizeScene = "/scene/ems/setOptimizeScene"; //7.13 更新一键优化场景参数
var _queryTemplateScenes = "/scene/ems/queryTemplateScenes"; //7.14 查询空气机场景列表
var _uploadSceneLog = "/scene/ems/uploadSceneLog"; //7.15 上传场景开启日志
var _getFavoriteScenes = "/scene/ems/getFavoriteScenes"; //7.16 获取同城最喜欢的场景
var _getTimerList = "/timer/ems/getTimerList"; //36.1 获取闹钟列表
var _addTimer = "/timer/ems/updateTimer"; //36.2 添加闹钟
var _updateTimer = "/timer/ems/updateTimer"; //36.3 更新闹钟
var _deleteTimer = "/timer/ems/deleteTimer"; //36.4 删除闹钟
var _getTimerBroadcast = "/timer/ems/getTimerBroadcast"; //36.10 获取定时播报
var _setTimerBroadcast = "/timer/ems/setTimerBroadcast"; // 36.11 设置定时播报
var resetTimerBroadcast = "/timer/ems/resetTimerBroadcast"; //36.12 重置定时播报

var _getAreaWeatherDetail = "/weather/getAreaWeatherDetail"; //18.7 根据地址获取室外天气
var _getAreaWeather24h = "/weather/getAreaWeather24h"; // 18.8.	根据地址获取24小时室外天气
var _getAreaWeather7d = "/weather/getAreaWeather7d"; //18.9 根据地址获取七天室外天气
var _reverseGeocode = "/weather/ReverseGeocode"; //18.5 经纬度坐标转换为地区地址


var _newInformationSheet = "/css/add"; //新建售后信息单
var _getServiceItems = "/css/getServiceItems"; //获取故障类型

var _update = "/ems/config/update"; //37.1 app 更新EMS配置
var _list = "/ems/config/list"; //37.2 获取EMS配置
var _statuslist = "/ems/status/list"; //37.6 获取EMS配置


var _receivesMessage = "/message/ems/history/list"; //23.24 消息接收端列表接口
var _manual = "/ems/manual/list"; //37.4 获取EMS使用手册
var _messageList = "/emsPlugMsg/list"; //37.8 1.1.	获取EMS插件消息列表
var _messagedeLeteId = "/emsPlugMsg/deleteId"; //37.8 1.1.	1.1.	删除EMS插件消息ID
var _syncId = "/emsPlugMsg/syncId";
var _getOurterUrlInfo = "/appliance/getOurterUrlInfo";
var _deletePicture = "/emsPlugMsg/deletePicture";
var _addPicture = "/emsPlugMsg/addPicture";
var _addPictureList = "/emsPlugMsg/addPictureList";
var _getPictureList = "/emsPlugMsg/getPictureList";

/*OBM海外美居*/
var _addSchedule = "/schedule/add"; //添加预约
var _updateSchedule = "/schedule/update"; //修改预约
var _removeSchedule = "/schedule/remove"; //删除预约
var _openSchedule = "/schedule/open"; //开启预约
var _closeSchedule = "/schedule/close"; //关闭预约
var _getListSchedule = "/schedule/getList";
var _electricityLimitQuery = "/electricityLimit/queryRatio"; // 获取电量取值范围
var _electricityQueryLimit = "/electricityLimit/queryLimit"; // 获取电量限额
var _electricityStartLimit = "/electricityLimit/startLimit"; // 开启电量限额
var _electricityStopLimit = "/electricityLimit/stopLimit"; // 关闭电量限额
var _getSleepCurveStatus = "/sleepcurve/getSleepCurveStatus"; // 获取睡眠曲线及状态
var _startSleepCurve = "/sleepcurve/startSleepCurve"; // 开启舒睡曲线
var closeSleepCurve = "/sleepcurve/closeSleepCurve"; // 关闭舒睡功能
var _updateSleepCurve = "/sleepcurve/updateSleepCurve"; // 修改自定义曲线
var _queryElec = "/electricity/queryElec"; // 用电统计
var productDesc = "/appliance/aboutDeviceDescription"; //产品详细信息

var _queryOtaStaus = "/ota/queryOtaStaus"; //查询OTA的版本
var _upgradeWifi = "/ota/upgradeWifi"; //升级OTA
var _abandonUpgradeWifi = "/ota/abandonUpgradeWifi"; //取消升级OTA
var _setAutoUpgradeWifi = "/ota/setAutoUpgradeWifi"; //设置自动升级OTA
var unbindDevice = "/v1/appliance/user/unbind"; //删除设备
var sheareDevice = "/v1/appliance/user/share/cancel"; //分享设备
var _userListGet = '/v1/appliance/user/list/get'; // 获取用户家电列表
// const deviceBindGet='v1/appliance/info/bind/get'  // 家电信息及绑定关系查询
var _infoModify = '/v1/appliance/info/modify'; // 家电信息修改 
var activityList = '/activity/list'; // 活动列表
var activityToken = '/activity/getToken'; // 获取用户令牌
var stateListUrl = '/activity/USNWarr22/stateList'; // 获取state列表
var _bindDevice = "/v1/appliance/user/bind"; // 绑定设备

var favoriteListUrl = '/favorite/list'; // 查询Favorite
var addFavoriteUrl = '/favorite/add'; //  新增Favorite
var updateFavoriteUrl = '/favorite/modify'; //  修改Favorite
var deleteFavoriteUrl = '/favorite/del'; //  新增Favorite

var _iserviceGet = 'intl-appconfig/config/iservice/get';

var digiremoteUrl = '/digiremote'; // 密码锁

var ennoRange = '/orac-airapp/v1/enno/range'; //节能区间
var curveAdd = '/orac-airapp/sleep/curve/modify'; //新增睡眠曲线
var _curveModify = '/orac-airapp/sleep/curve/modify'; //修改睡眠曲线
var _curveRun = '/orac-airapp/sleep/curve/run'; //启动睡眠曲线
var _curveStop = '/orac-airapp/sleep/curve/stop'; //停止睡眠曲线
var _curveDetail = '/orac-airapp/sleep/curve/detail'; //查询曲线详情
var _curveRecommend = '/orac-airapp/sleep/curve/recommend'; //查询推荐ＡＩ睡眠曲线
var iecoUrl = '/ieco/updateFirmwareVersion';
var _otaRefreshId = '/refreshId/'; // 注意后面有 /
var _powerReport = '/orac-airapp/ieco/power/report';
var _targetGet = '/orac-airapp/v1/ieco/target/get';
var _targetSet = '/orac-airapp/v1/ieco/target/set';
var _powerBoast = '/orac-airapp/ieco/power/board';

var _userPreferencesSet = '/settings/userPreferences/set';
var _userPreferencesGet = '/settings/userPreferences/get';
var deviceB5InfoSet = '/orac-airapp/ieco/power/saveb5'; //传设备B5数据

var langMap = {
    "ar": "arabic",
    "hr": "croatian",
    "en": "english",
    "fr": "french",
    "de": "Germany",
    "el": "greek",
    "hu": "hungary",
    "it": "italian",
    "ja": "japanese",
    "ko": "korean",
    "nl": "Netherlands",
    "pl": "Poland",
    "pt": "portuguese",
    "ro": "romanian",
    "ru": "russian",
    "es": "spanish",
    "se": "Sweden",
    "tr": "turkish",
    "zh": "zh-CHT"
};

var WebComDecorator = function () {
    function WebComDecorator(isViaServer, deviceId, deviceSn, familyId, mockMode) {
        _classCallCheck(this, WebComDecorator);

        this.isViaServer = isViaServer !== undefined ? isViaServer : false;
        this.deviceId = deviceId ? deviceId : "";
        this.deviceSn = deviceSn ? deviceSn : "";
        this.familyId = familyId ? familyId : "";

        this.mockMode = mockMode ? mockMode : false;

        this.runtimeTestData = {};
    }

    //获取EMS插件消息列表


    _createClass(WebComDecorator, [{
        key: 'messageList',
        value: function messageList(deviceId, success, error) {
            this.webserviceApdater(_messageList, {
                "deviceId": parseInt(this.deviceId)
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
        //删除EMS插件消息ID

    }, {
        key: 'messagedeLeteId',
        value: function messagedeLeteId(deviceId, messageID, success, error) {
            this.webserviceApdater(_messagedeLeteId, {
                "deviceId": parseInt(this.deviceId),
                "msgId": messageID
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'syncId',
        value: function syncId(deviceId, idList, success, error) {
            this.webserviceApdater(_syncId, {
                "deviceId": parseInt(this.deviceId),
                "idList": []
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        //新建售后信息单

    }, {
        key: 'newInformationSheet',
        value: function newInformationSheet(userId, customerName, phone, areaNum, areaCode, regionStr, address, serviceType, prodCode, serviceItem, serviceDesc, pubRemark, isFaultPush, success, error) {
            this.webserviceApdater(_newInformationSheet, {
                "userId": parseInt(userId),
                "customerName": customerName,
                "phone": parseInt(phone),
                "areaNum": areaNum,
                "areaCode": areaCode,
                "regionStr": regionStr + "",
                "address": address,
                "serviceType": serviceType,
                "prodCode": prodCode,
                "serviceItem": serviceItem,
                "serviceDesc": serviceDesc,
                "pubRemark": pubRemark,
                "isFaultPush": isFaultPush
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        //获取故障类型

    }, {
        key: 'getServiceItems',
        value: function getServiceItems(userId, prodCode, success, error) {
            this.webserviceApdater(_getServiceItems, {
                "userId": parseInt(userId),
                "prodCode": parseInt(prodCode)
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        //查询一键优化场景

    }, {
        key: 'queryOptimizeScene',
        value: function queryOptimizeScene(deviceId, success, error) {
            this.webserviceApdater(_queryOptimizeScene, {
                "deviceId": parseInt(this.deviceId),
                "deviceSn": this.deviceSn + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        //体检

    }, {
        key: 'StartACCheck',
        value: function StartACCheck(deviceId, success, error) {
            this.webserviceApdater(_StartACCheck, {
                "applianceId": parseInt(this.deviceId)
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
        //获取体检分数和时间

    }, {
        key: 'getACCheckScore',
        value: function getACCheckScore(deviceId, success, error) {
            this.webserviceApdater(_getACCheckScore, {
                "applianceId": parseInt(this.deviceId)
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
        //

    }, {
        key: 'AcCheckDetails',
        value: function AcCheckDetails(success, error) {
            this.webserviceApdater(_AcCheckDetails, {
                "applianceId": parseInt(this.deviceId)
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        //初始化一键优化场景

    }, {
        key: 'initOptimizeScene',
        value: function initOptimizeScene(deviceId, templateSceneId, success, error) {
            this.webserviceApdater(_initOptimizeScene, {
                "deviceId": parseInt(this.deviceId),
                "deviceSn": this.deviceSn + "",
                "templateSceneId": templateSceneId + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        //更新一键优化场景参数

    }, {
        key: 'setOptimizeScene',
        value: function setOptimizeScene(deviceId, tempSet, humidity, clean, fresh, windSpeed, mode, ion, lrSwing, udSwing, templateSceneId, success, error) {
            this.webserviceApdater(_setOptimizeScene, {
                "deviceId": parseInt(this.deviceId),
                "deviceSn": this.deviceSn + "",
                "tempSet": tempSet,
                "humidity": parseInt(humidity),
                "clean": parseInt(clean),
                "fresh": parseInt(fresh),
                "windSpeed": parseInt(windSpeed),
                "mode": parseInt(mode),
                "ion": parseInt(ion),
                "lrSwing": parseInt(lrSwing),
                "udSwing": parseInt(udSwing),
                "templateSceneId": templateSceneId
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        //查询空气机场景列表

    }, {
        key: 'queryTemplateScenes',
        value: function queryTemplateScenes(success, error) {
            this.webserviceApdater(_queryTemplateScenes, {}, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        //上传场景开启日志

    }, {
        key: 'uploadSceneLog',
        value: function uploadSceneLog(deviceId, sceneId, sceneType, success, error) {
            this.webserviceApdater(_uploadSceneLog, {
                "deviceId": parseInt(this.deviceId),
                "deviceSn": this.deviceSn + "",
                "sceneId": parseInt(sceneId),
                "sceneType": sceneType + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        //获取同城最喜欢的场景

    }, {
        key: 'getFavoriteScenes',
        value: function getFavoriteScenes(deviceId, sceneNum, success, error) {
            this.webserviceApdater(_getFavoriteScenes, {
                "deviceId": parseInt(this.deviceId),
                "deviceSn": this.deviceSn + "",
                "sceneNum": parseInt(sceneNum)
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        //获取闹钟列表

    }, {
        key: 'getTimerList',
        value: function getTimerList(deviceId, success, error) {
            this.webserviceApdater(_getTimerList, {
                "deviceId": parseInt(this.deviceId)
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'addTimer',
        value: function addTimer(deviceId, timerName, valid, time, repeat, optimizeOnoff, tempSet, mode, humidityOnoff, cleanOnoff, freshOnoff, degermingOnoff, allClose, power, isNeedExec, success, error) {
            this.webserviceApdater(_addTimer, {
                "deviceId": parseInt(this.deviceId),
                "timerName": timerName + "",
                "valid": parseInt(valid),
                "time": time + "",
                "repeat": repeat instanceof Array ? repeat : [0, 1, 2, 3, 4, 5, 6],
                "optimizeOnoff": parseInt(optimizeOnoff),
                "tempSet": parseFloat(tempSet),
                "mode": parseInt(mode),
                "humidityOnoff": parseInt(humidityOnoff),
                "cleanOnoff": parseInt(cleanOnoff),
                "freshOnoff": parseInt(freshOnoff),
                "degermingOnoff": parseInt(degermingOnoff),
                "allClose": parseInt(allClose),
                "power": parseInt(power),
                "isNeedExec": isNeedExec
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'updateTimer',
        value: function updateTimer(deviceId, timerId, timerName, valid, time, repeat, optimizeOnoff, tempSet, mode, humidityOnoff, cleanOnoff, freshOnoff, degermingOnoff, allClose, power, isNeedExec, success, error) {
            this.webserviceApdater(_updateTimer, {
                "deviceId": parseInt(this.deviceId),
                "timerId": parseInt(timerId),
                "timerName": timerName + "",
                "valid": parseInt(valid),
                "time": time + "",
                "repeat": repeat instanceof Array ? repeat : [0, 1, 2, 3, 4, 5, 6],
                "optimizeOnoff": parseInt(optimizeOnoff),
                "tempSet": parseFloat(tempSet),
                "mode": parseInt(mode),
                "humidityOnoff": parseInt(humidityOnoff),
                "cleanOnoff": parseInt(cleanOnoff),
                "freshOnoff": parseInt(freshOnoff),
                "degermingOnoff": parseInt(degermingOnoff),
                "allClose": parseInt(allClose),
                "power": parseInt(power),
                "isNeedExec": isNeedExec
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'deleteTimer',
        value: function deleteTimer(deviceId, timerId, success, error) {
            this.webserviceApdater(_deleteTimer, {
                "deviceId": parseInt(this.deviceId),
                "timerId": parseInt(timerId)
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'getTimerBroadcast',
        value: function getTimerBroadcast(deviceSn, success, error) {
            this.webserviceApdater(_getTimerBroadcast, {
                "deviceSn": this.deviceSn + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'setTimerBroadcast',
        value: function setTimerBroadcast(deviceSn, status, time, repeats, success, error) {
            this.webserviceApdater(_setTimerBroadcast, {
                "deviceSn": this.deviceSn + "",
                "status": parseInt(status),
                "time": time + "",
                "repeats": repeats + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        // startACCheck(deviceId,success,error){
        //   this.webserviceApdater(deleteTimer,{
        //     "deviceId": parseInt(this.deviceId),
        //   }, function (data) {
        //     success && success(data);
        //   }, function (errorCode,errorMsg) {
        //     error && error(errorCode,errorMsg);
        //   });
        // }

    }, {
        key: 'getAreaWeatherDetail',
        value: function getAreaWeatherDetail(longitude, latitude, city, district, success, error) {
            this.webserviceApdater(_getAreaWeatherDetail, {
                "longitude": longitude + "",
                "latitude": latitude + "",
                "city": city + "",
                "district": district + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'getAreaWeather24h',
        value: function getAreaWeather24h(longitude, latitude, city, district, success, error) {
            this.webserviceApdater(_getAreaWeather24h, {
                "longitude": longitude + "",
                "latitude": latitude + "",
                "city": city + "",
                "district": district + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'getAreaWeather7d',
        value: function getAreaWeather7d(longitude, latitude, city, district, success, error) {
            this.webserviceApdater(_getAreaWeather7d, {
                "longitude": longitude + "",
                "latitude": latitude + "",
                "city": city + "",
                "district": district + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'reverseGeocode',
        value: function reverseGeocode(longitude, latitude, success, error) {
            this.webserviceApdater(_reverseGeocode, {
                "longitude": longitude + "",
                "latitude": latitude + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'update',
        value: function update(deviceId, isApp, config, success, error) {
            this.webserviceApdater(_update, {
                "deviceId": this.deviceId + "",
                "isApp": parseInt(isApp),
                "config": config
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'list',
        value: function list(deviceId, success, error) {
            this.webserviceApdater(_list, {
                "deviceId": this.deviceId + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'statuslist',
        value: function statuslist(deviceId, success, error) {
            this.webserviceApdater(_statuslist, {
                "deviceId": this.deviceId + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'receivesMessage',
        value: function receivesMessage(deviceId, success, error) {
            this.webserviceApdater(_receivesMessage, {
                "deviceId": this.deviceId + "",
                "type": "",
                "messageType": 800,
                "from": "",
                "size": "",
                "sort": 1
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'manual',
        value: function manual(deviceId, success, error) {
            this.webserviceApdater(_manual, {
                "deviceId": this.deviceId + "",
                "isApp": 1
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'deletePicture',
        value: function deletePicture(deviceId, success, error) {
            this.webserviceApdater(_deletePicture, {
                "deviceId": this.deviceId + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'addPicture',
        value: function addPicture(deviceId, picUrl, success, error) {
            this.webserviceApdater(_addPicture, {
                deviceId: this.deviceId + "",
                url: picUrl + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'addPictureList',
        value: function addPictureList(deviceId, urls, success, error) {
            this.webserviceApdater(_addPictureList, {
                deviceId: this.deviceId + "",
                urls: urls
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'getPictureList',
        value: function getPictureList(deviceId, success, error) {
            this.webserviceApdater(_getPictureList, {
                deviceId: this.deviceId + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'getOurterUrlInfo',
        value: function getOurterUrlInfo(success, error) {
            this.webserviceApdater(_getOurterUrlInfo, {}, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        // activityList

    }, {
        key: 'getActivityList',
        value: function getActivityList(userId, success, error) {
            // nativeService.alert(1)
            this.webserviceApdater(activityList, {
                appId: '1010',
                userId: userId
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                // nativeService.alert(JSON.stringify(errorMsg));
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'getActivityToken',
        value: function getActivityToken(param, success, error) {
            this.webserviceApdater(activityToken, {
                appId: '1010',
                userId: param.userId,
                activityUUID: param.uuid
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                // nativeService.alert(JSON.stringify(errorMsg));
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'getStateList',
        value: function getStateList(param, success, error) {
            this.webserviceApdater(stateListUrl, param, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                // nativeService.alert(JSON.stringify(errorMsg));
                error && error(errorCode, errorMsg);
            });
        }

        // const addSchedule = "/schedule/add"; //添加预约
        // const updateSchedule  = "/schedule/update"; //修改预约
        // const removeSchedule = "/schedule/remove"; // 删除预约
        // const openSchedule = "/schedule/open"; //开启预约
        // const getListSchedule = "/schedule/getList";

    }, {
        key: 'addSchedule',
        value: function addSchedule(switcher, time, week, repeat, status, temperature, wind, mode, label, timezone, userId, appId, timeType, success, error) {
            this.webserviceApdater(_addSchedule, {
                applianceId: this.deviceId + "",
                switcher: switcher,
                time: time,
                week: week,
                repeat: repeat,
                status: status,
                temperature: temperature,
                wind: wind,
                mode: mode,
                label: label,
                timezone: timezone,
                userId: userId,
                appId: appId,
                time_type: timeType
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'updateSchedule',
        value: function updateSchedule(scheduleId, switcher, time, week, repeat, status, temperature, wind, mode, label, timezone, userId, appId, timeType, success, error) {
            // let a = {
            //     scheduleId:scheduleId,
            //     switcher:switcher,
            //     time:time,
            //     week:week,
            //     repeat:repeat,
            //     status:status,
            //     temperature:temperature,
            //     wind:wind,
            //     mode:mode,
            //     label:label,
            //     timezone:timezone,
            //     userId:userId,
            //     appId:appId,
            //     time_type:timeType
            // }
            // nativeService.alert(JSON.stringify(a))
            this.webserviceApdater(_updateSchedule, {
                scheduleId: scheduleId,
                switcher: switcher,
                time: time,
                week: week,
                repeat: repeat,
                status: status,
                temperature: temperature,
                wind: wind,
                mode: mode,
                label: label,
                timezone: timezone,
                userId: userId,
                appId: appId,
                time_type: timeType
            }, function (data) {
                // nativeService.alert(data)
                success && success(data);
            }, function (errorCode, errorMsg) {
                // nativeService.alert(errorMsg)
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'removeSchedule',
        value: function removeSchedule(scheduleId, success, error) {
            this.webserviceApdater(_removeSchedule, {
                scheduleId: scheduleId
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'openSchedule',
        value: function openSchedule(scheduleId, success, error) {
            this.webserviceApdater(_openSchedule, {
                scheduleId: scheduleId
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'closeSchedule',
        value: function closeSchedule(scheduleId, success, error) {
            this.webserviceApdater(_closeSchedule, {
                scheduleId: scheduleId
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'getListSchedule',
        value: function getListSchedule(success, error) {
            this.webserviceApdater(_getListSchedule, {
                applianceId: this.deviceId + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                // nativeService.alert(JSON.stringify(errorMsg));
                error && error(errorCode, errorMsg);
            });
        }

        /**
         * 查询Favorite列表
         * @param success
         * @param error
         */

    }, {
        key: 'queryFavoriteList',
        value: function queryFavoriteList(userId, success, error) {
            // nativeService.alert(`${this.deviceId}--${userId}`)
            this.webserviceApdater(favoriteListUrl, {
                applianceId: this.deviceId + "",
                userId: userId + "",
                // applianceId : "24189255812049",
                // userId: "457300",
                appId: '1010',
                page: 1,
                pageSize: 1000
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                // nativeService.alert(JSON.stringify(errorMsg));
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'addFavorite',
        value: function addFavorite(param, success, error) {
            param.applianceId = this.deviceId + "";
            param.appId = '1010';
            this.webserviceApdater(addFavoriteUrl, param, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'updateFavorite',
        value: function updateFavorite(param, success, error) {
            param.applianceId = this.deviceId + "";
            param.appId = '1010';
            this.webserviceApdater(updateFavoriteUrl, param, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'deleteFavorite',
        value: function deleteFavorite(param, success, error) {
            param.applianceId = this.deviceId + "";
            param.appId = '1010';
            this.webserviceApdater(deleteFavoriteUrl, param, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        /**
         * 密码锁
         * @param success
         * @param error
         */

    }, {
        key: 'digiremoteQueryPwd',
        value: function digiremoteQueryPwd(userId, success, error) {
            this.webserviceApdater(digiremoteUrl + '/queryPwd', {
                applianceId: this.deviceId + "",
                userId: userId + "",
                appId: '1010'
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'digiremoteCreatePwd',
        value: function digiremoteCreatePwd(param, success, error) {
            this.webserviceApdater(digiremoteUrl + '/createPwd', {
                applianceId: this.deviceId + "",
                userId: param.userId,
                appId: '1010',
                deviceSn: this.initDsn(this.deviceSn) + "",
                deviceType: '0xAC',
                password: param.password,
                applianceBleMac: param.applianceBleMac,
                enable: param.enable || true
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'digiremoteResetPwd',
        value: function digiremoteResetPwd(param, success, error) {
            this.webserviceApdater(digiremoteUrl + '/resetPwd', {
                userId: param.userId,
                appId: '1010',
                deviceSn: param.deviceSn + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'digiremoteModifyPwd',
        value: function digiremoteModifyPwd(param, success, error) {
            this.webserviceApdater(digiremoteUrl + '/modifyPwd', {
                applianceId: this.deviceId + "",
                userId: param.userId,
                appId: '1010',
                password: param.password
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'digiremoteVerifyPwd',
        value: function digiremoteVerifyPwd(param, success, error) {
            this.webserviceApdater(digiremoteUrl + '/verifyPwd', {
                applianceId: this.deviceId + "",
                userId: param.userId,
                appId: '1010',
                password: param.password
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'digiremoteEnablePwd',
        value: function digiremoteEnablePwd(param, success, error) {
            // nativeService.alert(JSON.stringify(
            //     {
            //         applianceId : this.deviceId+"",
            //         userId: param.userId,
            //         appId: '1010',
            //         enable: param.enable,
            //     }
            // ))
            this.webserviceApdater(digiremoteUrl + '/enablePwd', {
                applianceId: this.deviceId + "",
                userId: param.userId,
                appId: '1010',
                enable: param.enable
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'initDsn',
        value: function initDsn(data) {
            return data.length == 32 ? data.slice(6, -4) : data.length == 28 ? data.slice(6) : data;
        }

        /**
         * 查询电量控制范围
         * @param success
         * @param error
         */

    }, {
        key: 'electricityLimitQuery',
        value: function electricityLimitQuery(success, error) {
            this.webserviceApdater(_electricityLimitQuery, {
                applianceId: this.deviceId + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        /**
         * 获取电量限额
         * @param success
         * @param error
         */

    }, {
        key: 'electricityQueryLimit',
        value: function electricityQueryLimit(success, error) {
            this.webserviceApdater(_electricityQueryLimit, {
                applianceId: this.deviceId + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        /**
         * 开启电量限额
         * @param limitValue
         * @param time
         * @param success
         * @param error
         */

    }, {
        key: 'electricityStartLimit',
        value: function electricityStartLimit(limitValue, time, success, error) {
            this.webserviceApdater(_electricityStartLimit, {
                applianceId: this.deviceId + "",
                limitValue: limitValue + "",
                time: time + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        /**
         * 关闭电量限额
         * @param success
         * @param error
         */

    }, {
        key: 'electricityStopLimit',
        value: function electricityStopLimit(success, error) {
            this.webserviceApdater(_electricityStopLimit, {
                applianceId: this.deviceId + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        /**
         * 获取睡眠曲线及状态
         * @param success
         * @param error
         */

    }, {
        key: 'getSleepCurveStatus',
        value: function getSleepCurveStatus(mode, temp, success, error) {
            this.webserviceApdater(_getSleepCurveStatus, {
                applianceId: this.deviceId + "",
                mode: mode
            }, function (data) {
                // nativeService.alert(JSON.stringify(data)+'raw');
                success && success(data);
            }, function (errorCode, errorMsg) {
                // nativeService.alert(JSON.stringify(errorCode)+'raw'+JSON.stringify(errorMsg));
                error && error(errorCode, errorMsg);
            });
        }

        /**
         * 开启舒睡曲线
         * @param type 曲线类型，1成人曲线，2儿童曲线，3老人曲线，4自定义曲线
         * @param mode 空调模式，2制冷模式，4制热模式
         * value: 自定义曲线的温度值，只有type为4自定义曲线时，value0到value9必填
         * @param value0
         * @param value1
         * @param value2
         * @param value3
         * @param value4
         * @param value5
         * @param value6
         * @param value7
         * @param value8
         * @param value9
         * @param success
         * @param error
         */

    }, {
        key: 'startSleepCurve',
        value: function startSleepCurve(type, mode, value0, value1, value2, value3, value4, value5, value6, value7, value8, value9, success, error) {
            this.webserviceApdater(_startSleepCurve, {
                applianceId: this.deviceId + "",
                type: type,
                value0: value0,
                value1: value1,
                value2: value2,
                value3: value3,
                value4: value4,
                value5: value5,
                value6: value6,
                value7: value7,
                value8: value8,
                value9: value9
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        /**
         * 关闭舒睡功能
         * @param success
         * @param error
         */

    }, {
        key: 'CloseSleepCurve',
        value: function CloseSleepCurve(success, error) {
            this.webserviceApdater(closeSleepCurve, {
                applianceId: this.deviceId + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        /**
         * 修改自定义曲线
         * 调用更新接口后默认打开睡眠曲线，协议接口中增加一个字段isStart用来表示更新后是否开启或关闭，APP默认发送打开
         * 自定义曲线服务器需要给一个默认值，制冷睡眠曲线给26度，制热睡眠曲线给20度，修改后默认开启，备注：睡眠曲线在APP界面呈现一条，但后台要区分制热睡眠曲线和制冷睡眠曲线
         * @param type
         * @param mode
         * @param value0
         * @param value1
         * @param value2
         * @param value3
         * @param value4
         * @param value5
         * @param value6
         * @param value7
         * @param value8
         * @param value9
         * @param isStart
         * @param success
         * @param error
         */

    }, {
        key: 'updateSleepCurve',
        value: function updateSleepCurve(type, mode, value0, value1, value2, value3, value4, value5, value6, value7, value8, value9, isStart, success, error) {
            this.webserviceApdater(_updateSleepCurve, {
                applianceId: this.deviceId + "",
                type: type,
                mode: mode,
                value0: value0,
                value1: value1,
                value2: value2,
                value3: value3,
                value4: value4,
                value5: value5,
                value6: value6,
                value7: value7,
                value8: value8,
                value9: value9,
                isStart: isStart
            }, function (data) {
                // nativeService.alert(data);
                success && success(data);
            }, function (errorCode, errorMsg) {
                // nativeService.alert(errorMsg);
                error && error(errorCode, errorMsg);
            });
        }

        /**
         * 查询用电
         * @param type 1表示获取某周每天电量，2表示获取某月每天电量，3表示获取某年每月电量，默认为2
         * @param date 当前日期 格式如”2014-10-09
         * @param success
         * @param error
         */

    }, {
        key: 'queryElec',
        value: function queryElec(type, date, success, error) {
            this.webserviceApdater(_queryElec, {
                applianceId: this.deviceId + "",
                type: type,
                date: date
            }, function (data) {
                // nativeService.alert(JSON.stringify(data));
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        /**
         * 获取产品说明
         * @param langCode 通用的国家语言码
         * @param success
         * @param error
         * */

    }, {
        key: 'getProductDesc',
        value: function getProductDesc(langCode, success, error) {
            var lang = langMap[langCode] !== undefined ? langMap[langCode] : 'english';

            this.webserviceApdater(productDesc, {
                type: "AC",
                appId: this.deviceId + "",
                lang: lang
            }, function (data) {
                success && success(JSON.parse(data.data));
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        /**
         * 查询OTA版本
         * @param success
         * @param error
         * */

    }, {
        key: 'queryOtaStaus',
        value: function queryOtaStaus(success, error, cacheCallback) {
            this.webserviceApdater(_queryOtaStaus, {
                applianceId: this.deviceId + "",
                userId: this.familyId + ""
            }, function (data) {
                // nativeService.alert(data)
                success && success(JSON.parse(data.data));
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            }, true, function (data) {
                cacheCallback && cacheCallback(JSON.parse(data.data));
            });

            if (this.mockMode) {
                var data = _web2.default['queryOtaStaus'];
                if (this.runtimeTestData.status == undefined) {
                    this.runtimeTestData.status = data.result.status;
                }
                data.result.status = this.runtimeTestData.status;
                this.runtimeTestData.status++;
                this.runtimeTestData.status > 3 && (this.runtimeTestData.status = -1);
                success && success(data);
            }
        }
        /**
         * 查询是否需要升级 Function页 Firmware Update 后面基于 needUpdate = 1 时显示需要升级的红点 
         * @param success
         * @param error
         * */

    }, {
        key: 'queryNeedUpdateStaus',
        value: function queryNeedUpdateStaus(success, error) {
            this.webserviceApdater(_queryOtaStaus, {
                applianceId: this.deviceId + "",
                userId: this.familyId + ""
            }, function (data) {
                // nativeService.alert(123)
                success && success(JSON.parse(data.data));
            }, function (errorCode, errorMsg) {
                // nativeService.alert(errorMsg)
                error && error(errorCode, errorMsg);
            });

            // let functionParamers = {
            //     queryStrings: {
            //         "serviceUrl": queryOtaStaus
            //     },
            //     transmitData: {
            //         applianceId : this.deviceId+"",
            //         userId: this.familyId+"",
            //     }
            // };
            // // nativeService.alert(functionParamers)
            // nativeService.requestDataTransmit(functionParamers).then((messageBack)=>{
            //     success && success(messageBack);
            // },(errorMsg)=>{
            //     error && error(errorMsg);
            // });
        }
        /**
        * 升级OTA
        * @param success
        * @param error
        * */

    }, {
        key: 'upgradeWifi',
        value: function upgradeWifi(success, error) {
            this.webserviceApdater(_upgradeWifi, {
                applianceId: this.deviceId + "",
                userId: this.familyId + ""
            }, function (data) {
                success && success(JSON.parse(data.data));
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        /**
         * 取消升级OTA
         * @param success
         * @param error
         * */

    }, {
        key: 'abandonUpgradeWifi',
        value: function abandonUpgradeWifi(success, error) {
            this.webserviceApdater(_abandonUpgradeWifi, {
                applianceId: this.deviceId + "",
                userId: this.familyId + ""
            }, function (data) {
                success && success(JSON.parse(data.data));
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        /**
         * 设置自动升级OTA
         * @param auto 自动升级：1； 手工升级：0.
         * @param success
         * @param error
         * */

    }, {
        key: 'setAutoUpgradeWifi',
        value: function setAutoUpgradeWifi(auto, success, error) {
            this.webserviceApdater(_setAutoUpgradeWifi, {
                applianceId: this.deviceId + "",
                userId: this.familyId + "",
                auto: auto ? 1 : 0
            }, function (data) {
                success && success(JSON.parse(data.data));
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'getVoiceCtrlDevicesList',
        value: function getVoiceCtrlDevicesList(sceneType, success, error) {
            // var applianceId = nativeService.getCurrentApplianceID();
            var functionParamers = {
                url: getVoiceCtrlDevicesListUrl,
                params: {
                    homegroupId: this.familyId + '',
                    sceneType: sceneType + '',
                    masterId: this.deviceId + '',
                    sceneId: 0 + '',
                    stamp: new Date().getTime(),
                    reqId: this.generateUUID()
                }
            };
            console.log('start');
            _nativeService2.default.sendCentralCloundRequest(getVoiceCtrlDevicesListUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json;charset=utf-8'
                },
                data: functionParamers.params
            }).then(function (data) {
                // nativeService.alert(JSON.stringify(data));
                console.log(JSON.stringify(data));
                success && success(data);
            }).catch(function (errorMsg) {
                error && error(-1, errorMsg);
            });
            console.log('end');
        }

        /**
         * 删除设备接口
         * @param {*} sceneType 
         * @param {*} success 
         * @param {*} error 
         */

    }, {
        key: 'deleteDevice',
        value: function deleteDevice(deviceId, success, error) {
            // var applianceId = nativeService.getCurrentApplianceID();
            var functionParamers = {
                url: unbindDevice,
                params: {
                    applianceId: this.deviceId + '',
                    src: "0",
                    stamp: new Date().getTime(),
                    reqId: this.generateUUID()
                }
                // nativeService.alert("!!!");
            };_nativeService2.default.sendCentralCloundRequest(functionParamers.url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json;charset=utf-8'
                },
                data: functionParamers.params
            }).then(function (data) {
                // nativeService.alert(JSON.stringify(data));
                console.log(JSON.stringify(data));
                success && success(data);
            }).catch(function (errorMsg) {
                error && error(-1, errorMsg);
            });
            console.log('end');
        }
        /**
             * 绑定设备接口
             * @param {*} sceneType 
             * @param {*} success 
             * @param {*} error 
             */

    }, {
        key: 'bindDevice',
        value: function bindDevice(param, success, error) {
            // var applianceId = nativeService.getCurrentApplianceID();
            var functionParamers = {
                url: _bindDevice,
                params: {
                    referSn: param.referSn || '',
                    applianceName: param.applianceName || '',
                    applianceType: param.applianceType || '',
                    modelNumber: param.modelNumber || '',
                    applianceDes: param.applianceDes || '',
                    mac: param.mac || '',
                    language: param.language || 'zh_CN',
                    timeZoneID: param.timeZoneID,
                    src: "0",
                    stamp: new Date().getTime(),
                    reqId: this.generateUUID()
                }
                // nativeService.alert(JSON.stringify(functionParamers));
            };_nativeService2.default.sendCentralCloundRequest(functionParamers.url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json;charset=utf-8'
                },
                data: functionParamers.params
            }).then(function (data) {
                // nativeService.alert(JSON.stringify(data));
                // nativeService.alert('suc==='+JSON.stringify(data))
                success && success(data);
            }).catch(function (errorMsg) {
                // nativeService.alert('err==='+JSON.stringify(errorMsg))
                error && error(errorMsg);
            });
        }

        /**
         * 获取用户家电列表 
         * @param {*} sceneType 
         * @param {*} success 
         * @param {*} error 
         */

    }, {
        key: 'userListGet',
        value: function userListGet(userid, success, error) {
            // nativeService.alert(444);
            var functionParamers = {
                url: _userListGet,
                params: {
                    applianceId: this.deviceId + '',
                    src: "0",
                    stamp: new Date().getTime(),
                    reqId: this.generateUUID()
                }
                // nativeService.alert("!!!");
            };_nativeService2.default.sendCentralCloundRequest(functionParamers.url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json;charset=utf-8'
                },
                data: functionParamers.params
            }, { isShowLoading: false }).then(function (data) {
                // nativeService.alert(JSON.stringify(data));
                console.log(JSON.stringify(data));
                success && success(data);
            }).catch(function (errorMsg) {
                error && error(-1, errorMsg);
            });
            console.log('end');
        }
        //

    }, {
        key: 'infoModify',
        value: function infoModify(applianceName, success, error) {

            // nativeService.alert("112233");
            // var applianceId = nativeService.getCurrentApplianceID();
            var functionParamers = {
                url: _infoModify,
                params: {
                    appId: '1010',
                    applianceId: this.deviceId + '',
                    applianceName: applianceName,
                    src: "0",
                    stamp: new Date().getTime(),
                    reqId: this.generateUUID()
                }
                //   nativeService.alert("!!!");
            };_nativeService2.default.sendCentralCloundRequest(functionParamers.url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json;charset=utf-8'
                },
                data: functionParamers.params
            }).then(function (data) {
                //   nativeService.alert(JSON.stringify(data));
                //   console.log(JSON.stringify(data))
                success && success(data);
            }).catch(function (errorMsg) {
                error && error(-1, errorMsg);
            });
            console.log('end');
        }

        /**
        * 一键报修
        * @param {*} sceneType 
        * @param {*} success 
        * @param {*} error 
        */

    }, {
        key: 'iserviceGet',
        value: function iserviceGet(userid, success, error) {
            // // nativeService.alert(weex.config.env.version);
            var functionParamers = {
                url: _iserviceGet,
                params: {}
                // nativeService.alert("!!!");
            };_nativeService2.default.sendCentralCloundRequest(functionParamers.url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json;charset=utf-8',
                    'version': weex.config.env.appVersion
                },
                data: functionParamers.params
            }).then(function (data) {
                // nativeService.alert(JSON.stringify(data));
                console.log(JSON.stringify(data));
                success && success(data);
            }).catch(function (errorMsg) {
                error && error(-1, errorMsg);
            });
            console.log('end');
        }

        // 节能区间

    }, {
        key: 'queryEnnoRange',
        value: function queryEnnoRange(countryCode, success, error) {
            // nativeService.alert(`${this.deviceId}--${userId}`)
            this.webserviceApdater(ennoRange, {
                // applianceId : this.deviceId+"",
                countryCode: countryCode + ""
                // applianceId : "24189255812049",
                // userId: "457300",
                // appId: '1010',
                // page: 1,
                // pageSize: 1000
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                // nativeService.alert(JSON.stringify(errorMsg));
                error && error(errorCode, errorMsg);
            });
        }

        // 更新睡眠曲线

    }, {
        key: 'curveModify',
        value: function curveModify(curveId, applianceId, sn, userId, duration, tempCurve, fanSpeed, endClose, success, error) {
            // nativeService.alert(`${this.deviceId}--${userId}`)
            this.webserviceApdater(_curveModify, {
                curveId: curveId,
                applianceId: applianceId,
                sn: sn,
                userId: userId,
                duration: duration,
                tempCurve: tempCurve,
                fanSpeed: fanSpeed,
                endClose: endClose,
                appId: '1010'
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
        // 启动睡眠曲线

    }, {
        key: 'curveRun',
        value: function curveRun(curveId, userId, applianceId, sn, time, timezone, success, error) {
            this.webserviceApdater(_curveRun, {
                curveId: curveId,
                userId: userId,
                applianceId: applianceId,
                sn: sn,
                time: time,
                timezone: timezone,
                appId: '1010'
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
        // // 停止睡眠曲线
        // curveStop(curveId,userId,applianceId,sn,time,timezone, success,error) {
        //     this.webserviceApdater(curveStop,{
        //         curveId : curveId,
        //         userId: userId,
        //         applianceId: applianceId,
        //         sn : sn,
        //         time:time,
        //         timezone:timezone,
        //         appId:'1010'
        //     },(data)=>{
        //         success && success(data);
        //     },(errorCode,errorMsg)=>{
        //         error && error(errorCode,errorMsg);
        //     })
        // }
        // 停止睡眠曲线

    }, {
        key: 'curveStop',
        value: function curveStop(curveId, userId, applianceId, sn, success, error) {
            this.webserviceApdater(_curveStop, {
                curveId: curveId,
                userId: userId,
                applianceId: applianceId,
                sn: sn,
                appId: '1010'
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
        // 查询睡眠曲线

    }, {
        key: 'curveDetail',
        value: function curveDetail(curveId, applianceId, sn, duration, userId, mode, area, scale, success, error) {
            // nativeService.alert(33)
            this.webserviceApdater(_curveDetail, {
                curveId: curveId,
                applianceId: applianceId,
                sn: sn,
                duration: duration,
                userId: userId,
                mode: mode,
                area: area,
                scale: scale,
                appId: '1010'
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
        // 查询推荐AI曲线

    }, {
        key: 'curveRecommend',
        value: function curveRecommend(curveId, applianceId, sn, duration, userId, mode, area, scale, success, error) {
            this.webserviceApdater(_curveRecommend, {
                curveId: curveId,
                applianceId: applianceId,
                sn: sn,
                duration: duration,
                userId: userId,
                mode: mode,
                area: area,
                scale: scale,
                appId: '1010'
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        // 节能区间

    }, {
        key: 'checkIeco',
        value: function checkIeco(success, error) {
            this.webserviceApdater(iecoUrl, {
                applianceId: this.deviceId + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                // nativeService.alert(JSON.stringify(errorMsg));
                error && error(errorCode, errorMsg);
            });
        }
        // 刷新wifi版本信息

    }, {
        key: 'otaRefreshId',
        value: function otaRefreshId(success, error) {
            this.webserviceApdater(_otaRefreshId, {
                applianceId: this.deviceId + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                // nativeService.alert(JSON.stringify(errorMsg));
                error && error(errorCode, errorMsg);
            });
        }

        // IECO Report

    }, {
        key: 'powerReport',
        value: function powerReport(sn, timezone, time, localDateTime, userId, zoneId, success, error) {
            this.webserviceApdater(_powerReport, {
                applianceId: this.deviceId + "",
                sn: sn,
                timezone: timezone,
                time: time,
                localDateTime: localDateTime,
                userId: userId,
                zoneId: zoneId
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                // nativeService.alert(JSON.stringify(errorMsg));
                error && error(errorCode, errorMsg);
            });
        }

        // 查询IECO target设置

    }, {
        key: 'targetGet',
        value: function targetGet(success, error) {
            this.webserviceApdater(_targetGet, {
                applianceId: this.deviceId + ""
            }, function (data) {
                // nativeService.alert(JSON.stringify(data));
                success && success(data);
            }, function (errorCode, errorMsg) {
                // nativeService.alert(JSON.stringify(errorMsg));
                error && error(errorCode, errorMsg);
            });
        }

        // 查询IECO target设置

    }, {
        key: 'targetSet',
        value: function targetSet(status, target, period, notiPercentList, zoneId, success, error) {
            // let obj = {
            //     applianceId : this.deviceId+"",
            //     status:status,
            //     target:target,
            //     period:period,
            //     notiPercentList:notiPercentList,
            //     zoneId:zoneId
            // }
            // nativeService.alert(JSON.stringify(obj));
            this.webserviceApdater(_targetSet, {
                applianceId: this.deviceId + "",
                status: status,
                target: target,
                period: period,
                notiPercentList: notiPercentList,
                zoneId: zoneId
            }, function (data) {
                // nativeService.alert(JSON.stringify(data));
                success && success(data);
            }, function (errorCode, errorMsg) {
                // nativeService.alert(JSON.stringify(errorMsg));
                error && error(errorCode, errorMsg);
            });
        }

        // 电量看板接口

    }, {
        key: 'powerBoast',
        value: function powerBoast(sn, timezone, time, localDateTime, userId, zoneId, powerGroupByType, startDay, endDay, success, error) {
            // let obj = {
            //     applianceId : this.deviceId+"",
            //     sn:sn,
            //     timezone:timezone,
            //     time:time,
            //     localDateTime:localDateTime,
            //     userId:userId,
            //     zoneId:zoneId,
            //     powerGroupByType:powerGroupByType,
            //     startDay:startDay,
            //     endDay:endDay,
            // }
            // nativeService.alert(JSON.stringify(obj));
            this.webserviceApdater(_powerBoast, {
                applianceId: this.deviceId + "",
                sn: sn,
                timezone: timezone,
                time: time,
                localDateTime: localDateTime,
                userId: userId,
                zoneId: zoneId,
                powerGroupByType: powerGroupByType,
                startDay: startDay,
                endDay: endDay
            }, function (data) {
                // nativeService.alert(JSON.stringify(data));
                success && success(data);
            }, function (errorCode, errorMsg) {
                // nativeService.alert(JSON.stringify(errorMsg));
                error && error(errorCode, errorMsg);
            });
        }

        // 用户设置

    }, {
        key: 'userPreferencesSet',
        value: function userPreferencesSet(temperatureUnit, timeFormat, appId, userId, success, error) {
            // nativeService.alert(JSON.stringify(11));
            this.webserviceApdater(_userPreferencesSet, {
                // applianceId : this.deviceId+"",
                temperatureUnit: temperatureUnit,
                timeFormat: timeFormat,
                userId: userId,
                appId: '1010'
            }, function (data) {
                // nativeService.alert(JSON.stringify(data));
                success && success(data);
            }, function (errorCode, errorMsg) {
                // nativeService.alert(JSON.stringify(errorMsg));
                error && error(errorCode, errorMsg);
            });
        }
        // 用户设置查询

    }, {
        key: 'userPreferencesGet',
        value: function userPreferencesGet(userId, success, error) {
            this.webserviceApdater(_userPreferencesGet, {

                userId: userId
                // appId:'1010',
            }, function (data) {
                // nativeService.alert(JSON.stringify(data));
                success && success(data);
            }, function (errorCode, errorMsg) {
                // nativeService.alert(JSON.stringify(errorMsg));
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'setDeviceB5Info',
        value: function setDeviceB5Info(param, success, error) {
            //传接口的B5数据给数据器
            // nativeService.alert(JSON.stringify(param));
            this.webserviceApdater(deviceB5InfoSet, {
                appId: '1010',
                applianceId: this.deviceId + "",
                // applianceType: 'AC',
                sn: this.deviceSn + "",
                rawB5: param
            }, function (data) {
                // nativeService.alert('suc==='+JSON.stringify(data));
                success && success(data);
            }, function (errorCode, errorMsg) {
                // nativeService.alert('err==='+JSON.stringify(errorMsg));
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'generateUUID',
        value: function generateUUID() {
            var d = new Date().getTime();
            var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                var r = (d + Math.random() * 16) % 16 | 0;
                d = Math.floor(d / 16);
                return (c === 'x' ? r : r & 0x3 | 0x8).toString(16);
            });
            return uuid;
        }

        /***************************************base support func***************************************/

    }, {
        key: 'webserviceApdater',
        value: function webserviceApdater(url, parameters, success, error, _hasCache, cacheCallback) {
            console.log(url + "------url");
            _SLKDecorator2.default.MSmartUserDeviceManager.webserviceApdater(this.isViaServer, url, parameters, success, error, _hasCache, cacheCallback);
        }
    }]);

    return WebComDecorator;
}();

exports.default = WebComDecorator;

/***/ }),

/***/ 33:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
var MockData = {
    queryOtaStaus: {
        "errCode": "0",
        "errMsg": "成功",
        "result": {
            "chipType": "6",
            "chipName": "QualComm - QCA4004B",
            "protocolType": "06",
            "protocolName": "mSmart+Homekit",
            "version": "4.0.2",
            "status": 0,
            "statusName": "升级中",
            "needUpdate": 1,
            "updateVersion": "4.0.2",
            "updateVersionDesc": "fix bugs",
            "auto": 0
        }
    },

    upgradeWifi: {
        "errCode": "0",
        "errMsg": "成功",
        "result": {
            "status": 0,
            "statusName": ""
        }
    },

    abandonUpgradeWifi: {
        "errCode": "0",
        "errMsg": "成功",
        "result": {
            "status": 0,
            "statusName": ""
        }
    },

    setAutoUpgradeWifi: {
        "errCode": "0",
        "errMsg": "成功"
    }

};

exports.default = MockData;

/***/ }),

/***/ 4:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }(); /**
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      * Created by liujim on 2017/8/19.
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      */

var _all = __webpack_require__(16);

var _all2 = _interopRequireDefault(_all);

var _nativeService = __webpack_require__(1);

var _nativeService2 = _interopRequireDefault(_nativeService);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Process = function () {
    function Process() {
        _classCallCheck(this, Process);
    }

    _createClass(Process, null, [{
        key: "initLangEnv",
        value: function initLangEnv(callback) {
            var _this = this;

            if (this.currentLanguageCode === null) {
                _nativeService2.default.getLanguage().then(function (data) {
                    // nativeService.alert(data);
                    //language:zh  country:CN
                    //en, US
                    //ru, RU
                    //it, IT
                    //fr, FR
                    //pt, PT
                    //es,  ES

                    if (data && data.language) {
                        _this.currentLanguageCode = data.language;
                        callback(_this.currentLanguageCode);
                    }
                });
            } else {
                callback(this.currentLanguageCode);
            }
        }
    }, {
        key: "getText",
        value: function getText(mark) {
            var currentLocate = this.currentLanguageCode;
            currentLocate = currentLocate === "es" ? "sp" : currentLocate; //fix

            if (_all2.default[mark] !== undefined) {
                //console.log("translate success", mark, languageData[mark]);

                if (_all2.default[mark][currentLocate] !== undefined) {
                    return _all2.default[mark][currentLocate];
                } else {
                    return _all2.default[mark]["en"];
                }
            } else {
                //console.log("translate error", mark=="", mark, arguments);
                //console.trace();

                return mark;
            }
        }
    }]);

    return Process;
}();

Process.currentLanguageCode = null;
exports.default = Process;

/***/ }),

/***/ 42:
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(43)
)

/* script */
__vue_exports__ = __webpack_require__(44)

/* template */
var __vue_template__ = __webpack_require__(45)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/chenhx113/Documents/project/meijuobmweexapp/code/AC/src/T0xAC/components/common/cell.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-7e416c00"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),

/***/ 43:
/***/ (function(module, exports) {

module.exports = {
  "theme-background": {
    "backgroundColor": "#F9F9F9"
  },
  "white-background": {
    "backgroundColor": "#ffffff"
  },
  "theme-background-full": {
    "backgroundColor": "#468EFF"
  },
  "theme-font-color": {
    "color": "#000000"
  },
  "theme-font-orange-color": {
    "color": "#C26033"
  },
  "theme-font-explain-color": {
    "color": "#D8D8DE",
    "opacity": 0.4
  },
  "theme-font-msg-gray-color": {
    "color": "#8A8A8F"
  },
  "theme-font-msg-gray-bg-color": {
    "backgroundColor": "#333333"
  },
  "theme-center-layout": {
    "display": "flex",
    "flexDirection": "row",
    "alignItems": "center"
  },
  "theme-center-layout-wrapper": {
    "display": "flex",
    "flexDirection": "row",
    "alignItems": "center",
    "flexWrap": "wrap"
  },
  "theme-cell-standard-style": {
    "backgroundColor": "#1a1a1a"
  },
  "spacing-line": {
    "width": 750,
    "height": 1,
    "backgroundColor": "#e2e2e2",
    "display": "flex",
    "alignSelf": "center"
  },
  "midea-cell-theme": {
    "height": 124,
    "position": "relative",
    "flexDirection": "row",
    "alignItems": "center",
    "paddingLeft": 32,
    "paddingRight": 32,
    "backgroundColor": "#1a1a1a"
  },
  "active-cell-theme": {
    "backgroundColor:active": "#cccccc"
  },
  "cell-label-text-theme": {
    "fontSize": 30,
    "color": "#666666",
    "width": 188,
    "marginRight": 10
  },
  "right-text-theme": {
    "fontSize": 25,
    "color": "#ffffff"
  },
  "cell-content-theme": {
    "color": "#ffffff",
    "fontSize": 30,
    "lineHeight": 40
  },
  "cell-desc-text-theme": {
    "color": "#999999",
    "fontSize": 24,
    "lineHeight": 30,
    "marginTop": 4
  },
  "cell-top-border-theme": {
    "borderTopColor": "#333333",
    "borderTopWidth": 1,
    "opacity": 0.8
  },
  "cell-bottom-border-theme": {
    "borderBottomWidth": 1,
    "borderBottomStyle": "solid",
    "borderBottomColor": "#333333",
    "opacity": 0.8
  },
  "wrap-theme": {
    "position": "relative",
    "flexDirection": "row",
    "backgroundColor": "#000000"
  },
  "selected-item-theme": {
    "opacity": 1,
    "color": "#ffffff",
    "fontSize": 48
  },
  "unselected-item-theme": {
    "opacity": 0.3,
    "color": "#ffffff"
  },
  "debug-util": {
    "borderWidth": 2,
    "borderColor": "#FF0000"
  },
  "ctrl-page-wrapper": {
    "backgroundColor": "#000000",
    "width": 750
  },
  "ctrl-page-scroller": {
    "flex": 1,
    "zIndex": 99999,
    "display": "flex",
    "backgroundColor": "#000000",
    "alignItems": "center",
    "marginBottom": 30
  },
  "ctrl-page-info-bg": {
    "width": 750,
    "position": "absolute"
  },
  "ctrl-page-info-panel": {
    "height": 600,
    "backgroundSize": "cover"
  },
  "ctrl-page-temp-control": {
    "display": "flex",
    "flexDirection": "row",
    "width": 750,
    "justifyContent": "center",
    "alignItems": "center",
    "position": "absolute",
    "top": 200
  },
  "ctrl-page-temperature-value": {
    "width": 380,
    "height": 400,
    "display": "flex",
    "justifyContent": "center",
    "alignItems": "center"
  },
  "ctrl-page-circleprogress": {
    "position": "absolute",
    "width": 750,
    "top": 90,
    "height": 630
  },
  "ctrl-page-circle-arc": {
    "width": 630,
    "height": 630,
    "alignSelf": "center"
  },
  "ctrl-page-temp-btn": {
    "display": "flex",
    "justifyContent": "center",
    "alignItems": "center",
    "flexDirection": "row",
    "position": "absolute",
    "width": 500,
    "left": 125,
    "top": 350
  },
  "ctrl-page-temperature-btn-img": {
    "height": 55,
    "width": 55
  },
  "ctrl-page-temperature-unit": {
    "color": "#ffffff",
    "position": "absolute",
    "top": 120,
    "right": 53,
    "fontSize": 30
  },
  "ctrl-page-more-info-wrap": {
    "width": 350,
    "paddingTop": 16,
    "paddingRight": 16,
    "paddingBottom": 16,
    "paddingLeft": 16,
    "borderRadius": 50,
    "marginTop": 30
  },
  "ctrl-page-control-btn-group": {
    "width": 700,
    "marginTop": 12,
    "marginRight": 25,
    "marginBottom": 20,
    "marginLeft": 25,
    "position": "relative",
    "top": 20
  },
  "ctrl-page-btn-img-style": {
    "height": 95,
    "width": 95
  },
  "ctrl-page-control-btn-cell": {
    "height": 152,
    "backgroundColor": "rgba(255,255,255,0.1)",
    "width": 686,
    "paddingTop": 15,
    "paddingRight": 32,
    "paddingBottom": 15,
    "paddingLeft": 32,
    "borderRadius": 20,
    "display": "flex",
    "flexDirection": "row",
    "alignItems": "center",
    "position": "relative"
  },
  "ctrl-page-control-btn-group-wrap": {
    "backgroundColor": "rgba(255,255,255,0.1)",
    "borderRadius": 20,
    "paddingTop": 30,
    "paddingRight": 0,
    "paddingBottom": 30,
    "paddingLeft": 0,
    "display": "flex",
    "flexDirection": "row",
    "flexWrap": "wrap"
  },
  "ctrl-page-single-btn": {
    "height": 145,
    "width": 135,
    "display": "flex",
    "marginTop": 10,
    "marginRight": 20,
    "marginBottom": 10,
    "marginLeft": 20,
    "flexDirection": "column",
    "justifyContent": "center",
    "alignItems": "center",
    "opacity": 1
  },
  "ctrl-page-cell-img": {
    "marginTop": 0,
    "marginRight": 30,
    "marginBottom": 0,
    "marginLeft": 0
  },
  "ctrl-page-cell-title": {
    "display": "flex",
    "alignItems": "center",
    "flexDirection": "row"
  },
  "ctrl-page-switch-btn": {
    "position": "absolute",
    "left": 550,
    "top": 50,
    "width": 100,
    "height": 60
  },
  "ctrl-page-btn-text": {
    "textAlign": "center",
    "fontSize": 24,
    "color": "#000000",
    "marginTop": 20
  },
  "silder-container": {
    "flex": 1,
    "marginLeft": 8,
    "marginRight": 8,
    "height": 64,
    "width": 550
  },
  "line-container": {
    "position": "absolute",
    "left": 20,
    "height": 64,
    "width": 550,
    "flexDirection": "row",
    "justifyContent": "space-around",
    "alignItems": "center"
  },
  "line": {
    "height": 6,
    "marginTop": 30,
    "marginRight": 3,
    "marginBottom": 30,
    "marginLeft": 3,
    "flex": 1,
    "backgroundColor": "#424546",
    "borderRadius": 2
  },
  "title": {
    "fontSize": 35,
    "textAlign": "center"
  },
  "custom-content": {
    "marginTop": 10,
    "textAlign": "center"
  },
  "content": {
    "width": 750,
    "alignItems": "center",
    "justifyContent": "center"
  },
  "info-wrapper": {
    "width": 750,
    "display": "flex",
    "justifyContent": "center",
    "alignItems": "center",
    "position": "absolute",
    "top": 300,
    "height": 600
  },
  "dialog-btn": {
    "width": 300,
    "height": 80,
    "marginTop": 0,
    "marginRight": 20,
    "marginBottom": 0,
    "marginLeft": 20,
    "display": "flex",
    "justifyContent": "center",
    "alignItems": "center",
    "backgroundColor": "#333333"
  },
  "theme-blk": {
    "position": "absolute",
    "top": 4.7,
    "left": 4,
    "zIndex": 100,
    "height": 35,
    "width": 35,
    "backgroundColor": "#808080",
    "borderRadius": 35
  },
  "theme-blk-android": {
    "position": "absolute",
    "top": 5,
    "left": 4,
    "zIndex": 100,
    "height": 35,
    "width": 35,
    "backgroundColor": "#808080",
    "borderRadius": 35
  },
  "theme-wx-switch-color": {
    "position": "absolute",
    "width": 96,
    "height": 48,
    "borderRadius": 62,
    "borderWidth": 2,
    "borderStyle": "solid"
  },
  "theme-border-show": {
    "opacity": 1,
    "borderColor": "#c06039"
  },
  "theme-border-none": {
    "opacity": 1,
    "borderColor": "#808080"
  },
  "right-text-custom": {
    "fontSize": 24,
    "color": "#999999"
  },
  "midea-cell-firmware": {
    "height": 168,
    "position": "relative",
    "flexDirection": "row",
    "alignItems": "center",
    "paddingLeft": 32,
    "paddingRight": 32,
    "backgroundColor": "#ffffff"
  },
  "midea-cell": {
    "height": 108,
    "position": "relative",
    "flexDirection": "row",
    "alignItems": "center",
    "paddingLeft": 32,
    "paddingRight": 32,
    "backgroundColor": "#ffffff"
  },
  "active-cell": {
    "backgroundColor:active": "#f5f5f5"
  },
  "cell-margin": {
    "marginBottom": 24
  },
  "cell-title": {
    "flex": 1
  },
  "cell-indent": {
    "paddingBottom": 30,
    "paddingTop": 30
  },
  "has-desc": {
    "paddingBottom": 18,
    "paddingTop": 18
  },
  "cell-top-border": {
    "borderTopColor": "#e2e2e2",
    "borderTopWidth": 1
  },
  "cell-bottom-border": {
    "borderBottomWidth": 1,
    "borderBottomStyle": "solid",
    "borderBottomColor": "#e2e2e2"
  },
  "cell-label-text": {
    "fontSize": 30,
    "color": "#666666",
    "width": 188,
    "marginRight": 10
  },
  "right-text": {
    "fontSize": 24,
    "color": "#999999"
  },
  "cell-arrow-icon": {
    "width": 12,
    "height": 24,
    "position": "absolute",
    "right": 24
  },
  "cell-content": {
    "color": "#333333",
    "fontSize": 30,
    "lineHeight": 40
  },
  "cell-desc-text": {
    "color": "#999999",
    "fontSize": 24,
    "lineHeight": 30,
    "marginTop": 4
  },
  "item-img": {
    "width": 30,
    "height": 30,
    "marginRight": 24
  }
}

/***/ }),

/***/ 44:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var _util = __webpack_require__(28);

var _util2 = _interopRequireDefault(_util);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var icon = __webpack_require__(29);

module.exports = {
    props: {
        height: {
            type: String,
            default: '100'
        },
        label: {
            type: String,
            default: ''
        },
        title: {
            type: String,
            default: ''
        },
        desc: {
            type: String,
            default: ''
        },
        rightText: {
            type: String,
            default: ''
        },
        clickActivied: {
            type: Boolean,
            default: false
        },
        hasTopBorder: {
            type: Boolean,
            default: false
        },
        hasMargin: {
            type: Boolean,
            default: false
        },
        hasBottomBorder: {
            type: Boolean,
            default: true
        },
        hasArrow: {
            type: Boolean,
            default: false
        },
        hasVerticalIndent: {
            type: Boolean,
            default: true
        },
        cellStyle: {
            type: Object,
            default: function _default() {
                return {};
            }
        },
        itemImg: {
            type: String,
            default: ''
        },
        itemImgWidth: {
            type: Number,
            default: 30
        },
        itemImgHeight: {
            type: Number,
            default: 30
        },
        mideaCellClass: {
            type: String,
            default: 'midea-cell'
        },
        activeCellClass: {
            type: String,
            default: 'active-cell'
        },
        cellLabelTextClass: {
            type: String,
            default: 'cell-label-text'
        },
        rightTextClass: {
            type: String,
            default: 'right-text'
        },
        cellContentClass: {
            type: String,
            default: 'cell-content'
        },
        cellDescText: {
            type: String,
            default: 'cell-desc-text'
        },
        cellTopBorderClass: {
            type: String,
            default: 'cell-top-border'
        },
        cellBottomBorderClass: {
            type: String,
            default: 'cell-bottom-border'
        }
    },
    computed: {
        outputCellStyle: function outputCellStyle() {
            var height = this.height,
                cellStyle = this.cellStyle;
            //return util.extend({"height":height+"px"},cellStyle);

            return _extends({ "height": height + "px" }, cellStyle);
        }
    },
    data: function data() {
        return {
            //arrowIcon: icon.arrowIcon
            arrowIcon: "./img/arrow_right.png"
        };
    },
    methods: {
        cellClicked: function cellClicked(e) {

            this.$emit('mideaCellClick', { e: e });
        }
    }
};

/***/ }),

/***/ 45:
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    class: [_vm.mideaCellClass, _vm.clickActivied && _vm.activeCellClass, _vm.hasTopBorder && _vm.cellTopBorderClass, _vm.hasBottomBorder && _vm.cellBottomBorderClass, _vm.hasMargin && 'cell-margin', _vm.hasVerticalIndent && 'cell-indent', _vm.desc && 'has-desc'],
    on: {
      "click": _vm.cellClicked
    }
  }, [_vm._t("itemImg", [(_vm.itemImg && _vm.itemImg != '') ? _c('image', {
    staticClass: ["item-img"],
    style: {
      width: _vm.itemImgWidth + 'px',
      height: _vm.itemImgHeight + 'px'
    },
    attrs: {
      "src": _vm.itemImg
    }
  }) : _vm._e()]), _vm._t("label", [(_vm.label) ? _c('div', [_c('text', {
    class: [_vm.cellLabelTextClass]
  }, [_vm._v(_vm._s(_vm.label))])]) : _vm._e()]), _c('div', {
    staticClass: ["cell-title"]
  }, [_vm._t("title", [_c('text', {
    class: [_vm.cellContentClass]
  }, [_vm._v(_vm._s(_vm.title))]), (_vm.desc) ? _c('text', {
    class: [_vm.cellDescText]
  }, [_vm._v(_vm._s(_vm.desc))]) : _vm._e()])], 2), _vm._t("value"), _vm._t("text"), _vm._t("rightText", [(_vm.rightText) ? _c('div', {
    style: {
      paddingRight: _vm.hasArrow ? '24px' : '0px'
    }
  }, [_c('text', {
    class: [_vm.rightTextClass]
  }, [_vm._v(_vm._s(_vm.rightText))])]) : _vm._e()]), (_vm.hasArrow) ? _c('image', {
    staticClass: ["cell-arrow-icon"],
    style: {
      top: ((_vm.height - 24) / 2) + 'px'
    },
    attrs: {
      "src": _vm.arrowIcon
    }
  }) : _vm._e()], 2)
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),

/***/ 5:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

// ************ debug 相关 *************
var storage = weex.requireModule('storage');
var mm = weex.requireModule('modal');
var debugInfoDataChannel = new BroadcastChannel('debugInfoDataChannel');
var debugUtil = {
    isEnableDebugInfo: false,
    debugInfoKey: 'debugInfo',
    debugInfoDataChannel: debugInfoDataChannel,
    debugInfoExist: '',
    debugInfo: '',
    debugLogSizeLmite: 80000,
    debugLog: function debugLog() {
        var _this = this;

        for (var _len = arguments.length, messages = Array(_len), _key = 0; _key < _len; _key++) {
            messages[_key] = arguments[_key];
        }

        if (!this.isEnableDebugInfo) return;

        if (!this.debugInfoExist) {
            this.getDebugLog().then(function (data) {
                _this.debugInfoExist = data || ' ***>>> ';
                _this.debugLog.apply(_this, messages);
            });
        } else {
            var debugInfoArray = [];
            for (var index = 0; index < messages.length; index++) {
                var message = messages[index];
                if ((typeof message === 'undefined' ? 'undefined' : _typeof(message)) == 'object') {
                    try {
                        message = JSON.stringify(message, null, 2);
                    } catch (error) {
                        debugInfoArray.push(error);
                    }
                } else if (typeof message == 'string') {
                    try {
                        message = JSON.stringify(JSON.parse(message), null, 2);
                    } catch (error) {}
                }
                debugInfoArray = debugInfoArray.concat(this.strCut2Arr(message, 2000));
            }
            var newDebugInfo = new Date() + '\n' + debugInfoArray.join(", ") + '\n\n';
            this.debugInfo += newDebugInfo;
            this.setItem(this.debugInfoKey, this.debugInfoExist + this.debugInfo);
        }
    },
    getDebugLog: function getDebugLog() {
        var _this2 = this;

        return new Promise(function (resolve, reject) {
            _this2.getItem(_this2.debugInfoKey, function (resp) {
                var result = resp.data || '';
                resolve(result.substr(-_this2.debugLogSizeLmite));
            });
        });
    },
    resetDebugLog: function resetDebugLog() {
        this.debugInfoExist = '';
        this.debugInfo = '';
    },
    cleanDebugLog: function cleanDebugLog() {
        var _this3 = this;

        this.debugInfoExist = '***';
        this.debugInfo = '';
        return new Promise(function (resolve, reject) {
            _this3.removeItem(_this3.debugInfoKey, function () {
                _this3.debugInfoExist = '***';
                _this3.debugInfo = '';
                resolve();
            });
        });
    },
    getItem: function getItem(key, callback) {
        storage.getItem(key, callback);
    },
    setItem: function setItem(key, value, callback) {
        if ((typeof value === 'undefined' ? 'undefined' : _typeof(value)) == 'object') {
            value = JSON.stringify(value);
        }
        value = value.substr(-this.debugLogSizeLmite);
        storage.setItem(key, value, callback);
    },
    removeItem: function removeItem(key, callback) {
        storage.removeItem(key, callback);
    },
    strCut2Arr: function strCut2Arr(str, n) {
        var arr = [];
        var len = Math.ceil(str.length / n);
        for (var i = 0; i < len; i++) {
            if (str.length >= n) {
                var strCut = str.substring(0, n);
                arr.push(strCut + '&*&');
                str = str.substring(n);
            } else {
                str = str;
                arr.push(str);
            }
        }
        return arr;
    }
};

debugInfoDataChannel.onmessage = function (event) {
    debugUtil.cleanDebugLog();
};

exports.default = debugUtil;

/***/ }),

/***/ 7:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _nativeService = __webpack_require__(1);

var _nativeService2 = _interopRequireDefault(_nativeService);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var appPageDataChannel = new BroadcastChannel('appPageData');
var lottieModule = weex.requireModule('lottieModule');

var HasBurialPoint = true;

var WeexLayer = function () {
    function WeexLayer() {
        _classCallCheck(this, WeexLayer);
    }

    /*
    * 页面跳转
    * params 参数对象
    * fromPage 可选参数，从哪个页面跳转进来
    * */


    _createClass(WeexLayer, null, [{
        key: 'goToPages',
        value: function goToPages(link, params, fromPage, WebComDecorator) {
            var path = link + ".js";

            var _params = params === undefined ? {} : params;
            if (fromPage !== undefined) {
                _params['fromPage'] = fromPage;
            }

            var isCanSideBack = undefined;

            if (params && params.isCanSideBack !== undefined) {
                isCanSideBack = params.isCanSideBack;
            }
            // nativeService.alert('ww'+isCanSideBack)
            _nativeService2.default.goTo(path, { viewTag: link }, { param: JSON.stringify(params) }, isCanSideBack);

            //跳转埋点
            if (HasBurialPoint) {
                var routerItems = path.split("/");
                WebComDecorator && WebComDecorator.burialPointRequestCommon && WebComDecorator.burialPointRequestCommon(routerItems[routerItems.length - 1], fromPage, {}, {});
            }
        }

        /*
        * 页面返回：普通返回 + 跳页返回
        * */

    }, {
        key: 'goBack',
        value: function goBack(link, fromPage, toPage, WebComDecorator) {
            if (link !== undefined && link !== "") {
                _nativeService2.default.goBack({ viewTag: link });
            } else {
                _nativeService2.default.goBack();
            }

            //返回埋点
            HasBurialPoint && WebComDecorator && WebComDecorator.burialPointRequestCommon && WebComDecorator.burialPointRequestCommon(toPage, fromPage, {}, {});
        }

        /*
        * 快速返回:一键返回到最开始跳转的页面
        * */

    }, {
        key: 'goBackToRootView',
        value: function goBackToRootView() {
            _nativeService2.default.goBack({ viewTag: 'rootView' });
        }

        /*
        * 页面返回：退出插件
        * */

    }, {
        key: 'goBackToMeiju',
        value: function goBackToMeiju() {
            _nativeService2.default.backToNative();
        }

        /*
        * 获取页面导航参数
        * */

    }, {
        key: 'getParams',
        value: function getParams() {
            var params = _nativeService2.default.getParameters('param');

            if (WeexLayer.isEmptyObject(params)) {
                return null;
            } else {
                return JSON.parse(params);
            }
        }

        /*
        * 获得前一个页面
        * */

    }, {
        key: 'getPrePage',
        value: function getPrePage() {
            var params = WeexLayer.getParams();

            if (params !== null && params.fromPage !== undefined) {
                return params.fromPage;
            } else {
                return null;
            }
        }

        /*
        * 重置应用程序状态
        * */

    }, {
        key: 'resetAppRuntimeData',
        value: function resetAppRuntimeData(callback, _uuid) {
            var uuid = _uuid !== undefined ? _uuid : '';
            WeexLayer.resetCache(uuid + 'appRuntimeData', function () {
                callback && callback();
            });
        }

        /*
        * 设置应用程序状态
        * */

    }, {
        key: 'setAppRuntimeData',
        value: function setAppRuntimeData(dict, callback, _uuid) {
            var uuid = _uuid !== undefined ? _uuid : '';

            WeexLayer.getCache(uuid + 'appRuntimeData', function (result) {
                var data = dict;

                if (result !== null) {
                    data = result;
                    for (var key in dict) {
                        data[key] = dict[key];
                    }
                }

                WeexLayer.setCache(uuid + 'appRuntimeData', data, callback);
            });
        }

        /*
        * 获取应用程序状态
        * */

    }, {
        key: 'getAppRuntimeData',
        value: function getAppRuntimeData(callback, _uuid) {
            var uuid = _uuid !== undefined ? _uuid : '';

            WeexLayer.getCache(uuid + 'appRuntimeData', function (result) {
                callback && callback(result);
            });
        }

        /*
        * 删除应用程序中的某个状态
        * */

    }, {
        key: 'removeAppRuntimeData',
        value: function removeAppRuntimeData(key, callback, _uuid) {
            var uuid = _uuid !== undefined ? _uuid : '';

            WeexLayer.getCache(uuid + 'appRuntimeData', function (result) {
                if (result !== null) {
                    var data = result;

                    if (data[key] !== undefined) {
                        delete data[key];

                        WeexLayer.setCache(uuid + 'appRuntimeData', data, callback);
                    }
                }
            });
        }

        /*
        * 设置缓存
        * */

    }, {
        key: 'setCache',
        value: function setCache(key, dict, callback) {
            _nativeService2.default.setItem(key, JSON.stringify(dict), function () {
                callback && callback();
            });
        }

        /*
        * 获取缓存
        * */

    }, {
        key: 'getCache',
        value: function getCache(key, callback) {
            _nativeService2.default.getItem(key, function (result) {
                if (result.data !== "undefined" && callback) {
                    callback(JSON.parse(result.data));
                } else {
                    callback(null);
                }
            });
        }

        /*
        * 重置缓存
        * */

    }, {
        key: 'resetCache',
        value: function resetCache(key, callback) {
            _nativeService2.default.removeItem(key, function () {
                callback && callback();
            });
        }

        /*
        * 消息系统
        * 发送消息
        * */

    }, {
        key: 'postMessage',
        value: function postMessage(_name, _data) {
            appPageDataChannel.postMessage({ name: _name, data: _data });
        }

        /*
        * 消息系统
        * 接受消息
        * */

    }, {
        key: 'onMessage',
        value: function onMessage(_name, callback) {
            appPageDataChannel.onmessage = function (event) {
                if (event !== undefined && event.data !== undefined && event.data.name !== undefined) {
                    if (_name === event.data.name) {
                        callback && callback(event.data.data);
                    }
                }
            };
        }
    }, {
        key: 'isEmptyObject',
        value: function isEmptyObject(obj) {
            for (var key in obj) {
                return false;
            }
            return true;
        }
    }, {
        key: 'lottieControl',


        /*
        * lottie 通用控制
        * */
        value: function lottieControl(lottieRef, action, success, error) {
            var param = {
                api: action,
                params: {}
            };
            lottieModule.lottieInterface(lottieRef, param, function (data) {
                success && success(data);
            }, function (data) {
                error && error(data);
            });
        }

        /*
        * lottie 播放
        * */

    }, {
        key: 'lottiePlay',
        value: function lottiePlay(lottieRef, success, error) {
            this.lottieControl(lottieRef, 'play', success, error);
        }

        /*
        * lottie 暂停
        * */

    }, {
        key: 'lottiePause',
        value: function lottiePause(lottieRef, success, error) {
            this.lottieControl(lottieRef, 'pause', success, error);
        }

        /*
        * lottie 恢复
        * */

    }, {
        key: 'lottieResume',
        value: function lottieResume(lottieRef, success, error) {
            this.lottieControl(lottieRef, 'resume', success, error);
        }

        /*
        * lottie 停止
        * */

    }, {
        key: 'lottieStop',
        value: function lottieStop(lottieRef, success, error) {
            this.lottieControl(lottieRef, 'stop', success, error);
        }

        /*
        * Apng 通用控制
        * */

    }, {
        key: 'apngControl',
        value: function apngControl(apngRef, action, params, success, error) {
            apngRef[action](params, function (success) {
                success && success();
            }, function (error) {
                error && error();
            });
        }

        /*
        * 获取当前页面
        * */

    }, {
        key: 'getCurrentPage',
        value: function getCurrentPage() {
            var bundleUrl = weex.config.bundleUrl;
            return bundleUrl;
            // nativeService.alert(weex.config.bundleUrl)
            // return bundleUrl.substring(bundleUrl.lastIndexOf('/') + 1, bundleUrl.lastIndexOf('.js'))
        }
    }]);

    return WeexLayer;
}();

exports.default = WeexLayer;

/***/ }),

/***/ 9:
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(13)
)

/* script */
__vue_exports__ = __webpack_require__(14)

/* template */
var __vue_template__ = __webpack_require__(15)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/chenhx113/Documents/project/meijuobmweexapp/code/AC/src/midea-component/header.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-5837942a"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),

/***/ 920:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _AddScheduleRepeat = __webpack_require__(921);

var _AddScheduleRepeat2 = _interopRequireDefault(_AddScheduleRepeat);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

new Vue({
  el: '#root',
  render: function render(h) {
    return h(_AddScheduleRepeat2.default);
  }
}); // 自动生成的入口文件

/***/ }),

/***/ 921:
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(922)
)

/* script */
__vue_exports__ = __webpack_require__(923)

/* template */
var __vue_template__ = __webpack_require__(924)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/chenhx113/Documents/project/meijuobmweexapp/code/AC/src/T0xAC/app/ac/common/AddScheduleRepeat.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-5f39bccb"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),

/***/ 922:
/***/ (function(module, exports) {

module.exports = {
  "theme-background": {
    "backgroundColor": "#F9F9F9"
  },
  "white-background": {
    "backgroundColor": "#ffffff"
  },
  "theme-background-full": {
    "backgroundColor": "#468EFF"
  },
  "theme-font-color": {
    "color": "#000000"
  },
  "theme-font-orange-color": {
    "color": "#C26033"
  },
  "theme-font-explain-color": {
    "color": "#D8D8DE",
    "opacity": 0.4
  },
  "theme-font-msg-gray-color": {
    "color": "#8A8A8F"
  },
  "theme-font-msg-gray-bg-color": {
    "backgroundColor": "#333333"
  },
  "theme-center-layout": {
    "display": "flex",
    "flexDirection": "row",
    "alignItems": "center"
  },
  "theme-center-layout-wrapper": {
    "display": "flex",
    "flexDirection": "row",
    "alignItems": "center",
    "flexWrap": "wrap"
  },
  "theme-cell-standard-style": {
    "backgroundColor": "#1a1a1a"
  },
  "spacing-line": {
    "width": 750,
    "height": 1,
    "backgroundColor": "#e2e2e2",
    "display": "flex",
    "alignSelf": "center"
  },
  "midea-cell-theme": {
    "height": 124,
    "position": "relative",
    "flexDirection": "row",
    "alignItems": "center",
    "paddingLeft": 32,
    "paddingRight": 32,
    "backgroundColor": "#1a1a1a"
  },
  "active-cell-theme": {
    "backgroundColor:active": "#cccccc"
  },
  "cell-label-text-theme": {
    "fontSize": 30,
    "color": "#666666",
    "width": 188,
    "marginRight": 10
  },
  "right-text-theme": {
    "fontSize": 25,
    "color": "#ffffff"
  },
  "cell-content-theme": {
    "color": "#ffffff",
    "fontSize": 30,
    "lineHeight": 40
  },
  "cell-desc-text-theme": {
    "color": "#999999",
    "fontSize": 24,
    "lineHeight": 30,
    "marginTop": 4
  },
  "cell-top-border-theme": {
    "borderTopColor": "#333333",
    "borderTopWidth": 1,
    "opacity": 0.8
  },
  "cell-bottom-border-theme": {
    "borderBottomWidth": 1,
    "borderBottomStyle": "solid",
    "borderBottomColor": "#333333",
    "opacity": 0.8
  },
  "wrap-theme": {
    "position": "relative",
    "flexDirection": "row",
    "backgroundColor": "#000000"
  },
  "selected-item-theme": {
    "opacity": 1,
    "color": "#ffffff",
    "fontSize": 48
  },
  "unselected-item-theme": {
    "opacity": 0.3,
    "color": "#ffffff"
  },
  "debug-util": {
    "borderWidth": 2,
    "borderColor": "#FF0000"
  },
  "ctrl-page-wrapper": {
    "backgroundColor": "#000000",
    "width": 750
  },
  "ctrl-page-scroller": {
    "flex": 1,
    "zIndex": 99999,
    "display": "flex",
    "backgroundColor": "#000000",
    "alignItems": "center",
    "marginBottom": 30
  },
  "ctrl-page-info-bg": {
    "width": 750,
    "position": "absolute"
  },
  "ctrl-page-info-panel": {
    "height": 600,
    "backgroundSize": "cover"
  },
  "ctrl-page-temp-control": {
    "display": "flex",
    "flexDirection": "row",
    "width": 750,
    "justifyContent": "center",
    "alignItems": "center",
    "position": "absolute",
    "top": 200
  },
  "ctrl-page-temperature-value": {
    "width": 380,
    "height": 400,
    "display": "flex",
    "justifyContent": "center",
    "alignItems": "center"
  },
  "ctrl-page-circleprogress": {
    "position": "absolute",
    "width": 750,
    "top": 90,
    "height": 630
  },
  "ctrl-page-circle-arc": {
    "width": 630,
    "height": 630,
    "alignSelf": "center"
  },
  "ctrl-page-temp-btn": {
    "display": "flex",
    "justifyContent": "center",
    "alignItems": "center",
    "flexDirection": "row",
    "position": "absolute",
    "width": 500,
    "left": 125,
    "top": 350
  },
  "ctrl-page-temperature-btn-img": {
    "height": 55,
    "width": 55
  },
  "ctrl-page-temperature-unit": {
    "color": "#ffffff",
    "position": "absolute",
    "top": 120,
    "right": 53,
    "fontSize": 30
  },
  "ctrl-page-more-info-wrap": {
    "width": 350,
    "paddingTop": 16,
    "paddingRight": 16,
    "paddingBottom": 16,
    "paddingLeft": 16,
    "borderRadius": 50,
    "marginTop": 30
  },
  "ctrl-page-control-btn-group": {
    "width": 700,
    "marginTop": 12,
    "marginRight": 25,
    "marginBottom": 20,
    "marginLeft": 25,
    "position": "relative",
    "top": 20
  },
  "ctrl-page-btn-img-style": {
    "height": 95,
    "width": 95
  },
  "ctrl-page-control-btn-cell": {
    "height": 152,
    "backgroundColor": "rgba(255,255,255,0.1)",
    "width": 686,
    "paddingTop": 15,
    "paddingRight": 32,
    "paddingBottom": 15,
    "paddingLeft": 32,
    "borderRadius": 20,
    "display": "flex",
    "flexDirection": "row",
    "alignItems": "center",
    "position": "relative"
  },
  "ctrl-page-control-btn-group-wrap": {
    "backgroundColor": "rgba(255,255,255,0.1)",
    "borderRadius": 20,
    "paddingTop": 30,
    "paddingRight": 0,
    "paddingBottom": 30,
    "paddingLeft": 0,
    "display": "flex",
    "flexDirection": "row",
    "flexWrap": "wrap"
  },
  "ctrl-page-single-btn": {
    "height": 145,
    "width": 135,
    "display": "flex",
    "marginTop": 10,
    "marginRight": 20,
    "marginBottom": 10,
    "marginLeft": 20,
    "flexDirection": "column",
    "justifyContent": "center",
    "alignItems": "center",
    "opacity": 1
  },
  "ctrl-page-cell-img": {
    "marginTop": 0,
    "marginRight": 30,
    "marginBottom": 0,
    "marginLeft": 0
  },
  "ctrl-page-cell-title": {
    "display": "flex",
    "alignItems": "center",
    "flexDirection": "row"
  },
  "ctrl-page-switch-btn": {
    "position": "absolute",
    "left": 550,
    "top": 50,
    "width": 100,
    "height": 60
  },
  "ctrl-page-btn-text": {
    "textAlign": "center",
    "fontSize": 24,
    "color": "#000000",
    "marginTop": 20
  },
  "silder-container": {
    "flex": 1,
    "marginLeft": 8,
    "marginRight": 8,
    "height": 64,
    "width": 550
  },
  "line-container": {
    "position": "absolute",
    "left": 20,
    "height": 64,
    "width": 550,
    "flexDirection": "row",
    "justifyContent": "space-around",
    "alignItems": "center"
  },
  "line": {
    "height": 6,
    "marginTop": 30,
    "marginRight": 3,
    "marginBottom": 30,
    "marginLeft": 3,
    "flex": 1,
    "backgroundColor": "#424546",
    "borderRadius": 2
  },
  "title": {
    "fontSize": 35,
    "textAlign": "center"
  },
  "custom-content": {
    "marginTop": 10,
    "textAlign": "center"
  },
  "content": {
    "width": 750,
    "alignItems": "center",
    "justifyContent": "center"
  },
  "info-wrapper": {
    "width": 750,
    "display": "flex",
    "justifyContent": "center",
    "alignItems": "center",
    "position": "absolute",
    "top": 300,
    "height": 600
  },
  "dialog-btn": {
    "width": 300,
    "height": 80,
    "marginTop": 0,
    "marginRight": 20,
    "marginBottom": 0,
    "marginLeft": 20,
    "display": "flex",
    "justifyContent": "center",
    "alignItems": "center",
    "backgroundColor": "#333333"
  },
  "theme-blk": {
    "position": "absolute",
    "top": 4.7,
    "left": 4,
    "zIndex": 100,
    "height": 35,
    "width": 35,
    "backgroundColor": "#808080",
    "borderRadius": 35
  },
  "theme-blk-android": {
    "position": "absolute",
    "top": 5,
    "left": 4,
    "zIndex": 100,
    "height": 35,
    "width": 35,
    "backgroundColor": "#808080",
    "borderRadius": 35
  },
  "theme-wx-switch-color": {
    "position": "absolute",
    "width": 96,
    "height": 48,
    "borderRadius": 62,
    "borderWidth": 2,
    "borderStyle": "solid"
  },
  "theme-border-show": {
    "opacity": 1,
    "borderColor": "#c06039"
  },
  "theme-border-none": {
    "opacity": 1,
    "borderColor": "#808080"
  },
  "right-text-custom": {
    "fontSize": 24,
    "color": "#999999"
  },
  "midea-cell-firmware": {
    "height": 168,
    "position": "relative",
    "flexDirection": "row",
    "alignItems": "center",
    "paddingLeft": 32,
    "paddingRight": 32,
    "backgroundColor": "#ffffff"
  }
}

/***/ }),

/***/ 923:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _base = __webpack_require__(12);

var _base2 = _interopRequireDefault(_base);

var _nativeService = __webpack_require__(1);

var _nativeService2 = _interopRequireDefault(_nativeService);

var _WeexLayer = __webpack_require__(7);

var _WeexLayer2 = _interopRequireDefault(_WeexLayer);

var _cell = __webpack_require__(42);

var _cell2 = _interopRequireDefault(_cell);

var _WebComDecorator = __webpack_require__(32);

var _WebComDecorator2 = _interopRequireDefault(_WebComDecorator);

var _Process = __webpack_require__(4);

var _Process2 = _interopRequireDefault(_Process);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var BroadcastChannel = weex.requireModule('BroadcastChannel');

exports.default = {
    name: 'AddScheduleRepeat',
    components: {
        mideaCell: _cell2.default
    },
    mixins: [_base2.default],
    data: function data() {
        return {
            t: _Process2.default,

            msg: 'AddScheduleRepeat',
            links: [],
            commonUse: [],
            customUse: [],

            week: [],
            repeat: 0,
            scheduleId: null,
            switcher: null,
            time: null,
            status: null,
            temperature: null,
            wind: null,
            mode: null,
            label: null,
            timezone: null,
            userId: null,
            appId: null,
            timeType: null,
            isUpdate: null,

            hasSet: false,

            morefuncListA: [{
                "name": "Every day",
                "rightText": "",
                "descText": "",
                "itemImg": "./../../../../assets/img/ac/clomo-ems/setting/timer-icon@2x.png",
                "selected": true
            }, {
                "name": "Weekdays",
                "rightText": "",
                "descText": "",
                "itemImg": "./../../../../assets/img/ac/clomo-ems/setting/auto-switch-icon@2x.png"
            }, {
                "name": "Only once",
                "rightText": "",
                "descText": "",
                "itemImg": "./../../../../assets/img/ac/clomo-ems/setting/auto-switch-icon@2x.png"
            }],

            morefuncListB: [{
                "name": "Monday",
                "rightText": "",
                "descText": "",
                "itemImg": "./../../../../assets/img/ac/clomo-ems/setting/timer-icon@2x.png"
            }, {
                "name": "Tuesday",
                "rightText": "",
                "descText": "",
                "itemImg": "./../../../../assets/img/ac/clomo-ems/setting/timer-icon@2x.png"
            }, {
                "name": "Wednesday",
                "rightText": "",
                "descText": "",
                "itemImg": "./../../../../assets/img/ac/clomo-ems/setting/timer-icon@2x.png"
            }, {
                "name": "Thursday",
                "rightText": "",
                "descText": "",
                "itemImg": "./../../../../assets/img/ac/clomo-ems/setting/timer-icon@2x.png"
            }, {
                "name": "Friday",
                "rightText": "",
                "descText": "",
                "itemImg": "./../../../../assets/img/ac/clomo-ems/setting/timer-icon@2x.png",
                "selected": true
            }, {
                "name": "Saturday",
                "rightText": "",
                "descText": "",
                "itemImg": "./../../../../assets/img/ac/clomo-ems/setting/timer-icon@2x.png"
            }, {
                "name": "Sunday",
                "rightText": "",
                "descText": "",
                "itemImg": "./../../../../assets/img/ac/clomo-ems/setting/timer-icon@2x.png"
            }]
        };
    },

    created: function created() {
        // globalEvent.addEventListener('receiveMessageFromApp', (data)=> {
        //     if (data.messageType == 'hardwareBackClick') {
        //         // this.selfBack();
        //     }
        // });
    },
    mounted: function mounted() {
        var _this = this;

        // this.broadcastChannel = new BroadcastChannel('scheduleRepeat');

        _nativeService2.default.getDeviceInfo().then(function (data) {
            // nativeService.alert(JSON.stringify(data))
            _this.deviceId = data.result.deviceId;
            _this.deviceSn = data.result.deviceSn;
            if (!_this.webComDecorator) {
                _this.webComDecorator = new _WebComDecorator2.default(false, _this.deviceId, _this.deviceSn, "");
            }
            // callback && callback()
        });
    },
    methods: {
        viewappear: function viewappear() {
            this.getCommonUse();
            this.getCustomUse();
            var param = _WeexLayer2.default.getParams();

            this.week = param.week;
            this.repeat = param.repeat == null || param.repeat == undefined ? 1 : param.repeat;

            this.scheduleId = param.scheduleId;
            this.switcher = param.switcher;
            this.time = param.time;
            this.status = param.status;
            this.temperature = param.temperature;
            this.wind = param.wind;
            this.mode = param.mode;
            this.label = param.label, this.timezone = param.timezone, this.userId = param.userId;
            this.appId = param.appId, this.timeType = param.timeType;

            this.isUpdate = param.isUpdate;

            if (this.repeat == 1) {
                this.setCustomSelected(this.commonUse, 2);
            } else if (this.testWeekDay([1, 2, 3, 4, 5], param.week) && param.week.length == 5) {
                this.setCustomSelected(this.commonUse, 1);
            } else if (param.week.length == 7) {
                this.setCustomSelected(this.commonUse, 0);
            } else {
                for (var i = 0; i < param.week.length; i++) {
                    this.customUse[param.week[i] - 1].selected = true;
                }
            }

            // let param = this.$route.params;
            // if (param.repeat == 1) {
            //     this.setCustomSelected(this.commonUse, 2);
            // }
            // else if (this.testWeekDay([1, 2, 3, 4, 5], param.week) && param.week.length == 5) {
            //     this.setCustomSelected(this.commonUse, 1);
            // } else if (param.week.length == 7) {
            //     this.setCustomSelected(this.commonUse, 0);
            // } else {
            //     for (let i = 0; i < param.week.length; i++) {
            //         this.customUse[param.week[i] - 1].selected = true
            //     }
            // }
            // console.log('activated', this.$route.params);
        },

        init: function init() {},
        setCustomSelected: function setCustomSelected(arr, index) {
            for (var i = 0; i < arr.length; i++) {
                arr[i].selected = false;
            }
            arr[index].selected = true;
        },
        testWeekDay: function testWeekDay(container, search) {
            var arr = [1, 2, 3, 4, 5];
            // var testArr = [1,2,3,4];
            var flag = true;
            for (var i = 0; i < container.length; i++) {
                if (!this.checkWeekday(search[i], i)) {
                    flag = false;
                    console.log("!!");
                    return false;
                } else {}
                // console.log();
            }
            return flag;
        },
        checkWeekday: function checkWeekday(item, index) {
            var isExist = false;
            if (item == index + 1) {
                isExist = true;
            }
            return isExist;
        },

        // back() {
        //     this.confirmSchedule()
        //     this.popView();
        // },
        getCommonUse: function getCommonUse() {
            this.commonUse = [{
                title: this.t.getText("Every day"),
                selected: false
            }, {
                title: this.t.getText("Weekdays"),
                selected: false
            }, {
                title: this.t.getText("Only once"),
                selected: false
            }];
        },
        getCustomUse: function getCustomUse() {
            this.customUse = [{
                title: this.t.getText("Monday"),
                selected: false
            }, {
                title: this.t.getText("Tuesday"),
                selected: false
            }, {
                title: this.t.getText("Wednesday"),
                selected: false
            }, {
                title: this.t.getText("Thursday"),
                selected: false
            }, {
                title: this.t.getText("Friday"),
                selected: false
            }, {
                title: this.t.getText("Saturday"),
                selected: false
            }, {
                title: this.t.getText("Sunday"),
                selected: false
            }];
        },
        cellClick: function cellClick(item) {
            // nativeService.toast(JSON.stringify(item));
            this.resetCustomUse();
            // if (item.selected) {
            //     item.selected = false;
            // } else {
            this.resetCommonUse();
            item.selected = true;
            this.hasSet = true;
            // }

            // console.log(!item.selected);

            var repeatWeek = [];
            var repeat = 0; //0代表没选择 1代表不重复，2代表重复
            // ['每天','工作日','一次']
            for (var i = 0; i < this.commonUse.length; i++) {
                // console.log(this.commonUse[i]);
                if (this.commonUse[i].selected) {
                    // console.log(this.commonUse[i].title);
                    if (i == 0) {
                        repeatWeek = [1, 2, 3, 4, 5, 6, 7];
                        repeat = 2;
                    } else if (i == 1) {
                        repeatWeek = [1, 2, 3, 4, 5];
                        repeat = 2;
                    } else if (i == 2) {
                        repeatWeek = [];
                        repeat = 1;
                    }
                }
            }

            for (var j = 0; j < this.customUse.length; j++) {
                if (this.customUse[j].selected) {
                    repeatWeek.push(j + 1);
                    repeat = 2;
                }
            }
            // nativeService.alert("end confirm"+ repeatWeek + '---repeat:' +repeat);
            // 修改时才会立即保存(新增时因为无scheduleId,返回无法获取获取保存后的scheduleId)
            // nativeService.alert(this.isUpdate)
            if (this.isUpdate) {
                // nativeService.alert(JSON.stringify(this.timeType));
                this.webComDecorator.updateSchedule(this.scheduleId, this.switcher, this.time, repeatWeek, repeat, this.status, this.temperature, this.wind, this.mode, this.label, this.timezone, this.userId, this.appId, this.timeType, function (data) {
                    // nativeService.alert(JSON.stringify(data));
                    // nativeService.toast(t.getText('update success'));
                    // this.showLoading(false);
                    // this.back();
                }, function (errorCode, errorMsg) {
                    // nativeService.toast(t.getText('update fail'));
                });
            } else {
                // 保存至cache,返回后去获取该标识的缓存
                _WeexLayer2.default.setCache('weekAndRepeat', {
                    week: repeatWeek,
                    repeat: repeat
                }, function () {});
            }
        },
        customClick: function customClick(item) {

            if (this.checkAllSelected()) {
                item.selected = true;
                console.log("if");
            } else {
                console.log("else");
                item.selected = !item.selected;
            }
            this.checkAllSelected();
            this.resetCommonUse(); // 重置上面的
            this.hasSet = true;

            var repeatWeek = [];
            var repeat = 0; //0代表没选择 1代表不重复，2代表重复
            // ['每天','工作日','一次']
            for (var i = 0; i < this.commonUse.length; i++) {
                // console.log(this.commonUse[i]);
                if (this.commonUse[i].selected) {
                    // console.log(this.commonUse[i].title);
                    if (i == 0) {
                        repeatWeek = [1, 2, 3, 4, 5, 6, 7];
                        repeat = 2;
                    } else if (i == 1) {
                        repeatWeek = [1, 2, 3, 4, 5];
                        repeat = 2;
                    } else if (i == 2) {
                        repeatWeek = [];
                        repeat = 1;
                    }
                }
            }

            for (var j = 0; j < this.customUse.length; j++) {
                if (this.customUse[j].selected) {
                    repeatWeek.push(j + 1);
                    repeat = 2;
                }
            }
            // nativeService.alert(repeatWeek)
            // nativeService.alert("end confirm"+ repeatWeek + '---repeat:' +repeat);
            // 修改时才会立即保存(新增时因为无scheduleId,返回无法获取获取保存后的scheduleId)
            // nativeService.alert(this.isUpdate)
            if (this.isUpdate) {
                // nativeService.alert(JSON.stringify(this.timeType));
                this.webComDecorator.updateSchedule(this.scheduleId, this.switcher, this.time, repeatWeek, repeat, this.status, this.temperature, this.wind, this.mode, this.label, this.timezone, this.userId, this.appId, this.timeType, function (data) {
                    // nativeService.alert(JSON.stringify(data));
                    // nativeService.toast(t.getText('update success'));
                    // this.showLoading(false);
                    // this.back();
                }, function (errorCode, errorMsg) {
                    // nativeService.alert(errorMsg)
                    // nativeService.toast(t.getText('update fail'));
                });
            } else {
                // 保存至cache,返回后去获取该标识的缓存
                _WeexLayer2.default.setCache('weekAndRepeat', {
                    week: repeatWeek,
                    repeat: repeat
                }, function () {
                    //  nativeService.alert(JSON.stringify(333))
                    // this.back();
                });
            }
        },
        checkAllSelected: function checkAllSelected() {
            var j = 0;
            for (var i = 0; i < this.customUse.length; i++) {
                if (this.customUse[i].selected == false) {
                    j++;
                }
                // this.customUse[i].selected = false;
            }
            console.log(j, j == 6 ? true : false);
            return j == 6 ? true : false;
        },
        resetCommonUse: function resetCommonUse() {
            for (var i = 0; i < this.commonUse.length; i++) {
                this.commonUse[i].selected = false;
            }
        },
        resetCustomUse: function resetCustomUse() {
            for (var i = 0; i < this.customUse.length; i++) {
                this.customUse[i].selected = false;
            }
        },
        confirmSchedule: function confirmSchedule() {
            var _this2 = this;

            console.log("confirm");
            var repeatWeek = [];
            var repeat = 0; //0代表没选择 1代表不重复，2代表重复
            // ['每天','工作日','一次']
            for (var i = 0; i < this.commonUse.length; i++) {
                // console.log(this.commonUse[i]);
                if (this.commonUse[i].selected) {
                    // console.log(this.commonUse[i].title);
                    if (i == 0) {
                        repeatWeek = [1, 2, 3, 4, 5, 6, 7];
                        repeat = 2;
                    } else if (i == 1) {
                        repeatWeek = [1, 2, 3, 4, 5];
                        repeat = 2;
                    } else if (i == 2) {
                        repeatWeek = [];
                        repeat = 1;
                    }
                }
            }

            for (var j = 0; j < this.customUse.length; j++) {
                if (this.customUse[j].selected) {
                    repeatWeek.push(j + 1);
                    repeat = 2;
                }
            }
            // nativeService.alert("end confirm"+ repeatWeek + '---repeat:' +repeat);

            _WeexLayer2.default.postMessage('repeatBack', {
                repeatWeek: repeatWeek,
                repeat: repeat,
                hasSet: this.hasSet
            });

            _WeexLayer2.default.getCache('timerData', function (item) {
                _WeexLayer2.default.setCache('timerData', {
                    mode: item.mode,
                    wind: item.wind,
                    temperature: item.temperature,
                    label: item.label,
                    time: item.time,
                    switcher: item.switcher,
                    isUpdate: item.isUpdate, // 标志位区分是新增还是修改
                    scheduleId: item.scheduleId,
                    timeType: item.timeType,
                    week: repeatWeek,
                    repeat: repeat
                }, function () {
                    _this2.back();
                });
            });

            // let data = {
            //     timerData: {
            //         mode: item.mode,
            //         wind: item.wind,
            //         temperature: item.temperature,
            //         label: item.label,
            //         time: item.time,
            //         switcher: item.switcher,
            //         isUpdate: item.isUpdate, // 标志位区分是新增还是修改
            //         scheduleId: item.scheduleId,
            //         week: repeatWeek,
            //         repeat: repeat
            //     }};
            // nativeService.alert(JSON.stringify(data));
            // let item = this.getCache(this).timerData;
            // this.setCache(this, {
            //     timerData: {
            //         mode: item.mode,
            //         wind: item.wind,
            //         temperature: item.temperature,
            //         label: item.label,
            //         time: item.time,
            //         switcher: item.switcher,
            //         isUpdate: item.isUpdate, // 标志位区分是新增还是修改
            //         scheduleId: item.scheduleId,
            //         week: repeatWeek,
            //         repeat: repeat
            //     }
            // });
        },
        selfBack: function selfBack() {
            this.confirmSchedule();
        }
    }
};

/***/ }),

/***/ 924:
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    ref: "wrapper",
    staticClass: ["wrapper", "theme-background"],
    on: {
      "viewappear": _vm.viewappear,
      "viewdisappear": _vm.viewdisappear
    }
  }, [_c('div', {
    staticClass: ["accounted"],
    style: {
      'height': _vm.pageHeight
    }
  }, [_c('midea-header', {
    attrs: {
      "title": _vm.t.getText('Repeat'),
      "isImmersion": _vm.isImmersion,
      "showRightImg": true,
      "rightImg": "./../../../assets/img/smart_ic_reline@3x11.png"
    },
    on: {
      "leftImgClick": _vm.selfBack,
      "rightImgClick": _vm.reload
    }
  }), _c('div', {
    staticStyle: {
      marginTop: "24px"
    }
  }, [_vm._l((_vm.commonUse), function(item, i) {
    return _c('midea-cell', {
      attrs: {
        "itemImgWidth": "40",
        "itemImgHeight": "40",
        "title": item.title,
        "hasArrow": false,
        "height": "124",
        "hasTopBorder": true,
        "hasBottomBorder": false,
        "hasSubBottomBorder": false,
        "clickActivied": true,
        "rightText": item.rightText,
        "desc": item.descText
      },
      on: {
        "mideaCellClick": function($event) {
          _vm.cellClick(item)
        }
      }
    }, [_c('div', {
      staticClass: ["cell_content"],
      slot: "rightText"
    }, [(item.selected) ? _c('image', {
      staticStyle: {
        width: "40px",
        height: "40px"
      },
      attrs: {
        "src": "./../../../assets/img/ac/common/choose.png"
      }
    }) : _vm._e()])])
  }), _c('div', {
    staticClass: ["spacing-line"]
  })], 2), _c('div', {
    staticStyle: {
      marginTop: "24px"
    }
  }, [_vm._l((_vm.customUse), function(item, i) {
    return _c('midea-cell', {
      attrs: {
        "itemImgWidth": "40",
        "itemImgHeight": "40",
        "title": item.title,
        "hasArrow": false,
        "height": "124",
        "hasTopBorder": true,
        "hasBottomBorder": false,
        "hasSubBottomBorder": false,
        "clickActivied": true,
        "rightText": item.rightText,
        "desc": item.descText
      },
      on: {
        "mideaCellClick": function($event) {
          _vm.customClick(item)
        }
      }
    }, [_c('div', {
      staticClass: ["cell_content"],
      slot: "rightText"
    }, [(item.selected) ? _c('image', {
      staticStyle: {
        width: "40px",
        height: "40px"
      },
      attrs: {
        "src": "./../../../assets/img/ac/common/choose.png"
      }
    }) : _vm._e()])])
  }), _c('div', {
    staticClass: ["spacing-line"]
  })], 2)], 1)])
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ })

/******/ });